<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="vi_VN">
<context>
    <name>AiAssistedAnnotationWidget</name>
    <message>
        <source>AI-Assisted Annotation</source>
        <translation>Chú thích dữ liệu với sự hỗ trợ của AI</translation>
    </message>
    <message>
        <source>AI suggests annotation in &apos;AI-Points&apos; and &apos;AI-Box&apos; modes</source>
        <translation>AI gợi ý chú thích trong các chế độ &apos;AI-Points&apos; và &apos;AI-Box&apos;</translation>
    </message>
    <message>
        <source>Polygon detail</source>
        <translation>Độ chi tiết đa giác</translation>
    </message>
    <message>
        <source>Adjust polygon detail</source>
        <translation>Điều chỉnh độ chi tiết đa giác</translation>
    </message>
    <message>
        <source>Smoother</source>
        <translation>Mượt hơn</translation>
    </message>
    <message>
        <source>More detail</source>
        <translation>Chi tiết hơn</translation>
    </message>
    <message>
        <source>Select &apos;AI-Points&apos; or &apos;AI-Box&apos; mode to enable AI-Assisted Annotation</source>
        <translation>Chọn chế độ &apos;AI-Points&apos; hoặc &apos;AI-Box&apos; để bật Chú thích Hỗ trợ AI</translation>
    </message>
</context>
<context>
    <name>AiTextToAnnotationWidget</name>
    <message>
        <source>AI Text-to-Annotation</source>
        <translation>AI Văn bản sang Chú thích</translation>
    </message>
    <message>
        <source>e.g., dog,cat,bird</source>
        <translation>ví dụ: chó,mèo,chim</translation>
    </message>
    <message>
        <source>Run</source>
        <translation>Chạy</translation>
    </message>
    <message>
        <source>Score</source>
        <translation>Điểm số</translation>
    </message>
    <message>
        <source>IoU</source>
        <translation>IoU</translation>
    </message>
    <message>
        <source>AI creates annotations from the text prompt</source>
        <translation>AI tạo chú thích từ lời nhắc văn bản</translation>
    </message>
    <message>
        <source>Select &apos;Polygon&apos;, &apos;Rectangle&apos;, or &apos;AI-Points&apos; mode to enable</source>
        <translation>Chọn chế độ &apos;Polygon&apos;, &apos;Rectangle&apos; hoặc &apos;AI-Points&apos; để bật</translation>
    </message>
</context>
<context>
    <name>BrightnessContrastDialog</name>
    <message>
        <source>Brightness/Contrast</source>
        <translation>Độ sáng/Độ tương phản</translation>
    </message>
    <message>
        <source>Brightness:</source>
        <translation>Độ sáng:</translation>
    </message>
    <message>
        <source>Contrast:</source>
        <translation>Độ tương phản:</translation>
    </message>
</context>
<context>
    <name>Canvas</name>
    <message>
        <source>Click &amp; drag to move point</source>
        <translation>Nhấn và kéo để di chuyển điểm</translation>
    </message>
    <message>
        <source>Click &amp; drag to move shape</source>
        <translation>Nhấn và kéo để di chuyển hình dạng</translation>
    </message>
    <message>
        <source>Creating %r</source>
        <translation>Đang tạo %r</translation>
    </message>
    <message>
        <source>ESC to cancel</source>
        <translation>Nhấn ESC để hủy</translation>
    </message>
    <message>
        <source>Enter or Space to finalize</source>
        <translation>Nhấn Enter hoặc Space để hoàn tất</translation>
    </message>
    <message>
        <source>Editing shapes</source>
        <translation>Chỉnh sửa hình dạng</translation>
    </message>
    <message>
        <source>Click start point for line</source>
        <translation>Nhấn điểm bắt đầu cho đường thẳng</translation>
    </message>
    <message>
        <source>Click end point for line</source>
        <translation>Nhấn điểm kết thúc cho đường thẳng</translation>
    </message>
    <message>
        <source>Click start point for linestrip</source>
        <translation>Nhấn điểm bắt đầu cho đường gấp khúc</translation>
    </message>
    <message>
        <source>Click next point or finish by Ctrl/Cmd+Click for linestrip</source>
        <translation>Nhấn điểm tiếp theo hoặc hoàn tất bằng Ctrl/Cmd+Nhấn cho đường gấp khúc</translation>
    </message>
    <message>
        <source>Click center point for circle</source>
        <translation>Nhấn điểm trung tâm cho hình tròn</translation>
    </message>
    <message>
        <source>Click point on circumference for circle</source>
        <translation>Nhấn điểm trên chu vi cho hình tròn</translation>
    </message>
    <message>
        <source>Click first corner for rectangle</source>
        <translation>Nhấn góc đầu tiên cho hình chữ nhật</translation>
    </message>
    <message>
        <source>Click to add point</source>
        <translation>Nhấn để thêm điểm</translation>
    </message>
    <message>
        <source>ALT + SHIFT + Click to delete point</source>
        <translation>ALT + SHIFT + Nhấn để xóa điểm</translation>
    </message>
    <message>
        <source>ALT + Click to create point on shape</source>
        <translation>ALT + Nhấn để tạo điểm trên hình dạng</translation>
    </message>
    <message>
        <source>Right-click &amp; drag to copy shape</source>
        <translation>Nhấn chuột phải và kéo để sao chép hình dạng</translation>
    </message>
    <message>
        <source>Click opposite corner for rectangle (Shift for square)</source>
        <translation>Nhấn góc đối diện cho hình chữ nhật (Shift để tạo hình vuông)</translation>
    </message>
    <message>
        <source>Click points to include or Shift+Click to exclude. Ctrl+LeftClick ends creation.</source>
        <translation>Nhấp điểm để bao gồm hoặc Shift+Click để loại trừ. Ctrl+LeftClick kết thúc tạo.</translation>
    </message>
    <message>
        <source>Click first corner of bbox for AI segmentation</source>
        <translation>Nhấp vào góc đầu tiên của bbox để phân đoạn AI</translation>
    </message>
    <message>
        <source>Click opposite corner to segment object</source>
        <translation>Nhấp vào góc đối diện để phân đoạn đối tượng</translation>
    </message>
    <message>
        <source>Click first corner for oriented rectangle</source>
        <translation>Nhấn góc đầu tiên cho hình chữ nhật có hướng</translation>
    </message>
    <message>
        <source>Click second corner to set orientation</source>
        <translation>Nhấn góc thứ hai để đặt hướng</translation>
    </message>
    <message>
        <source>Click third corner to close oriented rectangle</source>
        <translation>Nhấn góc thứ ba để đóng hình chữ nhật có hướng</translation>
    </message>
    <message>
        <source>Click &amp; drag to rotate the shape</source>
        <translation>Nhấn và kéo để xoay hình dạng</translation>
    </message>
</context>
<context>
    <name>EmptyStateWidget</name>
    <message>
        <source>Start annotating</source>
        <translation>Bắt đầu chú thích</translation>
    </message>
    <message>
        <source>Open an image or a directory of images to begin.</source>
        <translation>Mở một hình ảnh hoặc thư mục hình ảnh để bắt đầu.</translation>
    </message>
    <message>
        <source>Open Image</source>
        <translation>Mở hình ảnh</translation>
    </message>
    <message>
        <source>Open Directory</source>
        <translation>Mở thư mục</translation>
    </message>
    <message>
        <source>Or drag and drop image files here</source>
        <translation>Hoặc kéo và thả tệp hình ảnh vào đây</translation>
    </message>
</context>
<context>
    <name>LabelDialog</name>
    <message>
        <source>Shape Label</source>
        <translation>Nhãn hình dạng</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Nhãn</translation>
    </message>
    <message>
        <source>Group ID</source>
        <translation>ID nhóm</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Mô tả</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Flags</source>
        <translation>Cờ</translation>
    </message>
    <message>
        <source>Shape List</source>
        <translation>Danh sách Hình dạng</translation>
    </message>
    <message>
        <source>Select label to start annotating for it. Press &apos;Esc&apos; to deselect.</source>
        <translation>Chọn nhãn để bắt đầu chú thích. Nhấn &apos;Esc&apos; để bỏ chọn.</translation>
    </message>
    <message>
        <source>Label List</source>
        <translation>Danh sách Nhãn</translation>
    </message>
    <message>
        <source>Search Filename</source>
        <translation>Tìm kiếm Tên tệp</translation>
    </message>
    <message>
        <source>File List</source>
        <translation>Danh sách Tệp</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation>Thoát(&amp;Q)</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>Thoát ứng dụng</translation>
    </message>
    <message>
        <source>&amp;Open
</source>
        <translation>Mở(&amp;O)</translation>
    </message>
    <message>
        <source>Open image or label file</source>
        <translation>Mở tệp hình ảnh hoặc nhãn</translation>
    </message>
    <message>
        <source>Open Dir</source>
        <translation>Mở Thư mục</translation>
    </message>
    <message>
        <source>&amp;Next Image</source>
        <translation>Hình ảnh Tiếp theo(&amp;N)</translation>
    </message>
    <message>
        <source>Open next (hold Ctl+Shift to copy labels)</source>
        <translation>Mở tiếp theo (giữ Ctl+Shift để sao chép nhãn)</translation>
    </message>
    <message>
        <source>&amp;Prev Image</source>
        <translation>Hình ảnh Trước(&amp;P)</translation>
    </message>
    <message>
        <source>Open prev (hold Ctl+Shift to copy labels)</source>
        <translation>Mở trước đó (giữ Ctl+Shift để sao chép nhãn)</translation>
    </message>
    <message>
        <source>&amp;Save
</source>
        <translation>Lưu(&amp;S)</translation>
    </message>
    <message>
        <source>Save labels to file</source>
        <translation>Lưu nhãn vào tệp</translation>
    </message>
    <message>
        <source>&amp;Save As</source>
        <translation>Lưu thành(&amp;S)</translation>
    </message>
    <message>
        <source>&amp;Delete File</source>
        <translation>Xóa(&amp;D)</translation>
    </message>
    <message>
        <source>Delete current label file</source>
        <translation>Xóa tệp nhãn hiện tại</translation>
    </message>
    <message>
        <source>&amp;Change Output Dir</source>
        <translation>Thay đổi Thư mục Đầu ra(&amp;C)</translation>
    </message>
    <message>
        <source>Change where annotations are loaded/saved</source>
        <translation>Thay đổi nơi chú thích được tải/lưu</translation>
    </message>
    <message>
        <source>Save &amp;Automatically</source>
        <translation>Tự động lưu (&amp;A)</translation>
    </message>
    <message>
        <source>Save automatically</source>
        <translation>Tự động lưu</translation>
    </message>
    <message>
        <source>Save With Image Data</source>
        <translation>Lưu với Dữ liệu Hình ảnh</translation>
    </message>
    <message>
        <source>Save image data in label file</source>
        <translation>Lưu dữ liệu hình ảnh trong tệp nhãn</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>Đóng(&amp;C)</translation>
    </message>
    <message>
        <source>Close current file</source>
        <translation>Đóng tệp hiện tại</translation>
    </message>
    <message>
        <source>Keep Previous Annotation</source>
        <translation>Giữ Chú thích Trước đó</translation>
    </message>
    <message>
        <source>Start drawing polygons</source>
        <translation>Bắt đầu vẽ đa giác</translation>
    </message>
    <message>
        <source>Start drawing rectangles</source>
        <translation>Bắt đầu vẽ hình chữ nhật</translation>
    </message>
    <message>
        <source>Start drawing circles</source>
        <translation>Bắt đầu vẽ hình tròn</translation>
    </message>
    <message>
        <source>Start drawing lines</source>
        <translation>Bắt đầu vẽ đường thẳng</translation>
    </message>
    <message>
        <source>Start drawing points</source>
        <translation>Bắt đầu vẽ điểm</translation>
    </message>
    <message>
        <source>Edit Shapes</source>
        <translation>Chỉnh sửa Hình dạng</translation>
    </message>
    <message>
        <source>Move and edit the selected shapes</source>
        <translation>Di chuyển và chỉnh sửa các hình dạng đã chọn</translation>
    </message>
    <message>
        <source>Delete Shapes</source>
        <translation>Xóa Hình dạng</translation>
    </message>
    <message>
        <source>Delete the selected shapes</source>
        <translation>Xóa các hình dạng đã chọn</translation>
    </message>
    <message>
        <source>Duplicate Shapes</source>
        <translation>Nhân đôi Hình dạng</translation>
    </message>
    <message>
        <source>Create a duplicate of the selected shapes</source>
        <translation>Tạo bản sao của các hình dạng đã chọn</translation>
    </message>
    <message>
        <source>Undo last point</source>
        <translation>Hoàn tác điểm cuối cùng</translation>
    </message>
    <message>
        <source>Undo last drawn point</source>
        <translation>Hoàn tác điểm vẽ cuối cùng</translation>
    </message>
    <message>
        <source>Remove Selected Point</source>
        <translation>Xóa Điểm đã Chọn</translation>
    </message>
    <message>
        <source>Remove selected point from polygon</source>
        <translation>Xóa điểm đã chọn khỏi đa giác</translation>
    </message>
    <message>
        <source>Undo
</source>
        <translation>Hoàn tác</translation>
    </message>
    <message>
        <source>Undo last add and edit of shape</source>
        <translation>Hoàn tác lần thêm và chỉnh sửa hình dạng cuối cùng</translation>
    </message>
    <message>
        <source>&amp;Hide
Shapes</source>
        <translation>Ẩn Hình dạng(&amp;H)</translation>
    </message>
    <message>
        <source>Hide all shapes</source>
        <translation>Ẩn tất cả hình dạng</translation>
    </message>
    <message>
        <source>&amp;Show
Shapes</source>
        <translation>Hiển thị Hình dạng(&amp;S)</translation>
    </message>
    <message>
        <source>Show all shapes</source>
        <translation>Hiển thị tất cả hình dạng</translation>
    </message>
    <message>
        <source>&amp;Toggle
Shapes</source>
        <translation>Bật/tắt Hình dạng(&amp;S)</translation>
    </message>
    <message>
        <source>Toggle all shapes</source>
        <translation>Bật/tắt tất cả hình dạng</translation>
    </message>
    <message>
        <source>&amp;Tutorial</source>
        <translation>Hướng dẫn(&amp;T)</translation>
    </message>
    <message>
        <source>Show tutorial page</source>
        <translation>Hiển thị trang hướng dẫn</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation>Thu phóng</translation>
    </message>
    <message>
        <source>Zoom &amp;In</source>
        <translation>Phóng to(&amp;I)</translation>
    </message>
    <message>
        <source>&amp;Zoom Out</source>
        <translation>Thu nhỏ(&amp;Z)</translation>
    </message>
    <message>
        <source>&amp;Brightness Contrast</source>
        <translation>Độ sáng Độ tương phản(&amp;B)</translation>
    </message>
    <message>
        <source>Adjust brightness and contrast</source>
        <translation>Điều chỉnh độ sáng và độ tương phản</translation>
    </message>
    <message>
        <source>&amp;Edit Label</source>
        <translation>Chỉnh sửa Nhãn(&amp;E)</translation>
    </message>
    <message>
        <source>Save the labels under a new file name</source>
        <translation>Lưu nhãn với tên tệp mới</translation>
    </message>
    <message>
        <source>Modify the label of the selected shape</source>
        <translation>Sửa đổi nhãn của hình dạng đã chọn</translation>
    </message>
    <message>
        <source>Copy to Clipboard</source>
        <translation>Sao chép vào Clipboard</translation>
    </message>
    <message>
        <source>Place the selected shapes on the clipboard</source>
        <translation>Đưa các hình dạng đã chọn vào clipboard</translation>
    </message>
    <message>
        <source>Paste from Clipboard</source>
        <translation>Dán từ Clipboard</translation>
    </message>
    <message>
        <source>Insert the clipboard shapes into this image</source>
        <translation>Chèn các hình dạng trong clipboard vào ảnh này</translation>
    </message>
    <message>
        <source>Click to place linestrip points; Ctrl+click places the last one.</source>
        <translation>Nhấn để đặt các điểm của đường gấp khúc; Ctrl+nhấn đặt điểm cuối cùng.</translation>
    </message>
    <message>
        <source>Fit to &amp;Window</source>
        <translation>Vừa Cửa sổ(&amp;W)</translation>
    </message>
    <message>
        <source>Keep the whole image visible when the window is resized</source>
        <translation>Giữ toàn bộ ảnh luôn hiển thị khi thay đổi kích thước cửa sổ</translation>
    </message>
    <message>
        <source>Fit to Wi&amp;dth</source>
        <translation>Vừa Chiều rộng(&amp;D)</translation>
    </message>
    <message>
        <source>Match the image width to the window when it is resized</source>
        <translation>Khớp chiều rộng của ảnh với cửa sổ khi thay đổi kích thước</translation>
    </message>
    <message>
        <source>Make the image appear larger</source>
        <translation>Hiển thị ảnh lớn hơn</translation>
    </message>
    <message>
        <source>Make the image appear smaller</source>
        <translation>Hiển thị ảnh nhỏ hơn</translation>
    </message>
    <message>
        <source>&amp;Actual Size</source>
        <translation>Kích thước &amp;thật</translation>
    </message>
    <message>
        <source>Show the image at 100%</source>
        <translation>Hiển thị ảnh ở mức 100%</translation>
    </message>
    <message>
        <source>Fill Drawing Polygon</source>
        <translation>Tô Đa giác Vẽ</translation>
    </message>
    <message>
        <source>Fill polygon while drawing</source>
        <translation>Tô đa giác khi vẽ</translation>
    </message>
    <message>
        <source>Ctrl+Wheel zooms the canvas</source>
        <translation>Ctrl+Bánh xe phóng to/thu nhỏ canvas</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>Tệp(&amp;F)</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>Chỉnh sửa(&amp;E)</translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation>Xem(&amp;V)</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>Trợ giúp(&amp;H)</translation>
    </message>
    <message>
        <source>%s started.</source>
        <translation>%s đã khởi động.</translation>
    </message>
    <message>
        <source>Mask Output Unavailable</source>
        <translation>Không có đầu ra mặt nạ</translation>
    </message>
    <message>
        <source>%s only detects bounding boxes and cannot create &apos;%s&apos; annotations.

Switch the AI Text-to-Annotation model to &apos;SAM3 (smart)&apos;, or set the output format to &apos;Rectangle&apos;.</source>
        <translation>%s chỉ phát hiện khung giới hạn và không thể tạo chú thích &apos;%s&apos;.

Chuyển mô hình AI Text-to-Annotation sang &apos;SAM3 (smart)&apos;, hoặc đặt định dạng đầu ra thành &apos;Rectangle&apos;.</translation>
    </message>
    <message>
        <source>Invalid label</source>
        <translation>Nhãn không hợp lệ</translation>
    </message>
    <message>
        <source>Invalid label &apos;{}&apos; with validation type &apos;{}&apos;</source>
        <translation>Nhãn không hợp lệ &apos;{}&apos; với loại xác thực &apos;{}&apos;</translation>
    </message>
    <message>
        <source>Error saving label data</source>
        <translation>Lỗi khi lưu dữ liệu nhãn</translation>
    </message>
    <message>
        <source>&lt;b&gt;%s&lt;/b&gt;</source>
        <translation>&lt;b&gt;%s&lt;/b&gt;</translation>
    </message>
    <message>
        <source>AI inference failed: %s</source>
        <translation>Suy luận AI thất bại: %s</translation>
    </message>
    <message>
        <source>Error opening file</source>
        <translation>Lỗi khi mở tệp</translation>
    </message>
    <message>
        <source>No such file: &lt;b&gt;%s&lt;/b&gt;</source>
        <translation>Không có tệp như vậy: &lt;b&gt;%s&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Loading %s...</source>
        <translation>Đang tải %s...</translation>
    </message>
    <message>
        <source>Loaded %s</source>
        <translation>Đã tải %s</translation>
    </message>
    <message>
        <source>Image &amp; Label files (%s)</source>
        <translation>Tệp Hình ảnh &amp; Nhãn (%s)</translation>
    </message>
    <message>
        <source>%s - Choose Image or Label file</source>
        <translation>%s - Chọn tệp Hình ảnh hoặc Nhãn</translation>
    </message>
    <message>
        <source>%s - Save/Load Annotations in Directory</source>
        <translation>%s - Lưu/Tải Chú thích trong Thư mục</translation>
    </message>
    <message>
        <source>%s . Annotations will be saved/loaded in %s</source>
        <translation>%s . Chú thích sẽ được lưu/tải trong %s</translation>
    </message>
    <message>
        <source>%s - Choose File</source>
        <translation>%s - Chọn Tệp</translation>
    </message>
    <message>
        <source>Label files (*%s)</source>
        <translation>Tệp nhãn (*%s)</translation>
    </message>
    <message>
        <source>Choose File</source>
        <translation>Chọn Tệp</translation>
    </message>
    <message>
        <source>Attention</source>
        <translation>Chú ý</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Xóa</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Hủy</translation>
    </message>
    <message>
        <source>Unavailable in AI-Points mode because this model does not support point prompts.</source>
        <translation>Không khả dụng trong chế độ AI-Points vì mô hình này không hỗ trợ lời nhắc điểm.</translation>
    </message>
    <message>
        <source>Save annotations to &quot;{}&quot; before closing?</source>
        <translation>Lưu chú thích vào &quot;{}&quot; trước khi đóng?</translation>
    </message>
    <message>
        <source>Save annotations?</source>
        <translation>Lưu chú thích?</translation>
    </message>
    <message>
        <source>Delete {} shapes? You can restore them with Undo.</source>
        <translation>Xóa {} hình dạng? Bạn có thể khôi phục chúng bằng Hoàn tác.</translation>
    </message>
    <message>
        <source>%s - Open Directory</source>
        <translation>%s - Mở Thư mục</translation>
    </message>
    <message>
        <source>The image is too large to open: {width}x{height} pixels exceeds the {max_side} pixel per-side limit of the raster engine. Raising the decode limit will not help. Split the image into tiles (for example with gdal_retile.py) or open a smaller copy.</source>
        <translation>Hình ảnh quá lớn để mở: {width}x{height} pixel vượt quá giới hạn {max_side} pixel mỗi cạnh của công cụ raster. Tăng giới hạn giải mã sẽ không giúp ích. Hãy chia hình ảnh thành các ô (ví dụ với gdal_retile.py) hoặc mở một bản sao nhỏ hơn.</translation>
    </message>
    <message>
        <source>The image is too large to open: {width}x{height} pixels needs about {required} MB, but the decode limit is {limit} MB. Split the image into tiles (for example with gdal_retile.py) or open a smaller copy.</source>
        <translation>Hình ảnh quá lớn để mở: {width}x{height} pixel cần khoảng {required} MB, nhưng giới hạn giải mã là {limit} MB. Hãy chia hình ảnh thành các ô (ví dụ với gdal_retile.py) hoặc mở một bản sao nhỏ hơn.</translation>
    </message>
    <message>
        <source>Toggle &quot;keep previous annotation&quot; mode</source>
        <translation>Bật/tắt chế độ &quot;giữ chú thích trước đó&quot;</translation>
    </message>
    <message>
        <source>Keep Previous Brightness/Contrast</source>
        <translation>Giữ Độ sáng/Độ tương phản Trước đó</translation>
    </message>
    <message>
        <source>Configuration Errors</source>
        <translation>Lỗi Cấu hình</translation>
    </message>
    <message>
        <source>Errors were found while loading the configuration. Please review the errors below and reload your configuration or ignore the erroneous lines.</source>
        <translation>Đã tìm thấy lỗi khi tải cấu hình. Vui lòng xem lại các lỗi bên dưới và tải lại cấu hình hoặc bỏ qua các dòng bị lỗi.</translation>
    </message>
    <message>
        <source>Reset Layout</source>
        <translation>Đặt lại bố cục</translation>
    </message>
    <message>
        <source>Polygon</source>
        <translation>Đa giác</translation>
    </message>
    <message>
        <source>Rectangle</source>
        <translation>Hình chữ nhật</translation>
    </message>
    <message>
        <source>Circle</source>
        <translation>Hình tròn</translation>
    </message>
    <message>
        <source>Line</source>
        <translation>Đường thẳng</translation>
    </message>
    <message>
        <source>Point</source>
        <translation>Điểm</translation>
    </message>
    <message>
        <source>LineStrip</source>
        <translation>Đường gấp khúc</translation>
    </message>
    <message>
        <source>AI-Points</source>
        <translation>AI-Points</translation>
    </message>
    <message>
        <source>Click points to segment object. Ctrl+LeftClick ends creation.</source>
        <translation>Nhấp điểm để phân đoạn đối tượng. Ctrl+LeftClick kết thúc tạo.</translation>
    </message>
    <message>
        <source>AI-Box</source>
        <translation>AI-Box</translation>
    </message>
    <message>
        <source>Draw a bounding box to segment object.</source>
        <translation>Vẽ một hộp giới hạn để phân đoạn đối tượng.</translation>
    </message>
    <message>
        <source>AI-Points Unavailable</source>
        <translation>AI-Points không khả dụng</translation>
    </message>
    <message>
        <source>%s does not support point prompts.
Please select a different model or use AI-Box mode.</source>
        <translation>%s không hỗ trợ gợi ý điểm.
Vui lòng chọn mô hình khác hoặc sử dụng chế độ AI-Box.</translation>
    </message>
    <message>
        <source>File list is disabled when a label file is opened</source>
        <translation>Danh sách tệp bị tắt khi mở tệp nhãn</translation>
    </message>
    <message>
        <source>Add Point to Edge</source>
        <translation>Thêm điểm vào cạnh</translation>
    </message>
    <message>
        <source>Insert a new point at the hovered polygon edge</source>
        <translation>Chèn điểm mới vào cạnh đa giác đang trỏ tới</translation>
    </message>
    <message>
        <source>&amp;Keep Previous Zoom</source>
        <translation>Giữ &amp;Mức Phóng to Trước đó</translation>
    </message>
    <message>
        <source>Permanently delete this label file? This action cannot be undone.</source>
        <translation>Xóa vĩnh viễn tệp nhãn này? Hành động này không thể hoàn tác.</translation>
    </message>
    <message>
        <source>Allowed formats: {formats}</source>
        <translation>Định dạng cho phép: {formats}</translation>
    </message>
    <message>
        <source>The selected label file could not be opened: {path}</source>
        <translation>Không thể mở tệp nhãn đã chọn: {path}</translation>
    </message>
    <message>
        <source>The selected image file could not be opened: {path}</source>
        <translation>Không thể mở tệp ảnh đã chọn: {path}</translation>
    </message>
    <message>
        <source>Failed to load: {path}</source>
        <translation>Không thể tải: {path}</translation>
    </message>
    <message>
        <source>Oriented Rectangle</source>
        <translation>Hình chữ nhật có hướng</translation>
    </message>
    <message>
        <source>Start drawing oriented rectangles</source>
        <translation>Bắt đầu vẽ hình chữ nhật có hướng</translation>
    </message>
    <message>
        <source>AI inference produced no new annotation.</source>
        <translation>Suy luận AI không tạo ra chú thích mới nào.</translation>
    </message>
    <message>
        <source>Shape had no area; nothing created.</source>
        <translation>Hình không có diện tích; không có gì được tạo.</translation>
    </message>
    <message>
        <source>Settings…</source>
        <translation>Cài đặt…</translation>
    </message>
    <message>
        <source>Edit settings</source>
        <translation>Chỉnh sửa cài đặt</translation>
    </message>
    <message>
        <source>Settings are managed via --config for this session</source>
        <translation>Cài đặt được quản lý qua --config trong phiên này</translation>
    </message>
    <message>
        <source>Configuration Error</source>
        <translation>Lỗi Cấu hình</translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <source>Color theme</source>
        <translation>Chủ đề màu</translation>
    </message>
    <message>
        <source>System</source>
        <translation>Hệ thống</translation>
    </message>
    <message>
        <source>Light</source>
        <translation>Sáng</translation>
    </message>
    <message>
        <source>Dark</source>
        <translation>Tối</translation>
    </message>
    <message>
        <source>Show label popup on new shape</source>
        <translation>Hiển thị cửa sổ nhãn khi tạo hình dạng mới</translation>
    </message>
    <message>
        <source>Show shape labels on canvas</source>
        <translation>Hiển thị nhãn của hình dạng trên canvas</translation>
    </message>
    <message>
        <source>Allow points outside the image boundary</source>
        <translation>Cho phép các điểm nằm ngoài ranh giới ảnh</translation>
    </message>
    <message>
        <source>Appearance and language</source>
        <translation>Giao diện và ngôn ngữ</translation>
    </message>
    <message>
        <source>Files and saving</source>
        <translation>Tệp và lưu</translation>
    </message>
    <message>
        <source>Drawing and canvas</source>
        <translation>Vẽ và canvas</translation>
    </message>
    <message>
        <source>Continue between images</source>
        <translation>Tiếp tục giữa các ảnh</translation>
    </message>
    <message>
        <source>Label sources</source>
        <translation>Nguồn nhãn</translation>
    </message>
    <message>
        <source>Label behavior</source>
        <translation>Hành vi nhãn</translation>
    </message>
    <message>
        <source>AI assist</source>
        <translation>Hỗ trợ AI</translation>
    </message>
    <message>
        <source>Save automatically</source>
        <translation>Tự động lưu</translation>
    </message>
    <message>
        <source>Save image data in label file</source>
        <translation>Lưu dữ liệu hình ảnh trong tệp nhãn</translation>
    </message>
    <message>
        <source>Embeds the image in the label JSON file.</source>
        <translation>Nhúng hình ảnh vào tệp JSON nhãn.</translation>
    </message>
    <message>
        <source>Shape Color Mode</source>
        <translation>Chế độ màu hình dạng</translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation>Tự động</translation>
    </message>
    <message>
        <source>Uniform</source>
        <translation>Đồng nhất</translation>
    </message>
    <message>
        <source>By Label</source>
        <translation>Theo nhãn</translation>
    </message>
    <message>
        <source>Automatic palette shift</source>
        <translation>Dịch bảng màu tự động</translation>
    </message>
    <message>
        <source>Uniform mode color</source>
        <translation>Màu của chế độ Đồng nhất</translation>
    </message>
    <message>
        <source>By Label fallback color</source>
        <translation>Màu dự phòng của chế độ Theo nhãn</translation>
    </message>
    <message>
        <source>Individual Label colors remain editable in the Config File.</source>
        <translation>Màu của từng nhãn vẫn có thể chỉnh sửa trong Tệp cấu hình.</translation>
    </message>
    <message>
        <source>Keep previous annotation</source>
        <translation>Giữ chú thích trước đó</translation>
    </message>
    <message>
        <source>Keep previous zoom</source>
        <translation>Giữ mức thu phóng trước đó</translation>
    </message>
    <message>
        <source>Keep previous brightness/contrast</source>
        <translation>Giữ độ sáng/độ tương phản trước đó</translation>
    </message>
    <message>
        <source>Fill polygon while drawing</source>
        <translation>Tô đa giác khi vẽ</translation>
    </message>
    <message>
        <source>Let shape points extend beyond the image, e.g. for partially visible objects.</source>
        <translation>Cho phép các điểm của hình vượt ra ngoài ảnh, ví dụ cho các đối tượng hiển thị một phần.</translation>
    </message>
    <message>
        <source>Polygon detail</source>
        <translation>Độ chi tiết đa giác</translation>
    </message>
    <message>
        <source>Higher values preserve more Mask boundary detail and smaller lands.</source>
        <translation>Giá trị cao hơn giữ lại nhiều chi tiết đường biên mặt nạ và các vùng nhỏ hơn.</translation>
    </message>
    <message>
        <source>Predefined labels</source>
        <translation>Nhãn định sẵn</translation>
    </message>
    <message>
        <source>Label validation</source>
        <translation>Kiểm tra nhãn</translation>
    </message>
    <message>
        <source>Sort labels</source>
        <translation>Sắp xếp nhãn</translation>
    </message>
    <message>
        <source>Sort the label list alphabetically instead of keeping the provided order.</source>
        <translation>Sắp xếp danh sách nhãn theo thứ tự bảng chữ cái thay vì giữ nguyên thứ tự đã cung cấp.</translation>
    </message>
    <message>
        <source>Show label text field</source>
        <translation>Hiển thị trường văn bản nhãn</translation>
    </message>
    <message>
        <source>Label completion</source>
        <translation>Tự động hoàn thành nhãn</translation>
    </message>
    <message>
        <source>Starts with</source>
        <translation>Bắt đầu bằng</translation>
    </message>
    <message>
        <source>Contains</source>
        <translation>Chứa</translation>
    </message>
    <message>
        <source>Default model</source>
        <translation>Mô hình mặc định</translation>
    </message>
    <message>
        <source>EfficientSam (speed)</source>
        <translation>EfficientSam (tốc độ)</translation>
    </message>
    <message>
        <source>EfficientSam (accuracy)</source>
        <translation>EfficientSam (độ chính xác)</translation>
    </message>
    <message>
        <source>Sam (speed)</source>
        <translation>Sam (tốc độ)</translation>
    </message>
    <message>
        <source>Sam (balanced)</source>
        <translation>Sam (cân bằng)</translation>
    </message>
    <message>
        <source>Sam (accuracy)</source>
        <translation>Sam (độ chính xác)</translation>
    </message>
    <message>
        <source>Sam2 (speed)</source>
        <translation>Sam2 (tốc độ)</translation>
    </message>
    <message>
        <source>Sam2 (balanced)</source>
        <translation>Sam2 (cân bằng)</translation>
    </message>
    <message>
        <source>Sam2 (accuracy)</source>
        <translation>Sam2 (độ chính xác)</translation>
    </message>
    <message>
        <source>Sam3</source>
        <translation>Sam3</translation>
    </message>
    <message>
        <source>Suppress existing Shape matches</source>
        <translation>Chặn các kết quả trùng với hình dạng hiện có</translation>
    </message>
    <message>
        <source>When an AI Assist candidate matches an existing Shape, highlight that Shape instead of creating a new Shape.</source>
        <translation>Khi một kết quả của Hỗ trợ AI trùng với hình dạng hiện có, hình dạng đó sẽ được làm nổi bật thay vì tạo hình dạng mới.</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Cài đặt</translation>
    </message>
    <message>
        <source>Open config file as text…</source>
        <translation>Mở tệp cấu hình dưới dạng văn bản…</translation>
    </message>
    <message>
        <source>Edits made in the text file apply after restart</source>
        <translation>Chỉnh sửa trong tệp văn bản sẽ áp dụng sau khi khởi động lại</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Đóng</translation>
    </message>
    <message>
        <source>BETA</source>
        <translation>BETA</translation>
    </message>
    <message>
        <source>(none)</source>
        <translation>(không có)</translation>
    </message>
    <message>
        <source>one item per line</source>
        <translation>mỗi dòng một mục</translation>
    </message>
    <message>
        <source>Configuration Error</source>
        <translation>Lỗi Cấu hình</translation>
    </message>
    <message>
        <source>Predefined labels cannot be empty while Label validation is set to exact. Disable exact validation first.</source>
        <translation>Nhãn định sẵn không được để trống khi kiểm tra nhãn được đặt thành &apos;exact&apos;. Vui lòng tắt kiểm tra &apos;exact&apos; trước.</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Ngôn ngữ</translation>
    </message>
    <message>
        <source>Takes effect after restart.</source>
        <translation>Có hiệu lực sau khi khởi động lại.</translation>
    </message>
    <message>
        <source>System default</source>
        <translation>Mặc định của hệ thống</translation>
    </message>
    <message>
        <source>Predefined image flags</source>
        <translation>Cờ hình ảnh định sẵn</translation>
    </message>
</context>
<context>
    <name>_ColorSwatchButton</name>
    <message>
        <source>RGB: {red}, {green}, {blue}</source>
        <translation>RGB: {red}, {green}, {blue}</translation>
    </message>
</context>
<context>
    <name>_SettingsPage</name>
    <message>
        <source>Settings sections</source>
        <translation>Các phần cài đặt</translation>
    </message>
</context>
</TS>
