<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
<context>
    <name>AiAssistedAnnotationWidget</name>
    <message>
        <source>AI-Assisted Annotation</source>
        <translation>KI-gestützte Annotation</translation>
    </message>
    <message>
        <source>AI suggests annotation in &apos;AI-Points&apos; and &apos;AI-Box&apos; modes</source>
        <translation>AI schlägt Annotationen in den Modi &apos;AI-Points&apos; und &apos;AI-Box&apos; vor</translation>
    </message>
    <message>
        <source>Polygon detail</source>
        <translation>Polygondetails</translation>
    </message>
    <message>
        <source>Adjust polygon detail</source>
        <translation>Polygondetails anpassen</translation>
    </message>
    <message>
        <source>Smoother</source>
        <translation>Glatter</translation>
    </message>
    <message>
        <source>More detail</source>
        <translation>Mehr Details</translation>
    </message>
    <message>
        <source>Select &apos;AI-Points&apos; or &apos;AI-Box&apos; mode to enable AI-Assisted Annotation</source>
        <translation>Wählen Sie den Modus &apos;AI-Points&apos; oder &apos;AI-Box&apos;, um die KI-gestützte Annotation zu aktivieren</translation>
    </message>
</context>
<context>
    <name>AiTextToAnnotationWidget</name>
    <message>
        <source>AI Text-to-Annotation</source>
        <translation>KI-Prompt</translation>
    </message>
    <message>
        <source>e.g., dog,cat,bird</source>
        <translation>z.B. Hund,Katze,Vogel</translation>
    </message>
    <message>
        <source>Run</source>
        <translation>Ausführen</translation>
    </message>
    <message>
        <source>Score</source>
        <translation>Score</translation>
    </message>
    <message>
        <source>IoU</source>
        <translation>IoU</translation>
    </message>
    <message>
        <source>AI creates annotations from the text prompt</source>
        <translation>KI erstellt Annotationen aus dem Textprompt</translation>
    </message>
    <message>
        <source>Select &apos;Polygon&apos;, &apos;Rectangle&apos;, or &apos;AI-Points&apos; mode to enable</source>
        <translation>&apos;Polygon&apos;-, &apos;Rectangle&apos;- oder &apos;AI-Points&apos;-Modus auswählen zum Aktivieren</translation>
    </message>
</context>
<context>
    <name>BrightnessContrastDialog</name>
    <message>
        <source>Brightness/Contrast</source>
        <translation>Helligkeit/Kontrast</translation>
    </message>
    <message>
        <source>Brightness:</source>
        <translation>Helligkeit:</translation>
    </message>
    <message>
        <source>Contrast:</source>
        <translation>Kontrast:</translation>
    </message>
</context>
<context>
    <name>Canvas</name>
    <message>
        <source>Creating %r</source>
        <translation>%r wird erstellt</translation>
    </message>
    <message>
        <source>ESC to cancel</source>
        <translation>ESC zum Abbrechen</translation>
    </message>
    <message>
        <source>Enter or Space to finalize</source>
        <translation>Enter oder Leertaste zum Abschließen</translation>
    </message>
    <message>
        <source>Editing shapes</source>
        <translation>Formen bearbeiten</translation>
    </message>
    <message>
        <source>Click start point for line</source>
        <translation>Startpunkt der Linie anklicken</translation>
    </message>
    <message>
        <source>Click end point for line</source>
        <translation>Endpunkt der Linie anklicken</translation>
    </message>
    <message>
        <source>Click start point for linestrip</source>
        <translation>Startpunkt der Linienfolge anklicken</translation>
    </message>
    <message>
        <source>Click next point or finish by Ctrl/Cmd+Click for linestrip</source>
        <translation>Nächsten Punkt anklicken oder mit Ctrl/Cmd+Klick abschließen (Linienfolge)</translation>
    </message>
    <message>
        <source>Click center point for circle</source>
        <translation>Mittelpunkt des Kreises anklicken</translation>
    </message>
    <message>
        <source>Click point on circumference for circle</source>
        <translation>Punkt auf dem Kreisumfang anklicken</translation>
    </message>
    <message>
        <source>Click first corner for rectangle</source>
        <translation>Erste Ecke des Rechtecks anklicken</translation>
    </message>
    <message>
        <source>Click to add point</source>
        <translation>Klicken zum Hinzufügen eines Punktes</translation>
    </message>
    <message>
        <source>Click &amp; drag to move point</source>
        <translation>Klicken und ziehen zum Verschieben des Punktes</translation>
    </message>
    <message>
        <source>ALT + SHIFT + Click to delete point</source>
        <translation>ALT + SHIFT + Klick zum Löschen des Punktes</translation>
    </message>
    <message>
        <source>ALT + Click to create point on shape</source>
        <translation>ALT + Klick zum Erstellen eines Punktes auf der Form</translation>
    </message>
    <message>
        <source>Click &amp; drag to move shape</source>
        <translation>Klicken und ziehen zum Verschieben der Form</translation>
    </message>
    <message>
        <source>Right-click &amp; drag to copy shape</source>
        <translation>Rechtsklick und Ziehen, um die Form zu kopieren</translation>
    </message>
    <message>
        <source>Click opposite corner for rectangle (Shift for square)</source>
        <translation>Gegenüberliegende Ecke des Rechtecks anklicken (Shift für Quadrat)</translation>
    </message>
    <message>
        <source>Click points to include or Shift+Click to exclude. Ctrl+LeftClick ends creation.</source>
        <translation>Punkte anklicken zum Einschließen oder Shift+Click zum Ausschließen. Ctrl+LeftClick beendet die Erstellung.</translation>
    </message>
    <message>
        <source>Click first corner of bbox for AI segmentation</source>
        <translation>Erste Ecke der bbox für AI-Segmentierung anklicken</translation>
    </message>
    <message>
        <source>Click opposite corner to segment object</source>
        <translation>Gegenüberliegende Ecke anklicken, um Objekt zu segmentieren</translation>
    </message>
    <message>
        <source>Click first corner for oriented rectangle</source>
        <translation>Erste Ecke des orientierten Rechtecks anklicken</translation>
    </message>
    <message>
        <source>Click second corner to set orientation</source>
        <translation>Zweite Ecke anklicken, um die Ausrichtung festzulegen</translation>
    </message>
    <message>
        <source>Click third corner to close oriented rectangle</source>
        <translation>Dritte Ecke anklicken, um das orientierte Rechteck zu schließen</translation>
    </message>
    <message>
        <source>Click &amp; drag to rotate the shape</source>
        <translation>Klicken und ziehen zum Drehen der Form</translation>
    </message>
</context>
<context>
    <name>EmptyStateWidget</name>
    <message>
        <source>Start annotating</source>
        <translation>Annotation starten</translation>
    </message>
    <message>
        <source>Open an image or a directory of images to begin.</source>
        <translation>Öffnen Sie zunächst ein Bild oder einen Ordner mit Bildern.</translation>
    </message>
    <message>
        <source>Open Image</source>
        <translation>Bild öffnen</translation>
    </message>
    <message>
        <source>Open Directory</source>
        <translation>Ordner öffnen</translation>
    </message>
    <message>
        <source>Or drag and drop image files here</source>
        <translation>Oder Bilddateien hierher ziehen und ablegen</translation>
    </message>
</context>
<context>
    <name>LabelDialog</name>
    <message>
        <source>Shape Label</source>
        <translation>Formlabel</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Label</translation>
    </message>
    <message>
        <source>Group ID</source>
        <translation>Gruppen-ID</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Beschreibung</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Flags</source>
        <translation>Markierungen</translation>
    </message>
    <message>
        <source>Shape List</source>
        <translation>Formenliste</translation>
    </message>
    <message>
        <source>Select label to start annotating for it. Press &apos;Esc&apos; to deselect.</source>
        <translation>Label auswählen, um mit der Annotation zu beginnen. Mit &apos;Esc&apos; abwählen.</translation>
    </message>
    <message>
        <source>Label List</source>
        <translation>Label-Liste</translation>
    </message>
    <message>
        <source>Search Filename</source>
        <translation>Dateiname suchen</translation>
    </message>
    <message>
        <source>File List</source>
        <translation>Dateiliste</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation>&amp;Beenden</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>Anwendung beenden</translation>
    </message>
    <message>
        <source>&amp;Open
</source>
        <translation>&amp;Öffnen
</translation>
    </message>
    <message>
        <source>Open image or label file</source>
        <translation>Bild- oder Label-Datei öffnen</translation>
    </message>
    <message>
        <source>Open Dir</source>
        <translation>Verzeichnis öffnen</translation>
    </message>
    <message>
        <source>&amp;Next Image</source>
        <translation>&amp;Nächstes Bild</translation>
    </message>
    <message>
        <source>Open next (hold Ctl+Shift to copy labels)</source>
        <translation>Nächstes öffnen (Strg+Umschalt gedrückt halten, um Labels zu kopieren)</translation>
    </message>
    <message>
        <source>&amp;Prev Image</source>
        <translation>&amp;Vorheriges Bild</translation>
    </message>
    <message>
        <source>Open prev (hold Ctl+Shift to copy labels)</source>
        <translation>Vorheriges öffnen (Strg+Umschalt gedrückt halten, um Labels zu kopieren)</translation>
    </message>
    <message>
        <source>&amp;Save
</source>
        <translation>&amp;Speichern
</translation>
    </message>
    <message>
        <source>Save labels to file</source>
        <translation>Labels in Datei speichern</translation>
    </message>
    <message>
        <source>&amp;Save As</source>
        <translation>Speichern &amp;unter</translation>
    </message>
    <message>
        <source>&amp;Delete File</source>
        <translation>&amp;Datei löschen</translation>
    </message>
    <message>
        <source>Delete current label file</source>
        <translation>Aktuelle Label-Datei löschen</translation>
    </message>
    <message>
        <source>&amp;Change Output Dir</source>
        <translation>&amp;Ausgabeverzeichnis ändern</translation>
    </message>
    <message>
        <source>Change where annotations are loaded/saved</source>
        <translation>Ändern, wo Annotationen geladen/gespeichert werden</translation>
    </message>
    <message>
        <source>Save &amp;Automatically</source>
        <translation>&amp;Automatisch speichern</translation>
    </message>
    <message>
        <source>Save automatically</source>
        <translation>Automatisch speichern</translation>
    </message>
    <message>
        <source>Save With Image Data</source>
        <translation>Mit Bilddaten speichern</translation>
    </message>
    <message>
        <source>Save image data in label file</source>
        <translation>Bilddaten in Label-Datei speichern</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Schließen</translation>
    </message>
    <message>
        <source>Close current file</source>
        <translation>Aktuelle Datei schließen</translation>
    </message>
    <message>
        <source>Keep Previous Annotation</source>
        <translation>Vorherige Annotation beibehalten</translation>
    </message>
    <message>
        <source>Toggle &quot;keep previous annotation&quot; mode</source>
        <translation>&quot;Vorherige Annotation beibehalten&quot; Modus umschalten</translation>
    </message>
    <message>
        <source>Start drawing polygons</source>
        <translation>Mit dem Zeichnen von Polygonen beginnen</translation>
    </message>
    <message>
        <source>Start drawing rectangles</source>
        <translation>Mit dem Zeichnen von Rechtecken beginnen</translation>
    </message>
    <message>
        <source>Start drawing circles</source>
        <translation>Mit dem Zeichnen von Kreisen beginnen</translation>
    </message>
    <message>
        <source>Start drawing lines</source>
        <translation>Mit dem Zeichnen von Linien beginnen</translation>
    </message>
    <message>
        <source>Start drawing points</source>
        <translation>Mit dem Zeichnen von Punkten beginnen</translation>
    </message>
    <message>
        <source>Edit Shapes</source>
        <translation>Formen bearbeiten</translation>
    </message>
    <message>
        <source>Move and edit the selected shapes</source>
        <translation>Ausgewählte Formen verschieben und bearbeiten</translation>
    </message>
    <message>
        <source>Delete Shapes</source>
        <translation>Formen löschen</translation>
    </message>
    <message>
        <source>Delete the selected shapes</source>
        <translation>Ausgewählte Formen löschen</translation>
    </message>
    <message>
        <source>Duplicate Shapes</source>
        <translation>Formen duplizieren</translation>
    </message>
    <message>
        <source>Create a duplicate of the selected shapes</source>
        <translation>Duplikat der ausgewählten Formen erstellen</translation>
    </message>
    <message>
        <source>Undo last point</source>
        <translation>Letzten Punkt rückgängig machen</translation>
    </message>
    <message>
        <source>Undo last drawn point</source>
        <translation>Letzten gezeichneten Punkt rückgängig machen</translation>
    </message>
    <message>
        <source>Remove Selected Point</source>
        <translation>Ausgewählten Punkt entfernen</translation>
    </message>
    <message>
        <source>Remove selected point from polygon</source>
        <translation>Ausgewählten Punkt aus Polygon entfernen</translation>
    </message>
    <message>
        <source>Undo
</source>
        <translation>Rückgängig
</translation>
    </message>
    <message>
        <source>Undo last add and edit of shape</source>
        <translation>Letztes Hinzufügen und Bearbeiten der Form rückgängig machen</translation>
    </message>
    <message>
        <source>&amp;Hide
Shapes</source>
        <translation>&amp;Verbergen
Formen</translation>
    </message>
    <message>
        <source>Hide all shapes</source>
        <translation>Alle Formen verbergen</translation>
    </message>
    <message>
        <source>&amp;Show
Shapes</source>
        <translation>&amp;Anzeigen
Formen</translation>
    </message>
    <message>
        <source>Show all shapes</source>
        <translation>Alle Formen anzeigen</translation>
    </message>
    <message>
        <source>&amp;Toggle
Shapes</source>
        <translation>&amp;Umschalten
Formen</translation>
    </message>
    <message>
        <source>Toggle all shapes</source>
        <translation>Alle Formen umschalten</translation>
    </message>
    <message>
        <source>&amp;Tutorial</source>
        <translation>&amp;Tutorial</translation>
    </message>
    <message>
        <source>Show tutorial page</source>
        <translation>Tutorial-Seite anzeigen</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation>Zoom</translation>
    </message>
    <message>
        <source>Zoom &amp;In</source>
        <translation>&amp;Vergrößern</translation>
    </message>
    <message>
        <source>&amp;Zoom Out</source>
        <translation>&amp;Verkleinern</translation>
    </message>
    <message>
        <source>&amp;Brightness Contrast</source>
        <translation>&amp;Helligkeit/Kontrast</translation>
    </message>
    <message>
        <source>Adjust brightness and contrast</source>
        <translation>Helligkeit und Kontrast einstellen</translation>
    </message>
    <message>
        <source>&amp;Edit Label</source>
        <translation>&amp;Label bearbeiten</translation>
    </message>
    <message>
        <source>Modify the label of the selected shape</source>
        <translation>Label der ausgewählten Form ändern</translation>
    </message>
    <message>
        <source>Fill Drawing Polygon</source>
        <translation>Gezeichnetes Polygon füllen</translation>
    </message>
    <message>
        <source>Fill polygon while drawing</source>
        <translation>Polygon beim Zeichnen füllen</translation>
    </message>
    <message>
        <source>Keep Previous Brightness/Contrast</source>
        <translation>Vorherige Helligkeit/Kontrast beibehalten</translation>
    </message>
    <message>
        <source>Save the labels under a new file name</source>
        <translation>Labels unter einem neuen Dateinamen speichern</translation>
    </message>
    <message>
        <source>Copy to Clipboard</source>
        <translation>In Zwischenablage kopieren</translation>
    </message>
    <message>
        <source>Place the selected shapes on the clipboard</source>
        <translation>Ausgewählte Formen in die Zwischenablage legen</translation>
    </message>
    <message>
        <source>Paste from Clipboard</source>
        <translation>Aus Zwischenablage einfügen</translation>
    </message>
    <message>
        <source>Insert the clipboard shapes into this image</source>
        <translation>Formen aus der Zwischenablage in dieses Bild einfügen</translation>
    </message>
    <message>
        <source>Click to place linestrip points; Ctrl+click places the last one.</source>
        <translation>Klicken, um Punkte der Linienfolge zu setzen; Strg+Klick setzt den letzten.</translation>
    </message>
    <message>
        <source>Fit to &amp;Window</source>
        <translation>&amp;An Fenster anpassen</translation>
    </message>
    <message>
        <source>Keep the whole image visible when the window is resized</source>
        <translation>Das ganze Bild sichtbar halten, wenn die Fenstergröße geändert wird</translation>
    </message>
    <message>
        <source>Fit to Wi&amp;dth</source>
        <translation>&amp;An Breite anpassen</translation>
    </message>
    <message>
        <source>Match the image width to the window when it is resized</source>
        <translation>Die Bildbreite an das Fenster angleichen, wenn dessen Größe geändert wird</translation>
    </message>
    <message>
        <source>Make the image appear larger</source>
        <translation>Das Bild größer anzeigen</translation>
    </message>
    <message>
        <source>Make the image appear smaller</source>
        <translation>Das Bild kleiner anzeigen</translation>
    </message>
    <message>
        <source>&amp;Actual Size</source>
        <translation>&amp;Originalgröße</translation>
    </message>
    <message>
        <source>Show the image at 100%</source>
        <translation>Das Bild bei 100 % anzeigen</translation>
    </message>
    <message>
        <source>Ctrl+Wheel zooms the canvas</source>
        <translation>Strg+Mausrad zoomt die Leinwand</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Datei</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Bearbeiten</translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation>&amp;Ansicht</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Hilfe</translation>
    </message>
    <message>
        <source>%s started.</source>
        <translation>%s gestartet.</translation>
    </message>
    <message>
        <source>Mask Output Unavailable</source>
        <translation>Maskenausgabe nicht verfügbar</translation>
    </message>
    <message>
        <source>%s only detects bounding boxes and cannot create &apos;%s&apos; annotations.

Switch the AI Text-to-Annotation model to &apos;SAM3 (smart)&apos;, or set the output format to &apos;Rectangle&apos;.</source>
        <translation>%s erkennt nur Begrenzungsrahmen und kann keine &apos;%s&apos;-Annotationen erstellen.

Wechseln Sie das AI Text-to-Annotation-Modell zu &apos;SAM3 (smart)&apos; oder stellen Sie das Ausgabeformat auf &apos;Rectangle&apos; ein.</translation>
    </message>
    <message>
        <source>Invalid label</source>
        <translation>Ungültiges Label</translation>
    </message>
    <message>
        <source>Invalid label &apos;{}&apos; with validation type &apos;{}&apos;</source>
        <translation>Ungültiges Label &apos;{}&apos; mit Validierungstyp &apos;{}&apos;</translation>
    </message>
    <message>
        <source>Error saving label data</source>
        <translation>Fehler beim Speichern der Labeldaten</translation>
    </message>
    <message>
        <source>&lt;b&gt;%s&lt;/b&gt;</source>
        <translation>&lt;b&gt;%s&lt;/b&gt;</translation>
    </message>
    <message>
        <source>AI inference failed: %s</source>
        <translation>KI-Inferenz fehlgeschlagen: %s</translation>
    </message>
    <message>
        <source>Error opening file</source>
        <translation>Fehler beim Öffnen der Datei</translation>
    </message>
    <message>
        <source>No such file: &lt;b&gt;%s&lt;/b&gt;</source>
        <translation>Datei nicht gefunden: &lt;b&gt;%s&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Loading %s...</source>
        <translation>%s wird geladen...</translation>
    </message>
    <message>
        <source>Loaded %s</source>
        <translation>%s geladen</translation>
    </message>
    <message>
        <source>Image &amp; Label files (%s)</source>
        <translation>Bild- und Label-Dateien (%s)</translation>
    </message>
    <message>
        <source>%s - Choose Image or Label file</source>
        <translation>%s - Bild- oder Label-Datei auswählen</translation>
    </message>
    <message>
        <source>%s - Save/Load Annotations in Directory</source>
        <translation>%s - Annotationen im Verzeichnis speichern/laden</translation>
    </message>
    <message>
        <source>%s . Annotations will be saved/loaded in %s</source>
        <translation>%s . Annotationen werden in %s gespeichert/geladen</translation>
    </message>
    <message>
        <source>%s - Choose File</source>
        <translation>%s - Datei auswählen</translation>
    </message>
    <message>
        <source>Label files (*%s)</source>
        <translation>Label-Dateien (*%s)</translation>
    </message>
    <message>
        <source>Choose File</source>
        <translation>Datei auswählen</translation>
    </message>
    <message>
        <source>Attention</source>
        <translation>Achtung</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Löschen</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Unavailable in AI-Points mode because this model does not support point prompts.</source>
        <translation>Im AI-Points-Modus nicht verfügbar, da dieses Modell keine Punkt-Prompts unterstützt.</translation>
    </message>
    <message>
        <source>Save annotations to &quot;{}&quot; before closing?</source>
        <translation>Annotationen in &quot;{}&quot; speichern vor dem Schließen?</translation>
    </message>
    <message>
        <source>Save annotations?</source>
        <translation>Annotationen speichern?</translation>
    </message>
    <message>
        <source>Delete {} shapes? You can restore them with Undo.</source>
        <translation>{} Formen löschen? Sie können sie mit „Rückgängig“ wiederherstellen.</translation>
    </message>
    <message>
        <source>%s - Open Directory</source>
        <translation>%s - Verzeichnis öffnen</translation>
    </message>
    <message>
        <source>The image is too large to open: {width}x{height} pixels exceeds the {max_side} pixel per-side limit of the raster engine. Raising the decode limit will not help. Split the image into tiles (for example with gdal_retile.py) or open a smaller copy.</source>
        <translation>Das Bild ist zu groß zum Öffnen: {width}x{height} Pixel überschreiten das Limit von {max_side} Pixeln pro Seite der Raster-Engine. Das Erhöhen des Dekodierlimits hilft nicht. Teilen Sie das Bild in Kacheln auf (zum Beispiel mit gdal_retile.py) oder öffnen Sie eine kleinere Kopie.</translation>
    </message>
    <message>
        <source>The image is too large to open: {width}x{height} pixels needs about {required} MB, but the decode limit is {limit} MB. Split the image into tiles (for example with gdal_retile.py) or open a smaller copy.</source>
        <translation>Das Bild ist zu groß zum Öffnen: {width}x{height} Pixel benötigen etwa {required} MB, aber das Dekodierlimit beträgt {limit} MB. Teilen Sie das Bild in Kacheln auf (zum Beispiel mit gdal_retile.py) oder öffnen Sie eine kleinere Kopie.</translation>
    </message>
    <message>
        <source>Configuration Errors</source>
        <translation>Konfigurationsfehler</translation>
    </message>
    <message>
        <source>Errors were found while loading the configuration. Please review the errors below and reload your configuration or ignore the erroneous lines.</source>
        <translation>Beim Laden der Konfiguration wurden Fehler gefunden. Bitte überprüfen Sie die folgenden Fehler und laden Sie Ihre Konfiguration neu oder ignorieren Sie die fehlerhaften Zeilen.</translation>
    </message>
    <message>
        <source>Reset Layout</source>
        <translation>Layout zurücksetzen</translation>
    </message>
    <message>
        <source>Polygon</source>
        <translation>Polygon</translation>
    </message>
    <message>
        <source>Rectangle</source>
        <translation>Rechteck</translation>
    </message>
    <message>
        <source>Circle</source>
        <translation>Kreis</translation>
    </message>
    <message>
        <source>Line</source>
        <translation>Linie</translation>
    </message>
    <message>
        <source>Point</source>
        <translation>Punkt</translation>
    </message>
    <message>
        <source>LineStrip</source>
        <translation>Linienfolge</translation>
    </message>
    <message>
        <source>AI-Points</source>
        <translation>AI-Points</translation>
    </message>
    <message>
        <source>Click points to segment object. Ctrl+LeftClick ends creation.</source>
        <translation>Punkte anklicken, um Objekt zu segmentieren. Ctrl+LeftClick beendet die Erstellung.</translation>
    </message>
    <message>
        <source>AI-Box</source>
        <translation>AI-Box</translation>
    </message>
    <message>
        <source>Draw a bounding box to segment object.</source>
        <translation>Einen Begrenzungsrahmen zeichnen, um Objekt zu segmentieren.</translation>
    </message>
    <message>
        <source>AI-Points Unavailable</source>
        <translation>AI-Points nicht verfügbar</translation>
    </message>
    <message>
        <source>%s does not support point prompts.
Please select a different model or use AI-Box mode.</source>
        <translation>%s unterstützt keine Punkt-Eingaben.
Bitte wählen Sie ein anderes Modell oder verwenden Sie den AI-Box-Modus.</translation>
    </message>
    <message>
        <source>File list is disabled when a label file is opened</source>
        <translation>Die Dateiliste ist deaktiviert, wenn eine Label-Datei geöffnet ist</translation>
    </message>
    <message>
        <source>Add Point to Edge</source>
        <translation>Punkt zur Kante hinzufügen</translation>
    </message>
    <message>
        <source>Insert a new point at the hovered polygon edge</source>
        <translation>Neuen Punkt an der ausgewählten Polygonkante einfügen</translation>
    </message>
    <message>
        <source>&amp;Keep Previous Zoom</source>
        <translation>&amp;Vorherigen Zoom beibehalten</translation>
    </message>
    <message>
        <source>Permanently delete this label file? This action cannot be undone.</source>
        <translation>Diese Label-Datei endgültig löschen? Diese Aktion kann nicht rückgängig gemacht werden.</translation>
    </message>
    <message>
        <source>Allowed formats: {formats}</source>
        <translation>Erlaubte Formate: {formats}</translation>
    </message>
    <message>
        <source>The selected label file could not be opened: {path}</source>
        <translation>Die ausgewählte Label-Datei konnte nicht geöffnet werden: {path}</translation>
    </message>
    <message>
        <source>The selected image file could not be opened: {path}</source>
        <translation>Die ausgewählte Bilddatei konnte nicht geöffnet werden: {path}</translation>
    </message>
    <message>
        <source>Failed to load: {path}</source>
        <translation>Laden fehlgeschlagen: {path}</translation>
    </message>
    <message>
        <source>Oriented Rectangle</source>
        <translation>Orientiertes Rechteck</translation>
    </message>
    <message>
        <source>Start drawing oriented rectangles</source>
        <translation>Mit dem Zeichnen von orientierten Rechtecken beginnen</translation>
    </message>
    <message>
        <source>AI inference produced no new annotation.</source>
        <translation>KI-Inferenz hat keine neue Annotation erzeugt.</translation>
    </message>
    <message>
        <source>Shape had no area; nothing created.</source>
        <translation>Form hat keine Fläche – nichts wurde erstellt.</translation>
    </message>
    <message>
        <source>Settings…</source>
        <translation>Einstellungen…</translation>
    </message>
    <message>
        <source>Edit settings</source>
        <translation>Einstellungen bearbeiten</translation>
    </message>
    <message>
        <source>Settings are managed via --config for this session</source>
        <translation>Einstellungen werden für diese Sitzung über --config verwaltet</translation>
    </message>
    <message>
        <source>Configuration Error</source>
        <translation>Konfigurationsfehler</translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <source>Color theme</source>
        <translation>Farbschema</translation>
    </message>
    <message>
        <source>System</source>
        <translation>System</translation>
    </message>
    <message>
        <source>Light</source>
        <translation>Hell</translation>
    </message>
    <message>
        <source>Dark</source>
        <translation>Dunkel</translation>
    </message>
    <message>
        <source>Show label popup on new shape</source>
        <translation>Label-Eingabe bei neuer Form anzeigen</translation>
    </message>
    <message>
        <source>Show shape labels on canvas</source>
        <translation>Formlabels auf der Leinwand anzeigen</translation>
    </message>
    <message>
        <source>Allow points outside the image boundary</source>
        <translation>Punkte außerhalb der Bildgrenzen zulassen</translation>
    </message>
    <message>
        <source>Appearance and language</source>
        <translation>Erscheinungsbild und Sprache</translation>
    </message>
    <message>
        <source>Files and saving</source>
        <translation>Dateien und Speichern</translation>
    </message>
    <message>
        <source>Drawing and canvas</source>
        <translation>Zeichnen und Leinwand</translation>
    </message>
    <message>
        <source>Continue between images</source>
        <translation>Zwischen Bildern fortfahren</translation>
    </message>
    <message>
        <source>Label sources</source>
        <translation>Label-Quellen</translation>
    </message>
    <message>
        <source>Label behavior</source>
        <translation>Label-Verhalten</translation>
    </message>
    <message>
        <source>AI assist</source>
        <translation>KI-Unterstützung</translation>
    </message>
    <message>
        <source>Save automatically</source>
        <translation>Automatisch speichern</translation>
    </message>
    <message>
        <source>Save image data in label file</source>
        <translation>Bilddaten in Label-Datei speichern</translation>
    </message>
    <message>
        <source>Embeds the image in the label JSON file.</source>
        <translation>Bettet das Bild in die Label-JSON-Datei ein.</translation>
    </message>
    <message>
        <source>Shape Color Mode</source>
        <translation>Formfarbenmodus</translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation>Automatisch</translation>
    </message>
    <message>
        <source>Uniform</source>
        <translation>Einheitlich</translation>
    </message>
    <message>
        <source>By Label</source>
        <translation>Nach Label</translation>
    </message>
    <message>
        <source>Automatic palette shift</source>
        <translation>Automatische Palettenverschiebung</translation>
    </message>
    <message>
        <source>Uniform mode color</source>
        <translation>Farbe im Modus „Einheitlich“</translation>
    </message>
    <message>
        <source>By Label fallback color</source>
        <translation>Ausweichfarbe im Modus „Nach Label“</translation>
    </message>
    <message>
        <source>Individual Label colors remain editable in the Config File.</source>
        <translation>Individuelle Labelfarben können weiterhin in der Konfigurationsdatei bearbeitet werden.</translation>
    </message>
    <message>
        <source>Keep previous annotation</source>
        <translation>Vorherige Annotation beibehalten</translation>
    </message>
    <message>
        <source>Keep previous zoom</source>
        <translation>Vorherigen Zoom beibehalten</translation>
    </message>
    <message>
        <source>Keep previous brightness/contrast</source>
        <translation>Vorherige Helligkeit/Kontrast beibehalten</translation>
    </message>
    <message>
        <source>Fill polygon while drawing</source>
        <translation>Polygon beim Zeichnen füllen</translation>
    </message>
    <message>
        <source>Let shape points extend beyond the image, e.g. for partially visible objects.</source>
        <translation>Erlaubt, dass Formpunkte über das Bild hinausragen, z. B. für teilweise sichtbare Objekte.</translation>
    </message>
    <message>
        <source>Polygon detail</source>
        <translation>Polygondetails</translation>
    </message>
    <message>
        <source>Higher values preserve more Mask boundary detail and smaller lands.</source>
        <translation>Höhere Werte bewahren mehr Details der Maskengrenze und kleinere Bereiche.</translation>
    </message>
    <message>
        <source>Predefined labels</source>
        <translation>Vordefinierte Labels</translation>
    </message>
    <message>
        <source>Label validation</source>
        <translation>Label-Validierung</translation>
    </message>
    <message>
        <source>Sort labels</source>
        <translation>Labels sortieren</translation>
    </message>
    <message>
        <source>Sort the label list alphabetically instead of keeping the provided order.</source>
        <translation>Sortiert die Label-Liste alphabetisch, anstatt die vorgegebene Reihenfolge beizubehalten.</translation>
    </message>
    <message>
        <source>Show label text field</source>
        <translation>Label-Textfeld anzeigen</translation>
    </message>
    <message>
        <source>Label completion</source>
        <translation>Label-Vervollständigung</translation>
    </message>
    <message>
        <source>Starts with</source>
        <translation>Beginnt mit</translation>
    </message>
    <message>
        <source>Contains</source>
        <translation>Enthält</translation>
    </message>
    <message>
        <source>Default model</source>
        <translation>Standardmodell</translation>
    </message>
    <message>
        <source>EfficientSam (speed)</source>
        <translation>EfficientSam (Geschwindigkeit)</translation>
    </message>
    <message>
        <source>EfficientSam (accuracy)</source>
        <translation>EfficientSam (Genauigkeit)</translation>
    </message>
    <message>
        <source>Sam (speed)</source>
        <translation>Sam (Geschwindigkeit)</translation>
    </message>
    <message>
        <source>Sam (balanced)</source>
        <translation>Sam (Ausgewogen)</translation>
    </message>
    <message>
        <source>Sam (accuracy)</source>
        <translation>Sam (Genauigkeit)</translation>
    </message>
    <message>
        <source>Sam2 (speed)</source>
        <translation>Sam2 (Geschwindigkeit)</translation>
    </message>
    <message>
        <source>Sam2 (balanced)</source>
        <translation>Sam2 (Ausgewogen)</translation>
    </message>
    <message>
        <source>Sam2 (accuracy)</source>
        <translation>Sam2 (Genauigkeit)</translation>
    </message>
    <message>
        <source>Sam3</source>
        <translation>Sam3</translation>
    </message>
    <message>
        <source>Suppress existing Shape matches</source>
        <translation>Übereinstimmungen mit vorhandenen Formen unterdrücken</translation>
    </message>
    <message>
        <source>When an AI Assist candidate matches an existing Shape, highlight that Shape instead of creating a new Shape.</source>
        <translation>Wenn ein Vorschlag der KI-Unterstützung mit einer vorhandenen Form übereinstimmt, wird diese Form hervorgehoben, statt eine neue Form zu erstellen.</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Einstellungen</translation>
    </message>
    <message>
        <source>Open config file as text…</source>
        <translation>Konfigurationsdatei als Text öffnen…</translation>
    </message>
    <message>
        <source>Edits made in the text file apply after restart</source>
        <translation>Änderungen in der Textdatei werden nach dem Neustart übernommen</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <source>BETA</source>
        <translation>BETA</translation>
    </message>
    <message>
        <source>(none)</source>
        <translation>(keine)</translation>
    </message>
    <message>
        <source>one item per line</source>
        <translation>ein Eintrag pro Zeile</translation>
    </message>
    <message>
        <source>Configuration Error</source>
        <translation>Konfigurationsfehler</translation>
    </message>
    <message>
        <source>Predefined labels cannot be empty while Label validation is set to exact. Disable exact validation first.</source>
        <translation>Vordefinierte Labels dürfen nicht leer sein, solange die Label-Validierung auf „exact“ gesetzt ist. Deaktivieren Sie zuerst die „exact“-Validierung.</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Sprache</translation>
    </message>
    <message>
        <source>Takes effect after restart.</source>
        <translation>Wird nach dem Neustart wirksam.</translation>
    </message>
    <message>
        <source>System default</source>
        <translation>Systemstandard</translation>
    </message>
    <message>
        <source>Predefined image flags</source>
        <translation>Vordefinierte Bild-Flags</translation>
    </message>
</context>
<context>
    <name>_ColorSwatchButton</name>
    <message>
        <source>RGB: {red}, {green}, {blue}</source>
        <translation>RGB: {red}, {green}, {blue}</translation>
    </message>
</context>
<context>
    <name>_SettingsPage</name>
    <message>
        <source>Settings sections</source>
        <translation>Einstellungsbereiche</translation>
    </message>
</context>
</TS>
