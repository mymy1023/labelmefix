<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="uk_UA">
<context>
    <name>AiAssistedAnnotationWidget</name>
    <message>
        <source>AI-Assisted Annotation</source>
        <translation>AI-анотація</translation>
    </message>
    <message>
        <source>AI suggests annotation in &apos;AI-Points&apos; and &apos;AI-Box&apos; modes</source>
        <translation>ШІ пропонує анотацію в режимах &apos;AI-Points&apos; та &apos;AI-Box&apos;</translation>
    </message>
    <message>
        <source>Polygon detail</source>
        <translation>Деталізація полігона</translation>
    </message>
    <message>
        <source>Adjust polygon detail</source>
        <translation>Налаштувати деталізацію полігона</translation>
    </message>
    <message>
        <source>Smoother</source>
        <translation>Плавніше</translation>
    </message>
    <message>
        <source>More detail</source>
        <translation>Більше деталей</translation>
    </message>
    <message>
        <source>Select &apos;AI-Points&apos; or &apos;AI-Box&apos; mode to enable AI-Assisted Annotation</source>
        <translation>Виберіть режим &apos;AI-Points&apos; або &apos;AI-Box&apos;, щоб увімкнути анотацію за допомогою ШІ</translation>
    </message>
</context>
<context>
    <name>AiTextToAnnotationWidget</name>
    <message>
        <source>AI Text-to-Annotation</source>
        <translation>AI: текст в анотацію</translation>
    </message>
    <message>
        <source>AI creates annotations from the text prompt</source>
        <translation>AI створює анотації з текстової підказки</translation>
    </message>
    <message>
        <source>e.g., dog,cat,bird</source>
        <translation>наприклад, собака, кішка, птах</translation>
    </message>
    <message>
        <source>Run</source>
        <translation>Запустити</translation>
    </message>
    <message>
        <source>Score</source>
        <translation>Оцінка</translation>
    </message>
    <message>
        <source>IoU</source>
        <translation>IoU</translation>
    </message>
    <message>
        <source>Select &apos;Polygon&apos;, &apos;Rectangle&apos;, or &apos;AI-Points&apos; mode to enable</source>
        <translation>Виберіть режим &apos;Polygon&apos;, &apos;Rectangle&apos; або &apos;AI-Points&apos;, щоб увімкнути</translation>
    </message>
</context>
<context>
    <name>BrightnessContrastDialog</name>
    <message>
        <source>Brightness/Contrast</source>
        <translation>Яскравість/Контраст</translation>
    </message>
    <message>
        <source>Brightness:</source>
        <translation>Яскравість:</translation>
    </message>
    <message>
        <source>Contrast:</source>
        <translation>Контраст:</translation>
    </message>
</context>
<context>
    <name>Canvas</name>
    <message>
        <source>Creating %r</source>
        <translation>Створення %r</translation>
    </message>
    <message>
        <source>ESC to cancel</source>
        <translation>ESC для скасування</translation>
    </message>
    <message>
        <source>Enter or Space to finalize</source>
        <translation>Enter або пробіл для завершення</translation>
    </message>
    <message>
        <source>Editing shapes</source>
        <translation>Редагування фігур</translation>
    </message>
    <message>
        <source>Click start point for line</source>
        <translation>Натисніть початкову точку лінії</translation>
    </message>
    <message>
        <source>Click end point for line</source>
        <translation>Натисніть кінцеву точку лінії</translation>
    </message>
    <message>
        <source>Click start point for linestrip</source>
        <translation>Натисніть початкову точку для лінії</translation>
    </message>
    <message>
        <source>Click next point or finish by Ctrl/Cmd+Click for linestrip</source>
        <translation>Натисніть наступну точку або завершіть через Ctrl/Cmd+Click для linestrip</translation>
    </message>
    <message>
        <source>Click center point for circle</source>
        <translation>Натисніть центральну точку для кола</translation>
    </message>
    <message>
        <source>Click point on circumference for circle</source>
        <translation>Натисніть точку на окружності для кола</translation>
    </message>
    <message>
        <source>Click first corner for rectangle</source>
        <translation>Натисніть перший кут для прямокутника</translation>
    </message>
    <message>
        <source>Click opposite corner for rectangle (Shift for square)</source>
        <translation>Натисніть протилежний кут для прямокутника (Shift для квадрата)</translation>
    </message>
    <message>
        <source>Click to add point</source>
        <translation>Натисніть, щоб додати точку</translation>
    </message>
    <message>
        <source>Click &amp; drag to move point</source>
        <translation>Натисніть і перетягніть, щоб перемістити точку</translation>
    </message>
    <message>
        <source>ALT + SHIFT + Click to delete point</source>
        <translation>ALT + SHIFT + Натисніть, щоб видалити точку</translation>
    </message>
    <message>
        <source>ALT + Click to create point on shape</source>
        <translation>ALT + Натисніть, щоб створити точку на фігурі</translation>
    </message>
    <message>
        <source>Click &amp; drag to move shape</source>
        <translation>Натисніть і перетягніть, щоб перемістити фігуру</translation>
    </message>
    <message>
        <source>Right-click &amp; drag to copy shape</source>
        <translation>Натисніть правою кнопкою миші та перетягніть, щоб скопіювати фігуру</translation>
    </message>
    <message>
        <source>Click points to include or Shift+Click to exclude. Ctrl+LeftClick ends creation.</source>
        <translation>Натисніть точки для включення або Shift+Click для виключення. Ctrl+LeftClick завершує створення.</translation>
    </message>
    <message>
        <source>Click first corner of bbox for AI segmentation</source>
        <translation>Натисніть на перший кут bbox для сегментації ШІ</translation>
    </message>
    <message>
        <source>Click opposite corner to segment object</source>
        <translation>Натисніть на протилежний кут для сегментації об&apos;єкта</translation>
    </message>
    <message>
        <source>Click first corner for oriented rectangle</source>
        <translation>Натисніть перший кут для орієнтованого прямокутника</translation>
    </message>
    <message>
        <source>Click second corner to set orientation</source>
        <translation>Натисніть другий кут для задання орієнтації</translation>
    </message>
    <message>
        <source>Click third corner to close oriented rectangle</source>
        <translation>Натисніть третій кут для замикання орієнтованого прямокутника</translation>
    </message>
    <message>
        <source>Click &amp; drag to rotate the shape</source>
        <translation>Натисніть і перетягніть, щоб обертати фігуру</translation>
    </message>
</context>
<context>
    <name>EmptyStateWidget</name>
    <message>
        <source>Start annotating</source>
        <translation>Почати анотування</translation>
    </message>
    <message>
        <source>Open an image or a directory of images to begin.</source>
        <translation>Щоб почати, відкрийте зображення або папку із зображеннями.</translation>
    </message>
    <message>
        <source>Open Image</source>
        <translation>Відкрити зображення</translation>
    </message>
    <message>
        <source>Open Directory</source>
        <translation>Відкрити папку</translation>
    </message>
    <message>
        <source>Or drag and drop image files here</source>
        <translation>Або перетягніть файли зображень сюди</translation>
    </message>
</context>
<context>
    <name>LabelDialog</name>
    <message>
        <source>Shape Label</source>
        <translation>Мітка фігури</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Мітка</translation>
    </message>
    <message>
        <source>Group ID</source>
        <translation>ID групи</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Опис</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>&amp;Save
</source>
        <translation>&amp;Зберегти</translation>
    </message>
    <message>
        <source>Save labels to file</source>
        <translation>Зберегти мітки у файл</translation>
    </message>
    <message>
        <source>&amp;Save As</source>
        <translation>&amp;Зберегти як</translation>
    </message>
    <message>
        <source>Save &amp;Automatically</source>
        <translation>&amp;Автоматично зберегти</translation>
    </message>
    <message>
        <source>Save automatically</source>
        <translation>Зберегти автоматично</translation>
    </message>
    <message>
        <source>Save With Image Data</source>
        <translation>Зберегти з даними зображення</translation>
    </message>
    <message>
        <source>Save image data in label file</source>
        <translation>Зберегти дані зображення у файлі мітки</translation>
    </message>
    <message>
        <source>&amp;Change Output Dir</source>
        <translation>&amp;Змінити каталог виводу</translation>
    </message>
    <message>
        <source>Change where annotations are loaded/saved</source>
        <translation>Змінити місце завантаження/збереження анотацій</translation>
    </message>
    <message>
        <source>&amp;Open
</source>
        <translation>&amp;Відкрити</translation>
    </message>
    <message>
        <source>Open image or label file</source>
        <translation>Відкрити файл зображення або мітки</translation>
    </message>
    <message>
        <source>Open Dir</source>
        <translation>Відкрити каталог</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Закрити</translation>
    </message>
    <message>
        <source>Close current file</source>
        <translation>Закрити поточний файл</translation>
    </message>
    <message>
        <source>&amp;Delete File</source>
        <translation>&amp;Видалити файл</translation>
    </message>
    <message>
        <source>Delete current label file</source>
        <translation>Видалити поточний файл мітки</translation>
    </message>
    <message>
        <source>Keep Previous Annotation</source>
        <translation>Зберегти попередню анотацію</translation>
    </message>
    <message>
        <source>Toggle &quot;keep previous annotation&quot; mode</source>
        <translation>Увімкнути режим «зберегти попередню анотацію»</translation>
    </message>
    <message>
        <source>Keep Previous Brightness/Contrast</source>
        <translation>Зберегти попередню яскравість/контраст</translation>
    </message>
    <message>
        <source>Delete Shapes</source>
        <translation>Видалити фігури</translation>
    </message>
    <message>
        <source>Delete the selected shapes</source>
        <translation>Видалити вибрані фігури</translation>
    </message>
    <message>
        <source>&amp;Edit Label</source>
        <translation>&amp;Редагувати мітку</translation>
    </message>
    <message>
        <source>Modify the label of the selected shape</source>
        <translation>Змінити мітку вибраної фігури</translation>
    </message>
    <message>
        <source>Copy to Clipboard</source>
        <translation>Копіювати в буфер обміну</translation>
    </message>
    <message>
        <source>Place the selected shapes on the clipboard</source>
        <translation>Помістити вибрані фігури в буфер обміну</translation>
    </message>
    <message>
        <source>Paste from Clipboard</source>
        <translation>Вставити з буфера обміну</translation>
    </message>
    <message>
        <source>Duplicate Shapes</source>
        <translation>Дублювати фігури</translation>
    </message>
    <message>
        <source>Create a duplicate of the selected shapes</source>
        <translation>Створити дублікат вибраних фігур</translation>
    </message>
    <message>
        <source>Undo last point</source>
        <translation>Скасувати останній пункт</translation>
    </message>
    <message>
        <source>Undo last drawn point</source>
        <translation>Скасувати останню намальовану точку</translation>
    </message>
    <message>
        <source>Undo
</source>
        <translation>Скасувати</translation>
    </message>
    <message>
        <source>Undo last add and edit of shape</source>
        <translation>Скасувати останнє додавання та редагування фігури</translation>
    </message>
    <message>
        <source>Remove Selected Point</source>
        <translation>Видалити вибрану точку</translation>
    </message>
    <message>
        <source>Remove selected point from polygon</source>
        <translation>Видалити вибрану точку з багатокутника</translation>
    </message>
    <message>
        <source>Start drawing polygons</source>
        <translation>Почніть малювати багатокутники</translation>
    </message>
    <message>
        <source>Edit Shapes</source>
        <translation>Редагувати фігури</translation>
    </message>
    <message>
        <source>Move and edit the selected shapes</source>
        <translation>Перемістити і відредагувати вибрані фігури</translation>
    </message>
    <message>
        <source>Start drawing rectangles</source>
        <translation>Почніть малювати прямокутники</translation>
    </message>
    <message>
        <source>Start drawing circles</source>
        <translation>Почніть малювати кола</translation>
    </message>
    <message>
        <source>Start drawing lines</source>
        <translation>Почніть малювати лінії</translation>
    </message>
    <message>
        <source>Start drawing points</source>
        <translation>Почніть малювати точки</translation>
    </message>
    <message>
        <source>&amp;Next Image</source>
        <translation>&amp;Наступне зображення</translation>
    </message>
    <message>
        <source>Open next (hold Ctl+Shift to copy labels)</source>
        <translation>Відкрити далі (утримуйте Ctrl+Shift, щоб скопіювати мітки)</translation>
    </message>
    <message>
        <source>&amp;Prev Image</source>
        <translation>&amp;Попереднє зображення</translation>
    </message>
    <message>
        <source>Open prev (hold Ctl+Shift to copy labels)</source>
        <translation>Відкрити попередній (утримуйте Ctrl+Shift, щоб скопіювати мітки)</translation>
    </message>
    <message>
        <source>&amp;Brightness Contrast</source>
        <translation>&amp;Яскравість Контраст</translation>
    </message>
    <message>
        <source>Adjust brightness and contrast</source>
        <translation>Відрегулювати яскравість і контраст</translation>
    </message>
    <message>
        <source>Zoom &amp;In</source>
        <translation>&amp;Збільшити</translation>
    </message>
    <message>
        <source>&amp;Zoom Out</source>
        <translation>&amp;Зменшити</translation>
    </message>
    <message>
        <source>Reset Layout</source>
        <translation>Скинути макет</translation>
    </message>
    <message>
        <source>Fill Drawing Polygon</source>
        <translation>Заливка багатокутника при малюванні</translation>
    </message>
    <message>
        <source>Fill polygon while drawing</source>
        <translation>Заповнювати багатокутник під час малювання</translation>
    </message>
    <message>
        <source>&amp;Hide
Shapes</source>
        <translation>&amp;Приховати
фігури</translation>
    </message>
    <message>
        <source>Hide all shapes</source>
        <translation>Приховати всі фігури</translation>
    </message>
    <message>
        <source>&amp;Show
Shapes</source>
        <translation>&amp;Показати
фігури</translation>
    </message>
    <message>
        <source>Show all shapes</source>
        <translation>Показати всі фігури</translation>
    </message>
    <message>
        <source>&amp;Toggle
Shapes</source>
        <translation>&amp;Переключити
фігури</translation>
    </message>
    <message>
        <source>Toggle all shapes</source>
        <translation>Переключити всі фігури</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation>Збільшити</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation>&amp;Вийти</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>Вийти з програми</translation>
    </message>
    <message>
        <source>&amp;Tutorial</source>
        <translation>&amp;Посібник</translation>
    </message>
    <message>
        <source>Show tutorial page</source>
        <translation>Показати сторінку підручника</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Файл</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Редагувати</translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation>&amp;Переглянути</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Довідка</translation>
    </message>
    <message>
        <source>%s started.</source>
        <translation>%s розпочато.</translation>
    </message>
    <message>
        <source>Flags</source>
        <translation>Прапори</translation>
    </message>
    <message>
        <source>Shape List</source>
        <translation>Список фігур</translation>
    </message>
    <message>
        <source>Select label to start annotating for it. Press &apos;Esc&apos; to deselect.</source>
        <translation>Виберіть мітку, щоб розпочати анотування для неї. Натисніть «Esc», щоб скасувати вибір.</translation>
    </message>
    <message>
        <source>Label List</source>
        <translation>Список міток</translation>
    </message>
    <message>
        <source>Search Filename</source>
        <translation>Пошук імені файлу</translation>
    </message>
    <message>
        <source>File List</source>
        <translation>Список файлів</translation>
    </message>
    <message>
        <source>Configuration Errors</source>
        <translation>Помилки конфігурації</translation>
    </message>
    <message>
        <source>Errors were found while loading the configuration. Please review the errors below and reload your configuration or ignore the erroneous lines.</source>
        <translation>Під час завантаження конфігурації виявлено помилки. Перегляньте наведені нижче помилки та перезавантажте свою конфігурацію або проігноруйте помилкові рядки.</translation>
    </message>
    <message>
        <source>Mask Output Unavailable</source>
        <translation>Вивід маски недоступний</translation>
    </message>
    <message>
        <source>%s only detects bounding boxes and cannot create &apos;%s&apos; annotations.

Switch the AI Text-to-Annotation model to &apos;SAM3 (smart)&apos;, or set the output format to &apos;Rectangle&apos;.</source>
        <translation>%s виявляє лише обмежувальні рамки й не може створювати анотації &apos;%s&apos;.

Перемкніть модель AI Text-to-Annotation на &apos;SAM3 (smart)&apos; або встановіть формат виводу &apos;Rectangle&apos;.</translation>
    </message>
    <message>
        <source>Invalid label</source>
        <translation>Недійсна мітка</translation>
    </message>
    <message>
        <source>Invalid label &apos;{}&apos; with validation type &apos;{}&apos;</source>
        <translation>Недійсна мітка &quot;{}&quot; з типом перевірки &quot;{}&quot;</translation>
    </message>
    <message>
        <source>Error saving label data</source>
        <translation>Помилка збереження даних мітки</translation>
    </message>
    <message>
        <source>&lt;b&gt;%s&lt;/b&gt;</source>
        <translation>&lt;b&gt;%s&lt;/b&gt;</translation>
    </message>
    <message>
        <source>AI inference failed: %s</source>
        <translation>Інференс ШІ не вдався: %s</translation>
    </message>
    <message>
        <source>Error opening file</source>
        <translation>Помилка відкриття файлу</translation>
    </message>
    <message>
        <source>No such file: &lt;b&gt;%s&lt;/b&gt;</source>
        <translation>Такого файлу немає: &lt;b&gt;%s&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Loading %s...</source>
        <translation>Завантаження %s...</translation>
    </message>
    <message>
        <source>Loaded %s</source>
        <translation>Завантажено %s</translation>
    </message>
    <message>
        <source>Image &amp; Label files (%s)</source>
        <translation>Файли зображень і міток (%s)</translation>
    </message>
    <message>
        <source>%s - Choose Image or Label file</source>
        <translation>%s - Виберіть файл зображення або мітки</translation>
    </message>
    <message>
        <source>%s - Save/Load Annotations in Directory</source>
        <translation>%s - Зберегти/завантажити анотації в каталозі</translation>
    </message>
    <message>
        <source>%s . Annotations will be saved/loaded in %s</source>
        <translation>%s . Анотації будуть збережені/завантажені в %s</translation>
    </message>
    <message>
        <source>%s - Choose File</source>
        <translation>%s - Виберіть файл</translation>
    </message>
    <message>
        <source>Label files (*%s)</source>
        <translation>Файли міток (*%s)</translation>
    </message>
    <message>
        <source>Choose File</source>
        <translation>Виберіть файл</translation>
    </message>
    <message>
        <source>Attention</source>
        <translation>Увага</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Видалити</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Скасувати</translation>
    </message>
    <message>
        <source>Unavailable in AI-Points mode because this model does not support point prompts.</source>
        <translation>Недоступно в режимі AI-Points, оскільки ця модель не підтримує точкові запити.</translation>
    </message>
    <message>
        <source>Save annotations to &quot;{}&quot; before closing?</source>
        <translation>Зберегти анотації до &quot;{}&quot; перед закриттям?</translation>
    </message>
    <message>
        <source>Save annotations?</source>
        <translation>Зберегти анотації?</translation>
    </message>
    <message>
        <source>Delete {} shapes? You can restore them with Undo.</source>
        <translation>Видалити {} фігур? Ви можете відновити їх за допомогою команди «Скасувати».</translation>
    </message>
    <message>
        <source>%s - Open Directory</source>
        <translation>%s - Відкрити каталог</translation>
    </message>
    <message>
        <source>The image is too large to open: {width}x{height} pixels exceeds the {max_side} pixel per-side limit of the raster engine. Raising the decode limit will not help. Split the image into tiles (for example with gdal_retile.py) or open a smaller copy.</source>
        <translation>Зображення завелике, щоб його відкрити: {width}x{height} пікселів перевищує обмеження растрового рушія у {max_side} пікселів на сторону. Збільшення ліміту декодування не допоможе. Розбийте зображення на плитки (наприклад, за допомогою gdal_retile.py) або відкрийте меншу копію.</translation>
    </message>
    <message>
        <source>The image is too large to open: {width}x{height} pixels needs about {required} MB, but the decode limit is {limit} MB. Split the image into tiles (for example with gdal_retile.py) or open a smaller copy.</source>
        <translation>Зображення завелике, щоб його відкрити: {width}x{height} пікселів потребує близько {required} МБ, але ліміт декодування становить {limit} МБ. Розбийте зображення на плитки (наприклад, за допомогою gdal_retile.py) або відкрийте меншу копію.</translation>
    </message>
    <message>
        <source>Polygon</source>
        <translation>Багатокутник</translation>
    </message>
    <message>
        <source>Save the labels under a new file name</source>
        <translation>Зберегти мітки під новою назвою файлу</translation>
    </message>
    <message>
        <source>Insert the clipboard shapes into this image</source>
        <translation>Вставити фігури з буфера обміну в це зображення</translation>
    </message>
    <message>
        <source>Rectangle</source>
        <translation>Прямокутник</translation>
    </message>
    <message>
        <source>Circle</source>
        <translation>Коло</translation>
    </message>
    <message>
        <source>Line</source>
        <translation>Лінія</translation>
    </message>
    <message>
        <source>Point</source>
        <translation>Точка</translation>
    </message>
    <message>
        <source>LineStrip</source>
        <translation>LineStrip</translation>
    </message>
    <message>
        <source>Click to place linestrip points; Ctrl+click places the last one.</source>
        <translation>Клацайте, щоб ставити точки лінії; Ctrl+клацання ставить останню.</translation>
    </message>
    <message>
        <source>AI-Points</source>
        <translation>AI-Points</translation>
    </message>
    <message>
        <source>Click points to segment object. Ctrl+LeftClick ends creation.</source>
        <translation>Натисніть точки для сегментації об&apos;єкта. Ctrl+LeftClick завершує створення.</translation>
    </message>
    <message>
        <source>AI-Box</source>
        <translation>AI-Box</translation>
    </message>
    <message>
        <source>Draw a bounding box to segment object.</source>
        <translation>Намалюйте обмежувальну рамку для сегментації об&apos;єкта.</translation>
    </message>
    <message>
        <source>Fit to &amp;Window</source>
        <translation>&amp;Припасувати вікно</translation>
    </message>
    <message>
        <source>Keep the whole image visible when the window is resized</source>
        <translation>Усе зображення залишається видимим під час зміни розміру вікна</translation>
    </message>
    <message>
        <source>Fit to Wi&amp;dth</source>
        <translation>За &amp;шириною</translation>
    </message>
    <message>
        <source>Match the image width to the window when it is resized</source>
        <translation>Ширина зображення підлаштовується під вікно під час зміни його розміру</translation>
    </message>
    <message>
        <source>Make the image appear larger</source>
        <translation>Показати зображення більшим</translation>
    </message>
    <message>
        <source>Make the image appear smaller</source>
        <translation>Показати зображення меншим</translation>
    </message>
    <message>
        <source>&amp;Actual Size</source>
        <translation>&amp;Реальний розмір</translation>
    </message>
    <message>
        <source>Show the image at 100%</source>
        <translation>Показати зображення в масштабі 100%</translation>
    </message>
    <message>
        <source>Ctrl+Wheel zooms the canvas</source>
        <translation>Ctrl+колесо масштабує полотно</translation>
    </message>
    <message>
        <source>AI-Points Unavailable</source>
        <translation>AI-Points недоступний</translation>
    </message>
    <message>
        <source>%s does not support point prompts.
Please select a different model or use AI-Box mode.</source>
        <translation>%s не підтримує точкові запити.
Будь ласка, виберіть іншу модель або використовуйте режим AI-Box.</translation>
    </message>
    <message>
        <source>File list is disabled when a label file is opened</source>
        <translation>Список файлів вимкнено, коли відкрито файл міток</translation>
    </message>
    <message>
        <source>Add Point to Edge</source>
        <translation>Додати точку на ребро</translation>
    </message>
    <message>
        <source>Insert a new point at the hovered polygon edge</source>
        <translation>Вставити нову точку на ребрі полігона під курсором</translation>
    </message>
    <message>
        <source>&amp;Keep Previous Zoom</source>
        <translation>&amp;Зберегти попередній масштаб</translation>
    </message>
    <message>
        <source>Permanently delete this label file? This action cannot be undone.</source>
        <translation>Остаточно видалити цей файл мітки? Цю дію неможливо скасувати.</translation>
    </message>
    <message>
        <source>Allowed formats: {formats}</source>
        <translation>Дозволені формати: {formats}</translation>
    </message>
    <message>
        <source>The selected label file could not be opened: {path}</source>
        <translation>Не вдалося відкрити вибраний файл міток: {path}</translation>
    </message>
    <message>
        <source>The selected image file could not be opened: {path}</source>
        <translation>Не вдалося відкрити вибраний файл зображення: {path}</translation>
    </message>
    <message>
        <source>Failed to load: {path}</source>
        <translation>Не вдалося завантажити: {path}</translation>
    </message>
    <message>
        <source>Oriented Rectangle</source>
        <translation>Орієнтований прямокутник</translation>
    </message>
    <message>
        <source>Start drawing oriented rectangles</source>
        <translation>Почніть малювати орієнтовані прямокутники</translation>
    </message>
    <message>
        <source>AI inference produced no new annotation.</source>
        <translation>Інференс ШІ не створив нової анотації.</translation>
    </message>
    <message>
        <source>Shape had no area; nothing created.</source>
        <translation>Фігура не має площі; нічого не створено.</translation>
    </message>
    <message>
        <source>Settings…</source>
        <translation>Параметри…</translation>
    </message>
    <message>
        <source>Edit settings</source>
        <translation>Редагувати параметри</translation>
    </message>
    <message>
        <source>Settings are managed via --config for this session</source>
        <translation>Параметри керуються через --config для цього сеансу</translation>
    </message>
    <message>
        <source>Configuration Error</source>
        <translation>Помилка конфігурації</translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <source>Color theme</source>
        <translation>Кольорова тема</translation>
    </message>
    <message>
        <source>System</source>
        <translation>Системна</translation>
    </message>
    <message>
        <source>Light</source>
        <translation>Світла</translation>
    </message>
    <message>
        <source>Dark</source>
        <translation>Темна</translation>
    </message>
    <message>
        <source>Show label popup on new shape</source>
        <translation>Показувати спливаюче вікно мітки для нової фігури</translation>
    </message>
    <message>
        <source>Show shape labels on canvas</source>
        <translation>Показувати мітки фігур на полотні</translation>
    </message>
    <message>
        <source>Allow points outside the image boundary</source>
        <translation>Дозволити точки за межами зображення</translation>
    </message>
    <message>
        <source>Appearance and language</source>
        <translation>Вигляд і мова</translation>
    </message>
    <message>
        <source>Files and saving</source>
        <translation>Файли та збереження</translation>
    </message>
    <message>
        <source>Drawing and canvas</source>
        <translation>Малювання та полотно</translation>
    </message>
    <message>
        <source>Continue between images</source>
        <translation>Продовження роботи між зображеннями</translation>
    </message>
    <message>
        <source>Label sources</source>
        <translation>Джерела міток</translation>
    </message>
    <message>
        <source>Label behavior</source>
        <translation>Поведінка міток</translation>
    </message>
    <message>
        <source>AI assist</source>
        <translation>Допомога ШІ</translation>
    </message>
    <message>
        <source>Save automatically</source>
        <translation>Зберігати автоматично</translation>
    </message>
    <message>
        <source>Save image data in label file</source>
        <translation>Зберігати дані зображення у файлі мітки</translation>
    </message>
    <message>
        <source>Embeds the image in the label JSON file.</source>
        <translation>Вбудовує зображення у JSON-файл мітки.</translation>
    </message>
    <message>
        <source>Shape Color Mode</source>
        <translation>Режим кольору фігур</translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation>Автоматично</translation>
    </message>
    <message>
        <source>Uniform</source>
        <translation>Однаковий</translation>
    </message>
    <message>
        <source>By Label</source>
        <translation>За міткою</translation>
    </message>
    <message>
        <source>Automatic palette shift</source>
        <translation>Автоматичний зсув палітри</translation>
    </message>
    <message>
        <source>Uniform mode color</source>
        <translation>Колір режиму «Однаковий»</translation>
    </message>
    <message>
        <source>By Label fallback color</source>
        <translation>Резервний колір режиму «За міткою»</translation>
    </message>
    <message>
        <source>Individual Label colors remain editable in the Config File.</source>
        <translation>Кольори окремих міток і надалі можна редагувати у файлі конфігурації.</translation>
    </message>
    <message>
        <source>Keep previous annotation</source>
        <translation>Зберегти попередню анотацію</translation>
    </message>
    <message>
        <source>Keep previous zoom</source>
        <translation>Зберегти попередній масштаб</translation>
    </message>
    <message>
        <source>Keep previous brightness/contrast</source>
        <translation>Зберегти попередню яскравість/контраст</translation>
    </message>
    <message>
        <source>Fill polygon while drawing</source>
        <translation>Заповнювати багатокутник під час малювання</translation>
    </message>
    <message>
        <source>Let shape points extend beyond the image, e.g. for partially visible objects.</source>
        <translation>Дозволяє точкам фігур виходити за межі зображення, напр. для частково видимих об&apos;єктів.</translation>
    </message>
    <message>
        <source>Polygon detail</source>
        <translation>Деталізація полігона</translation>
    </message>
    <message>
        <source>Higher values preserve more Mask boundary detail and smaller lands.</source>
        <translation>Вищі значення зберігають більше деталей межі маски та менші області.</translation>
    </message>
    <message>
        <source>Predefined labels</source>
        <translation>Попередньо визначені мітки</translation>
    </message>
    <message>
        <source>Label validation</source>
        <translation>Перевірка мітки</translation>
    </message>
    <message>
        <source>Sort labels</source>
        <translation>Сортувати мітки</translation>
    </message>
    <message>
        <source>Sort the label list alphabetically instead of keeping the provided order.</source>
        <translation>Сортує список міток за алфавітом замість збереження заданого порядку.</translation>
    </message>
    <message>
        <source>Show label text field</source>
        <translation>Показувати текстове поле мітки</translation>
    </message>
    <message>
        <source>Label completion</source>
        <translation>Автодоповнення міток</translation>
    </message>
    <message>
        <source>Starts with</source>
        <translation>Починається з</translation>
    </message>
    <message>
        <source>Contains</source>
        <translation>Містить</translation>
    </message>
    <message>
        <source>Default model</source>
        <translation>Модель за замовчуванням</translation>
    </message>
    <message>
        <source>EfficientSam (speed)</source>
        <translation>EfficientSam (швидкість)</translation>
    </message>
    <message>
        <source>EfficientSam (accuracy)</source>
        <translation>EfficientSam (точність)</translation>
    </message>
    <message>
        <source>Sam (speed)</source>
        <translation>Sam (швидкість)</translation>
    </message>
    <message>
        <source>Sam (balanced)</source>
        <translation>Sam (збалансований)</translation>
    </message>
    <message>
        <source>Sam (accuracy)</source>
        <translation>Sam (точність)</translation>
    </message>
    <message>
        <source>Sam2 (speed)</source>
        <translation>Sam2 (швидкість)</translation>
    </message>
    <message>
        <source>Sam2 (balanced)</source>
        <translation>Sam2 (збалансований)</translation>
    </message>
    <message>
        <source>Sam2 (accuracy)</source>
        <translation>Sam2 (точність)</translation>
    </message>
    <message>
        <source>Sam3</source>
        <translation>Sam3</translation>
    </message>
    <message>
        <source>Suppress existing Shape matches</source>
        <translation>Придушувати збіги з наявними фігурами</translation>
    </message>
    <message>
        <source>When an AI Assist candidate matches an existing Shape, highlight that Shape instead of creating a new Shape.</source>
        <translation>Якщо кандидат Допомоги ШІ збігається з наявною фігурою, ця фігура виділяється замість створення нової фігури.</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Параметри</translation>
    </message>
    <message>
        <source>Open config file as text…</source>
        <translation>Відкрити файл конфігурації як текст…</translation>
    </message>
    <message>
        <source>Edits made in the text file apply after restart</source>
        <translation>Зміни в текстовому файлі застосуються після перезапуску</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Закрити</translation>
    </message>
    <message>
        <source>BETA</source>
        <translation>BETA</translation>
    </message>
    <message>
        <source>(none)</source>
        <translation>(немає)</translation>
    </message>
    <message>
        <source>one item per line</source>
        <translation>по одному елементу на рядок</translation>
    </message>
    <message>
        <source>Configuration Error</source>
        <translation>Помилка конфігурації</translation>
    </message>
    <message>
        <source>Predefined labels cannot be empty while Label validation is set to exact. Disable exact validation first.</source>
        <translation>Попередньо визначені мітки не можуть бути порожніми, коли перевірка мітки встановлена на «exact». Спочатку вимкніть перевірку «exact».</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Мова</translation>
    </message>
    <message>
        <source>Takes effect after restart.</source>
        <translation>Набуде чинності після перезапуску.</translation>
    </message>
    <message>
        <source>System default</source>
        <translation>Мова системи</translation>
    </message>
    <message>
        <source>Predefined image flags</source>
        <translation>Попередньо визначені прапорці зображення</translation>
    </message>
</context>
<context>
    <name>_ColorSwatchButton</name>
    <message>
        <source>RGB: {red}, {green}, {blue}</source>
        <translation>RGB: {red}, {green}, {blue}</translation>
    </message>
</context>
<context>
    <name>_SettingsPage</name>
    <message>
        <source>Settings sections</source>
        <translation>Розділи налаштувань</translation>
    </message>
</context>
</TS>
