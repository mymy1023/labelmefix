<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>AiAssistedAnnotationWidget</name>
    <message>
        <source>AI-Assisted Annotation</source>
        <translation>AI 辅助标注</translation>
    </message>
    <message>
        <source>AI suggests annotation in &apos;AI-Points&apos; and &apos;AI-Box&apos; modes</source>
        <translation>在 &apos;AI-Points&apos; 和 &apos;AI-Box&apos; 模式下，AI 会提供标注建议</translation>
    </message>
    <message>
        <source>Polygon detail</source>
        <translation>多边形细节</translation>
    </message>
    <message>
        <source>Adjust polygon detail</source>
        <translation>调整多边形细节</translation>
    </message>
    <message>
        <source>Smoother</source>
        <translation>更平滑</translation>
    </message>
    <message>
        <source>More detail</source>
        <translation>更多细节</translation>
    </message>
    <message>
        <source>Select &apos;AI-Points&apos; or &apos;AI-Box&apos; mode to enable AI-Assisted Annotation</source>
        <translation>请选择 &apos;AI-Points&apos; 或 &apos;AI-Box&apos; 模式以启用 AI 辅助标注</translation>
    </message>
</context>
<context>
    <name>AiTextToAnnotationWidget</name>
    <message>
        <source>AI Text-to-Annotation</source>
        <translation>AI 文本转标注</translation>
    </message>
    <message>
        <source>e.g., dog,cat,bird</source>
        <translation>例如：dog,cat,bird</translation>
    </message>
    <message>
        <source>Run</source>
        <translation>运行</translation>
    </message>
    <message>
        <source>Score</source>
        <translation>得分</translation>
    </message>
    <message>
        <source>IoU</source>
        <translation>IoU</translation>
    </message>
    <message>
        <source>AI creates annotations from the text prompt</source>
        <translation>AI 将根据文本提示生成标注</translation>
    </message>
    <message>
        <source>Select &apos;Polygon&apos;, &apos;Rectangle&apos;, or &apos;AI-Points&apos; mode to enable</source>
        <translation>请选择 &apos;Polygon&apos;、&apos;Rectangle&apos; 或 &apos;AI-Points&apos; 模式以启用</translation>
    </message>
</context>
<context>
    <name>BrightnessContrastDialog</name>
    <message>
        <source>Brightness/Contrast</source>
        <translation>亮度/对比度</translation>
    </message>
    <message>
        <source>Brightness:</source>
        <translation>亮度:</translation>
    </message>
    <message>
        <source>Contrast:</source>
        <translation>对比度:</translation>
    </message>
</context>
<context>
    <name>Canvas</name>
    <message>
        <source>Click &amp; drag to move point</source>
        <translation>点击 &amp; 拖动以移动点</translation>
    </message>
    <message>
        <source>Click &amp; drag to move shape</source>
        <translation>按住鼠标拖动以移动形状</translation>
    </message>
    <message>
        <source>Creating %r</source>
        <translation>正在创建 %r</translation>
    </message>
    <message>
        <source>ESC to cancel</source>
        <translation>按 ESC 键取消</translation>
    </message>
    <message>
        <source>Enter or Space to finalize</source>
        <translation>按 Enter 或空格键确认</translation>
    </message>
    <message>
        <source>Editing shapes</source>
        <translation>正在编辑形状</translation>
    </message>
    <message>
        <source>Click start point for line</source>
        <translation>单击确定直线起点</translation>
    </message>
    <message>
        <source>Click end point for line</source>
        <translation>单击确定直线终点</translation>
    </message>
    <message>
        <source>Click start point for linestrip</source>
        <translation>单击确定折线起点</translation>
    </message>
    <message>
        <source>Click next point or finish by Ctrl/Cmd+Click for linestrip</source>
        <translation>单击添加下一个顶点；按住 Ctrl/Cmd 并单击以结束折线</translation>
    </message>
    <message>
        <source>Click center point for circle</source>
        <translation>单击确定圆心</translation>
    </message>
    <message>
        <source>Click point on circumference for circle</source>
        <translation>单击圆周上的点以确定圆形</translation>
    </message>
    <message>
        <source>Click first corner for rectangle</source>
        <translation>单击确定矩形的第一个角</translation>
    </message>
    <message>
        <source>Click to add point</source>
        <translation>单击以添加顶点</translation>
    </message>
    <message>
        <source>ALT + SHIFT + Click to delete point</source>
        <translation>按住 ALT + SHIFT 并单击以删除顶点</translation>
    </message>
    <message>
        <source>ALT + Click to create point on shape</source>
        <translation>按住 ALT 并单击以在形状上添加顶点</translation>
    </message>
    <message>
        <source>Right-click &amp; drag to copy shape</source>
        <translation>按住鼠标右键拖动以复制形状</translation>
    </message>
    <message>
        <source>Click opposite corner for rectangle (Shift for square)</source>
        <translation>单击对角以确定矩形（按住 Shift 绘制正方形）</translation>
    </message>
    <message>
        <source>Click points to include or Shift+Click to exclude. Ctrl+LeftClick ends creation.</source>
        <translation>单击添加包含点；按住 Shift 并单击添加排除点；按住 Ctrl 并单击结束创建。</translation>
    </message>
    <message>
        <source>Click first corner of bbox for AI segmentation</source>
        <translation>单击确定 AI 分割边界框的第一个角</translation>
    </message>
    <message>
        <source>Click opposite corner to segment object</source>
        <translation>单击对角以分割对象</translation>
    </message>
    <message>
        <source>Click first corner for oriented rectangle</source>
        <translation>单击确定有向矩形的第一个角</translation>
    </message>
    <message>
        <source>Click second corner to set orientation</source>
        <translation>单击第二个角以设定方向</translation>
    </message>
    <message>
        <source>Click third corner to close oriented rectangle</source>
        <translation>单击第三个角以闭合有向矩形</translation>
    </message>
    <message>
        <source>Click &amp; drag to rotate the shape</source>
        <translation>按住鼠标左键拖动以旋转形状</translation>
    </message>
</context>
<context>
    <name>EmptyStateWidget</name>
    <message>
        <source>Start annotating</source>
        <translation>开始标注</translation>
    </message>
    <message>
        <source>Open an image or a directory of images to begin.</source>
        <translation>打开图像或图像目录以开始。</translation>
    </message>
    <message>
        <source>Open Image</source>
        <translation>打开图像</translation>
    </message>
    <message>
        <source>Open Directory</source>
        <translation>打开目录</translation>
    </message>
    <message>
        <source>Or drag and drop image files here</source>
        <translation>或将图像文件拖放到此处</translation>
    </message>
</context>
<context>
    <name>LabelDialog</name>
    <message>
        <source>Shape Label</source>
        <translation>形状标签</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>标签</translation>
    </message>
    <message>
        <source>Group ID</source>
        <translation>组 ID</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>描述</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Flags</source>
        <translation>标志</translation>
    </message>
    <message>
        <source>Shape List</source>
        <translation>形状列表</translation>
    </message>
    <message>
        <source>Select label to start annotating for it. Press &apos;Esc&apos; to deselect.</source>
        <translation>选择标签以开始为其添加标注。按“Esc”取消选择。</translation>
    </message>
    <message>
        <source>Label List</source>
        <translation>标签列表</translation>
    </message>
    <message>
        <source>Search Filename</source>
        <translation>搜索文件名</translation>
    </message>
    <message>
        <source>File List</source>
        <translation>文件列表</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation>退出(&amp;Q)</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>退出应用程序</translation>
    </message>
    <message>
        <source>&amp;Open
</source>
        <translation>打开(&amp;O)
</translation>
    </message>
    <message>
        <source>Open image or label file</source>
        <translation>打开图像或标签文件</translation>
    </message>
    <message>
        <source>Open Dir</source>
        <translation>打开目录</translation>
    </message>
    <message>
        <source>&amp;Next Image</source>
        <translation>下一张图像(&amp;N)</translation>
    </message>
    <message>
        <source>Open next (hold Ctl+Shift to copy labels)</source>
        <translation>打开下一张图像（按住 Ctl+Shift 复制标签）</translation>
    </message>
    <message>
        <source>&amp;Prev Image</source>
        <translation>上一张图像(&amp;P)</translation>
    </message>
    <message>
        <source>Open prev (hold Ctl+Shift to copy labels)</source>
        <translation>打开上一张图像（按住 Ctl+Shift 复制标签）</translation>
    </message>
    <message>
        <source>&amp;Save
</source>
        <translation>保存(&amp;S)
</translation>
    </message>
    <message>
        <source>Save labels to file</source>
        <translation>将标签保存到文件</translation>
    </message>
    <message>
        <source>&amp;Save As</source>
        <translation>另存为(&amp;S)</translation>
    </message>
    <message>
        <source>&amp;Delete File</source>
        <translation>删除文件(&amp;D)</translation>
    </message>
    <message>
        <source>Delete current label file</source>
        <translation>删除当前标签文件</translation>
    </message>
    <message>
        <source>&amp;Change Output Dir</source>
        <translation>更改输出目录(&amp;C)</translation>
    </message>
    <message>
        <source>Change where annotations are loaded/saved</source>
        <translation>更改标注的加载和保存位置</translation>
    </message>
    <message>
        <source>Save &amp;Automatically</source>
        <translation>自动保存(&amp;A)</translation>
    </message>
    <message>
        <source>Save automatically</source>
        <translation>自动保存</translation>
    </message>
    <message>
        <source>Save With Image Data</source>
        <translation>保存图像数据</translation>
    </message>
    <message>
        <source>Save image data in label file</source>
        <translation>在标签文件中保存图像数据</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>关闭(&amp;C)</translation>
    </message>
    <message>
        <source>Close current file</source>
        <translation>关闭当前文件</translation>
    </message>
    <message>
        <source>Keep Previous Annotation</source>
        <translation>保留上一张标注</translation>
    </message>
    <message>
        <source>Start drawing polygons</source>
        <translation>开始绘制多边形</translation>
    </message>
    <message>
        <source>Start drawing rectangles</source>
        <translation>开始绘制矩形</translation>
    </message>
    <message>
        <source>Start drawing circles</source>
        <translation>开始绘制圆形</translation>
    </message>
    <message>
        <source>Start drawing lines</source>
        <translation>开始绘制线段</translation>
    </message>
    <message>
        <source>Start drawing points</source>
        <translation>开始绘制点</translation>
    </message>
    <message>
        <source>Edit Shapes</source>
        <translation>编辑形状</translation>
    </message>
    <message>
        <source>Move and edit the selected shapes</source>
        <translation>移动和编辑选中的形状</translation>
    </message>
    <message>
        <source>Delete Shapes</source>
        <translation>删除形状</translation>
    </message>
    <message>
        <source>Delete the selected shapes</source>
        <translation>删除选中的形状</translation>
    </message>
    <message>
        <source>Duplicate Shapes</source>
        <translation>复制形状</translation>
    </message>
    <message>
        <source>Create a duplicate of the selected shapes</source>
        <translation>创建选中形状的副本</translation>
    </message>
    <message>
        <source>Undo last point</source>
        <translation>撤销上一个点</translation>
    </message>
    <message>
        <source>Undo last drawn point</source>
        <translation>撤销上一个绘制的点</translation>
    </message>
    <message>
        <source>Remove Selected Point</source>
        <translation>移除选中的点</translation>
    </message>
    <message>
        <source>Remove selected point from polygon</source>
        <translation>从多边形中移除选中的点</translation>
    </message>
    <message>
        <source>Undo
</source>
        <translation>撤销
</translation>
    </message>
    <message>
        <source>Undo last add and edit of shape</source>
        <translation>撤销上一次添加或编辑形状的操作</translation>
    </message>
    <message>
        <source>&amp;Hide
Shapes</source>
        <translation>隐藏(&amp;H)
形状</translation>
    </message>
    <message>
        <source>Hide all shapes</source>
        <translation>隐藏所有形状</translation>
    </message>
    <message>
        <source>&amp;Show
Shapes</source>
        <translation>显示(&amp;S)
形状</translation>
    </message>
    <message>
        <source>Show all shapes</source>
        <translation>显示所有形状</translation>
    </message>
    <message>
        <source>&amp;Toggle
Shapes</source>
        <translation>切换(&amp;T)
形状显示</translation>
    </message>
    <message>
        <source>Toggle all shapes</source>
        <translation>切换所有形状的显示状态</translation>
    </message>
    <message>
        <source>&amp;Tutorial</source>
        <translation>教程(&amp;T)</translation>
    </message>
    <message>
        <source>Show tutorial page</source>
        <translation>显示教程页面</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation>缩放</translation>
    </message>
    <message>
        <source>Zoom &amp;In</source>
        <translation>放大(&amp;I)</translation>
    </message>
    <message>
        <source>&amp;Zoom Out</source>
        <translation>缩小(&amp;Z)</translation>
    </message>
    <message>
        <source>&amp;Brightness Contrast</source>
        <translation>亮度与对比度(&amp;B)</translation>
    </message>
    <message>
        <source>Adjust brightness and contrast</source>
        <translation>调整亮度和对比度</translation>
    </message>
    <message>
        <source>&amp;Edit Label</source>
        <translation>编辑标签(&amp;E)</translation>
    </message>
    <message>
        <source>Save the labels under a new file name</source>
        <translation>以新的文件名保存标签</translation>
    </message>
    <message>
        <source>Modify the label of the selected shape</source>
        <translation>修改选中形状的标签</translation>
    </message>
    <message>
        <source>Copy to Clipboard</source>
        <translation>复制到剪贴板</translation>
    </message>
    <message>
        <source>Place the selected shapes on the clipboard</source>
        <translation>将所选形状放入剪贴板</translation>
    </message>
    <message>
        <source>Paste from Clipboard</source>
        <translation>从剪贴板粘贴</translation>
    </message>
    <message>
        <source>Insert the clipboard shapes into this image</source>
        <translation>将剪贴板中的形状插入此图像</translation>
    </message>
    <message>
        <source>Click to place linestrip points; Ctrl+click places the last one.</source>
        <translation>单击放置折线的点；Ctrl+单击放置最后一个点。</translation>
    </message>
    <message>
        <source>Fit to &amp;Window</source>
        <translation>适合窗口(&amp;W)</translation>
    </message>
    <message>
        <source>Keep the whole image visible when the window is resized</source>
        <translation>调整窗口大小时保持整幅图像可见</translation>
    </message>
    <message>
        <source>Fit to Wi&amp;dth</source>
        <translation>适合宽度(&amp;D)</translation>
    </message>
    <message>
        <source>Match the image width to the window when it is resized</source>
        <translation>调整窗口大小时使图像宽度与窗口一致</translation>
    </message>
    <message>
        <source>Make the image appear larger</source>
        <translation>以更大的尺寸显示图像</translation>
    </message>
    <message>
        <source>Make the image appear smaller</source>
        <translation>以更小的尺寸显示图像</translation>
    </message>
    <message>
        <source>&amp;Actual Size</source>
        <translation>实际大小(&amp;A)</translation>
    </message>
    <message>
        <source>Show the image at 100%</source>
        <translation>以 100% 显示图像</translation>
    </message>
    <message>
        <source>Fill Drawing Polygon</source>
        <translation>填充正在绘制的多边形</translation>
    </message>
    <message>
        <source>Fill polygon while drawing</source>
        <translation>绘制时填充多边形</translation>
    </message>
    <message>
        <source>Ctrl+Wheel zooms the canvas</source>
        <translation>Ctrl+滚轮缩放画布</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>文件(&amp;F)</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>编辑(&amp;E)</translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation>视图(&amp;V)</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>帮助(&amp;H)</translation>
    </message>
    <message>
        <source>%s started.</source>
        <translation>%s 已启动。</translation>
    </message>
    <message>
        <source>Mask Output Unavailable</source>
        <translation>掩膜输出不可用</translation>
    </message>
    <message>
        <source>%s only detects bounding boxes and cannot create &apos;%s&apos; annotations.

Switch the AI Text-to-Annotation model to &apos;SAM3 (smart)&apos;, or set the output format to &apos;Rectangle&apos;.</source>
        <translation>%s 仅检测边界框，无法创建 &apos;%s&apos; 标注。

请将 AI Text-to-Annotation 模型切换为 &apos;SAM3 (smart)&apos;，或将输出格式设置为 &apos;Rectangle&apos;。</translation>
    </message>
    <message>
        <source>Invalid label</source>
        <translation>无效标签</translation>
    </message>
    <message>
        <source>Invalid label &apos;{}&apos; with validation type &apos;{}&apos;</source>
        <translation>标签“{}”不符合“{}”验证类型</translation>
    </message>
    <message>
        <source>Error saving label data</source>
        <translation>保存标签数据时出错</translation>
    </message>
    <message>
        <source>&lt;b&gt;%s&lt;/b&gt;</source>
        <translation>&lt;b&gt;%s&lt;/b&gt;</translation>
    </message>
    <message>
        <source>AI inference failed: %s</source>
        <translation>AI 推理失败：%s</translation>
    </message>
    <message>
        <source>Error opening file</source>
        <translation>打开文件时出错</translation>
    </message>
    <message>
        <source>No such file: &lt;b&gt;%s&lt;/b&gt;</source>
        <translation>文件不存在：&lt;b&gt;%s&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Loading %s...</source>
        <translation>正在加载 %s...</translation>
    </message>
    <message>
        <source>Loaded %s</source>
        <translation>已加载 %s</translation>
    </message>
    <message>
        <source>Image &amp; Label files (%s)</source>
        <translation>图像 &amp; 标签文件 (%s)</translation>
    </message>
    <message>
        <source>%s - Choose Image or Label file</source>
        <translation>%s - 选择图像或标签文件</translation>
    </message>
    <message>
        <source>%s - Save/Load Annotations in Directory</source>
        <translation>%s - 在目录中保存或加载标注</translation>
    </message>
    <message>
        <source>%s . Annotations will be saved/loaded in %s</source>
        <translation>%s。标注将在 %s 中保存或加载</translation>
    </message>
    <message>
        <source>%s - Choose File</source>
        <translation>%s - 选择文件</translation>
    </message>
    <message>
        <source>Label files (*%s)</source>
        <translation>标签文件 (*%s)</translation>
    </message>
    <message>
        <source>Choose File</source>
        <translation>选择文件</translation>
    </message>
    <message>
        <source>Attention</source>
        <translation>注意</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <source>Unavailable in AI-Points mode because this model does not support point prompts.</source>
        <translation>此模型不支持点提示，因此在 AI-Points 模式下不可用。</translation>
    </message>
    <message>
        <source>Save annotations to &quot;{}&quot; before closing?</source>
        <translation>关闭前将标注保存到“{}”？</translation>
    </message>
    <message>
        <source>Save annotations?</source>
        <translation>保存标注？</translation>
    </message>
    <message>
        <source>Delete {} shapes? You can restore them with Undo.</source>
        <translation>删除 {} 个形状？可以使用「撤销」恢复。</translation>
    </message>
    <message>
        <source>%s - Open Directory</source>
        <translation>%s - 打开目录</translation>
    </message>
    <message>
        <source>The image is too large to open: {width}x{height} pixels exceeds the {max_side} pixel per-side limit of the raster engine. Raising the decode limit will not help. Split the image into tiles (for example with gdal_retile.py) or open a smaller copy.</source>
        <translation>图像过大,无法打开: {width}x{height} 像素超出了栅格引擎每边 {max_side} 像素的上限。提高解码上限也无济于事。请将图像切分为图块(例如使用 gdal_retile.py),或打开较小的副本。</translation>
    </message>
    <message>
        <source>The image is too large to open: {width}x{height} pixels needs about {required} MB, but the decode limit is {limit} MB. Split the image into tiles (for example with gdal_retile.py) or open a smaller copy.</source>
        <translation>图像过大,无法打开: {width}x{height} 像素约需 {required} MB,但解码上限为 {limit} MB。请将图像切分为图块(例如使用 gdal_retile.py),或打开较小的副本。</translation>
    </message>
    <message>
        <source>Toggle &quot;keep previous annotation&quot; mode</source>
        <translation>切换“保留上一次的标注”模式</translation>
    </message>
    <message>
        <source>Keep Previous Brightness/Contrast</source>
        <translation>保留上一次的亮度/对比度</translation>
    </message>
    <message>
        <source>Configuration Errors</source>
        <translation>配置错误</translation>
    </message>
    <message>
        <source>Errors were found while loading the configuration. Please review the errors below and reload your configuration or ignore the erroneous lines.</source>
        <translation>加载配置时发现错误。请查看下方的错误信息，并重新加载配置或忽略有误的行。</translation>
    </message>
    <message>
        <source>Reset Layout</source>
        <translation>重置布局</translation>
    </message>
    <message>
        <source>Polygon</source>
        <translation>多边形</translation>
    </message>
    <message>
        <source>Rectangle</source>
        <translation>矩形</translation>
    </message>
    <message>
        <source>Circle</source>
        <translation>圆形</translation>
    </message>
    <message>
        <source>Line</source>
        <translation>直线</translation>
    </message>
    <message>
        <source>Point</source>
        <translation>点</translation>
    </message>
    <message>
        <source>LineStrip</source>
        <translation>折线</translation>
    </message>
    <message>
        <source>AI-Points</source>
        <translation>AI-Points</translation>
    </message>
    <message>
        <source>Click points to segment object. Ctrl+LeftClick ends creation.</source>
        <translation>单击添加点以分割对象；按住 Ctrl 并单击结束创建。</translation>
    </message>
    <message>
        <source>AI-Box</source>
        <translation>AI-Box</translation>
    </message>
    <message>
        <source>Draw a bounding box to segment object.</source>
        <translation>绘制边界框以分割对象。</translation>
    </message>
    <message>
        <source>AI-Points Unavailable</source>
        <translation>AI-Points 不可用</translation>
    </message>
    <message>
        <source>%s does not support point prompts.
Please select a different model or use AI-Box mode.</source>
        <translation>%s 不支持点提示。
请另选模型，或改用 AI-Box 模式。</translation>
    </message>
    <message>
        <source>File list is disabled when a label file is opened</source>
        <translation>打开标签文件时，文件列表不可用</translation>
    </message>
    <message>
        <source>Add Point to Edge</source>
        <translation>在边上添加点</translation>
    </message>
    <message>
        <source>Insert a new point at the hovered polygon edge</source>
        <translation>在悬停的多边形边上插入新顶点</translation>
    </message>
    <message>
        <source>&amp;Keep Previous Zoom</source>
        <translation>保留上一次的缩放(&amp;K)</translation>
    </message>
    <message>
        <source>Permanently delete this label file? This action cannot be undone.</source>
        <translation>永久删除该标签文件？此操作无法撤销。</translation>
    </message>
    <message>
        <source>Allowed formats: {formats}</source>
        <translation>支持的格式: {formats}</translation>
    </message>
    <message>
        <source>The selected label file could not be opened: {path}</source>
        <translation>无法打开所选标签文件: {path}</translation>
    </message>
    <message>
        <source>The selected image file could not be opened: {path}</source>
        <translation>无法打开所选图像文件: {path}</translation>
    </message>
    <message>
        <source>Failed to load: {path}</source>
        <translation>加载失败：{path}</translation>
    </message>
    <message>
        <source>Oriented Rectangle</source>
        <translation>有向矩形</translation>
    </message>
    <message>
        <source>Start drawing oriented rectangles</source>
        <translation>开始绘制有向矩形</translation>
    </message>
    <message>
        <source>AI inference produced no new annotation.</source>
        <translation>AI 推理未生成新标注。</translation>
    </message>
    <message>
        <source>Shape had no area; nothing created.</source>
        <translation>形状面积为零，未创建。</translation>
    </message>
    <message>
        <source>Settings…</source>
        <translation>设置…</translation>
    </message>
    <message>
        <source>Edit settings</source>
        <translation>编辑设置</translation>
    </message>
    <message>
        <source>Settings are managed via --config for this session</source>
        <translation>本次会话的设置通过 --config 管理</translation>
    </message>
    <message>
        <source>Configuration Error</source>
        <translation>配置错误</translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <source>Color theme</source>
        <translation>颜色主题</translation>
    </message>
    <message>
        <source>System</source>
        <translation>跟随系统</translation>
    </message>
    <message>
        <source>Light</source>
        <translation>浅色</translation>
    </message>
    <message>
        <source>Dark</source>
        <translation>深色</translation>
    </message>
    <message>
        <source>Show label popup on new shape</source>
        <translation>新建形状时显示标签弹窗</translation>
    </message>
    <message>
        <source>Show shape labels on canvas</source>
        <translation>在画布上显示形状标签</translation>
    </message>
    <message>
        <source>Allow points outside the image boundary</source>
        <translation>允许点超出图像边界</translation>
    </message>
    <message>
        <source>Appearance and language</source>
        <translation>外观与语言</translation>
    </message>
    <message>
        <source>Files and saving</source>
        <translation>文件与保存</translation>
    </message>
    <message>
        <source>Drawing and canvas</source>
        <translation>绘制与画布</translation>
    </message>
    <message>
        <source>Continue between images</source>
        <translation>图像之间延续</translation>
    </message>
    <message>
        <source>Label sources</source>
        <translation>标签来源</translation>
    </message>
    <message>
        <source>Label behavior</source>
        <translation>标签行为</translation>
    </message>
    <message>
        <source>AI assist</source>
        <translation>AI 辅助</translation>
    </message>
    <message>
        <source>Save automatically</source>
        <translation>自动保存</translation>
    </message>
    <message>
        <source>Save image data in label file</source>
        <translation>在标签文件中保存图像数据</translation>
    </message>
    <message>
        <source>Embeds the image in the label JSON file.</source>
        <translation>将图像嵌入标签 JSON 文件中。</translation>
    </message>
    <message>
        <source>Shape Color Mode</source>
        <translation>形状颜色模式</translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation>自动</translation>
    </message>
    <message>
        <source>Uniform</source>
        <translation>统一</translation>
    </message>
    <message>
        <source>By Label</source>
        <translation>按标签</translation>
    </message>
    <message>
        <source>Automatic palette shift</source>
        <translation>自动调色板偏移</translation>
    </message>
    <message>
        <source>Uniform mode color</source>
        <translation>“统一”模式颜色</translation>
    </message>
    <message>
        <source>By Label fallback color</source>
        <translation>“按标签”模式备用颜色</translation>
    </message>
    <message>
        <source>Individual Label colors remain editable in the Config File.</source>
        <translation>仍可在配置文件中编辑各个标签的颜色。</translation>
    </message>
    <message>
        <source>Keep previous annotation</source>
        <translation>保留上一张标注</translation>
    </message>
    <message>
        <source>Keep previous zoom</source>
        <translation>保留上一次的缩放</translation>
    </message>
    <message>
        <source>Keep previous brightness/contrast</source>
        <translation>保留上一次的亮度/对比度</translation>
    </message>
    <message>
        <source>Fill polygon while drawing</source>
        <translation>绘制时填充多边形</translation>
    </message>
    <message>
        <source>Let shape points extend beyond the image, e.g. for partially visible objects.</source>
        <translation>允许形状的点延伸到图像之外，例如用于部分可见的对象。</translation>
    </message>
    <message>
        <source>Polygon detail</source>
        <translation>多边形细节</translation>
    </message>
    <message>
        <source>Higher values preserve more Mask boundary detail and smaller lands.</source>
        <translation>值越高，保留的蒙版边界细节和较小区域越多。</translation>
    </message>
    <message>
        <source>Predefined labels</source>
        <translation>预定义标签</translation>
    </message>
    <message>
        <source>Label validation</source>
        <translation>标签验证</translation>
    </message>
    <message>
        <source>Sort labels</source>
        <translation>标签排序</translation>
    </message>
    <message>
        <source>Sort the label list alphabetically instead of keeping the provided order.</source>
        <translation>按字母顺序排序标签列表，而非保留提供的顺序。</translation>
    </message>
    <message>
        <source>Show label text field</source>
        <translation>显示标签文本字段</translation>
    </message>
    <message>
        <source>Label completion</source>
        <translation>标签补全</translation>
    </message>
    <message>
        <source>Starts with</source>
        <translation>以…开头</translation>
    </message>
    <message>
        <source>Contains</source>
        <translation>包含</translation>
    </message>
    <message>
        <source>Default model</source>
        <translation>默认模型</translation>
    </message>
    <message>
        <source>EfficientSam (speed)</source>
        <translation>EfficientSam (速度)</translation>
    </message>
    <message>
        <source>EfficientSam (accuracy)</source>
        <translation>EfficientSam (准确度)</translation>
    </message>
    <message>
        <source>Sam (speed)</source>
        <translation>Sam (速度)</translation>
    </message>
    <message>
        <source>Sam (balanced)</source>
        <translation>Sam (均衡)</translation>
    </message>
    <message>
        <source>Sam (accuracy)</source>
        <translation>Sam (准确度)</translation>
    </message>
    <message>
        <source>Sam2 (speed)</source>
        <translation>Sam2 (速度)</translation>
    </message>
    <message>
        <source>Sam2 (balanced)</source>
        <translation>Sam2 (均衡)</translation>
    </message>
    <message>
        <source>Sam2 (accuracy)</source>
        <translation>Sam2 (准确度)</translation>
    </message>
    <message>
        <source>Sam3</source>
        <translation>Sam3</translation>
    </message>
    <message>
        <source>Suppress existing Shape matches</source>
        <translation>抑制与已有形状匹配的结果</translation>
    </message>
    <message>
        <source>When an AI Assist candidate matches an existing Shape, highlight that Shape instead of creating a new Shape.</source>
        <translation>当 AI 辅助的候选结果与已有形状匹配时，高亮该形状，而不是创建新的形状。</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>设置</translation>
    </message>
    <message>
        <source>Open config file as text…</source>
        <translation>以文本方式打开配置文件…</translation>
    </message>
    <message>
        <source>Edits made in the text file apply after restart</source>
        <translation>在文本文件中所做的修改将在重启后生效</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>关闭</translation>
    </message>
    <message>
        <source>BETA</source>
        <translation>BETA</translation>
    </message>
    <message>
        <source>(none)</source>
        <translation>（无）</translation>
    </message>
    <message>
        <source>one item per line</source>
        <translation>每行一项</translation>
    </message>
    <message>
        <source>Configuration Error</source>
        <translation>配置错误</translation>
    </message>
    <message>
        <source>Predefined labels cannot be empty while Label validation is set to exact. Disable exact validation first.</source>
        <translation>当标签验证设置为“exact”时，预定义标签不能为空。请先禁用“exact”验证。</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>语言</translation>
    </message>
    <message>
        <source>Takes effect after restart.</source>
        <translation>重新启动后生效。</translation>
    </message>
    <message>
        <source>System default</source>
        <translation>系统默认</translation>
    </message>
    <message>
        <source>Predefined image flags</source>
        <translation>预定义图像标记</translation>
    </message>
</context>
<context>
    <name>_ColorSwatchButton</name>
    <message>
        <source>RGB: {red}, {green}, {blue}</source>
        <translation>RGB: {red}, {green}, {blue}</translation>
    </message>
</context>
<context>
    <name>_SettingsPage</name>
    <message>
        <source>Settings sections</source>
        <translation>设置分区</translation>
    </message>
</context>
</TS>
