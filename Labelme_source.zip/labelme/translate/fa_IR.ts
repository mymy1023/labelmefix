<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fa_IR">
<context>
    <name>AiAssistedAnnotationWidget</name>
    <message>
        <source>AI-Assisted Annotation</source>
        <translation>حاشیه‌نویسی با کمک هوش مصنوعی</translation>
    </message>
    <message>
        <source>AI suggests annotation in &apos;AI-Points&apos; and &apos;AI-Box&apos; modes</source>
        <translation>AI در حالت‌های &apos;AI-Points&apos; و &apos;AI-Box&apos; حاشیه‌نویسی پیشنهاد می‌دهد</translation>
    </message>
    <message>
        <source>Polygon detail</source>
        <translation>جزئیات چندضلعی</translation>
    </message>
    <message>
        <source>Adjust polygon detail</source>
        <translation>تنظیم جزئیات چندضلعی</translation>
    </message>
    <message>
        <source>Smoother</source>
        <translation>هموارتر</translation>
    </message>
    <message>
        <source>More detail</source>
        <translation>جزئیات بیشتر</translation>
    </message>
    <message>
        <source>Select &apos;AI-Points&apos; or &apos;AI-Box&apos; mode to enable AI-Assisted Annotation</source>
        <translation>حالت &apos;AI-Points&apos; یا &apos;AI-Box&apos; را برای فعال‌سازی حاشیه‌نویسی با کمک AI انتخاب کنید</translation>
    </message>
</context>
<context>
    <name>AiTextToAnnotationWidget</name>
    <message>
        <source>AI Text-to-Annotation</source>
        <translation>پیشنهاد هوش مصنوعی</translation>
    </message>
    <message>
        <source>e.g., dog,cat,bird</source>
        <translation>مثال: سگ، گربه، پرنده</translation>
    </message>
    <message>
        <source>Run</source>
        <translation>اجرا</translation>
    </message>
    <message>
        <source>Score</source>
        <translation>امتیاز</translation>
    </message>
    <message>
        <source>IoU</source>
        <translation>IoU</translation>
    </message>
    <message>
        <source>AI creates annotations from the text prompt</source>
        <translation>هوش مصنوعی حاشیه‌نویسی‌ها را از متن ایجاد می‌کند</translation>
    </message>
    <message>
        <source>Select &apos;Polygon&apos;, &apos;Rectangle&apos;, or &apos;AI-Points&apos; mode to enable</source>
        <translation>حالت &apos;Polygon&apos;، &apos;Rectangle&apos; یا &apos;AI-Points&apos; را برای فعال‌سازی انتخاب کنید</translation>
    </message>
</context>
<context>
    <name>BrightnessContrastDialog</name>
    <message>
        <source>Brightness/Contrast</source>
        <translation>روشنایی/کنتراست</translation>
    </message>
    <message>
        <source>Brightness:</source>
        <translation>روشنایی:</translation>
    </message>
    <message>
        <source>Contrast:</source>
        <translation>کنتراست:</translation>
    </message>
</context>
<context>
    <name>Canvas</name>
    <message>
        <source>Click &amp; drag to move point</source>
        <translation>کلیک و کشیدن برای جابجایی نقطه</translation>
    </message>
    <message>
        <source>Click &amp; drag to move shape</source>
        <translation>کلیک و کشیدن برای جابجایی شکل</translation>
    </message>
    <message>
        <source>Creating %r</source>
        <translation>در حال ایجاد %r</translation>
    </message>
    <message>
        <source>ESC to cancel</source>
        <translation>ESC برای لغو</translation>
    </message>
    <message>
        <source>Enter or Space to finalize</source>
        <translation>Enter یا Space برای نهایی کردن</translation>
    </message>
    <message>
        <source>Editing shapes</source>
        <translation>ویرایش اشکال</translation>
    </message>
    <message>
        <source>Click start point for line</source>
        <translation>کلیک روی نقطه شروع خط</translation>
    </message>
    <message>
        <source>Click end point for line</source>
        <translation>کلیک روی نقطه پایان خط</translation>
    </message>
    <message>
        <source>Click start point for linestrip</source>
        <translation>کلیک روی نقطه شروع خط چندتکه‌ای</translation>
    </message>
    <message>
        <source>Click next point or finish by Ctrl/Cmd+Click for linestrip</source>
        <translation>کلیک روی نقطه بعدی یا Ctrl/Cmd+کلیک برای پایان خط چندتکه‌ای</translation>
    </message>
    <message>
        <source>Click center point for circle</source>
        <translation>کلیک روی نقطه مرکز دایره</translation>
    </message>
    <message>
        <source>Click point on circumference for circle</source>
        <translation>کلیک روی نقطه روی محیط دایره</translation>
    </message>
    <message>
        <source>Click first corner for rectangle</source>
        <translation>کلیک روی گوشه اول مستطیل</translation>
    </message>
    <message>
        <source>Click to add point</source>
        <translation>کلیک برای افزودن نقطه</translation>
    </message>
    <message>
        <source>ALT + SHIFT + Click to delete point</source>
        <translation>ALT + SHIFT + کلیک برای حذف نقطه</translation>
    </message>
    <message>
        <source>ALT + Click to create point on shape</source>
        <translation>ALT + کلیک برای ایجاد نقطه روی شکل</translation>
    </message>
    <message>
        <source>Right-click &amp; drag to copy shape</source>
        <translation>کلیک راست و کشیدن برای کپی شکل</translation>
    </message>
    <message>
        <source>Click opposite corner for rectangle (Shift for square)</source>
        <translation>کلیک روی گوشه مقابل مستطیل (Shift برای مربع)</translation>
    </message>
    <message>
        <source>Click points to include or Shift+Click to exclude. Ctrl+LeftClick ends creation.</source>
        <translation>روی نقاط کلیک کنید تا شامل شوند یا Shift+Click برای حذف. Ctrl+LeftClick ایجاد را پایان می‌دهد.</translation>
    </message>
    <message>
        <source>Click first corner of bbox for AI segmentation</source>
        <translation>برای قطعه‌بندی AI روی اولین گوشه bbox کلیک کنید</translation>
    </message>
    <message>
        <source>Click opposite corner to segment object</source>
        <translation>روی گوشه مقابل برای قطعه‌بندی شیء کلیک کنید</translation>
    </message>
    <message>
        <source>Click first corner for oriented rectangle</source>
        <translation>کلیک روی گوشه اول مستطیل جهت‌دار</translation>
    </message>
    <message>
        <source>Click second corner to set orientation</source>
        <translation>کلیک روی گوشه دوم برای تنظیم جهت</translation>
    </message>
    <message>
        <source>Click third corner to close oriented rectangle</source>
        <translation>کلیک روی گوشه سوم برای بستن مستطیل جهت‌دار</translation>
    </message>
    <message>
        <source>Click &amp; drag to rotate the shape</source>
        <translation>کلیک و کشیدن برای چرخاندن شکل</translation>
    </message>
</context>
<context>
    <name>EmptyStateWidget</name>
    <message>
        <source>Start annotating</source>
        <translation>برچسب‌گذاری را شروع کنید</translation>
    </message>
    <message>
        <source>Open an image or a directory of images to begin.</source>
        <translation>برای شروع، یک تصویر یا پوشه‌ای از تصاویر را باز کنید.</translation>
    </message>
    <message>
        <source>Open Image</source>
        <translation>باز کردن تصویر</translation>
    </message>
    <message>
        <source>Open Directory</source>
        <translation>باز کردن پوشه</translation>
    </message>
    <message>
        <source>Or drag and drop image files here</source>
        <translation>یا فایل‌های تصویری را اینجا بکشید و رها کنید</translation>
    </message>
</context>
<context>
    <name>LabelDialog</name>
    <message>
        <source>Shape Label</source>
        <translation>برچسب شکل</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>برچسب</translation>
    </message>
    <message>
        <source>Group ID</source>
        <translation>شناسه گروه</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>توضیحات</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Flags</source>
        <translation>پرچم‌ها</translation>
    </message>
    <message>
        <source>Shape List</source>
        <translation>فهرست شکل‌ها</translation>
    </message>
    <message>
        <source>Select label to start annotating for it. Press &apos;Esc&apos; to deselect.</source>
        <translation>برچسب را انتخاب کنید تا شروع به حاشیه‌نویسی کنید. &apos;Esc&apos; را فشار دهید تا انتخاب لغو شود.</translation>
    </message>
    <message>
        <source>Label List</source>
        <translation>فهرست برچسب‌ها</translation>
    </message>
    <message>
        <source>Search Filename</source>
        <translation>جستجوی نام فایل</translation>
    </message>
    <message>
        <source>File List</source>
        <translation>فهرست فایل‌ها</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation>خروج(&amp;Q)</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>خروج از برنامه</translation>
    </message>
    <message>
        <source>&amp;Open
</source>
        <translation>باز کردن(&amp;O)</translation>
    </message>
    <message>
        <source>Open image or label file</source>
        <translation>باز کردن فایل تصویر یا برچسب</translation>
    </message>
    <message>
        <source>Open Dir</source>
        <translation>باز کردن پوشه</translation>
    </message>
    <message>
        <source>&amp;Next Image</source>
        <translation>تصویر بعدی(&amp;N)</translation>
    </message>
    <message>
        <source>Open next (hold Ctl+Shift to copy labels)</source>
        <translation>باز کردن بعدی (Ctrl+Shift را نگه دارید تا برچسب‌ها کپی شوند)</translation>
    </message>
    <message>
        <source>&amp;Prev Image</source>
        <translation>تصویر قبلی(&amp;P)</translation>
    </message>
    <message>
        <source>Open prev (hold Ctl+Shift to copy labels)</source>
        <translation>باز کردن قبلی (Ctrl+Shift را نگه دارید تا برچسب‌ها کپی شوند)</translation>
    </message>
    <message>
        <source>&amp;Save
</source>
        <translation>ذخیره(&amp;S)</translation>
    </message>
    <message>
        <source>Save labels to file</source>
        <translation>ذخیره برچسب‌ها در فایل</translation>
    </message>
    <message>
        <source>&amp;Save As</source>
        <translation>ذخیره با نام دیگر(&amp;S)</translation>
    </message>
    <message>
        <source>&amp;Delete File</source>
        <translation>حذف(&amp;D)</translation>
    </message>
    <message>
        <source>Delete current label file</source>
        <translation>حذف فایل برچسب فعلی</translation>
    </message>
    <message>
        <source>&amp;Change Output Dir</source>
        <translation>تغییر مسیر خروجی(&amp;C)</translation>
    </message>
    <message>
        <source>Change where annotations are loaded/saved</source>
        <translation>تغییر محل بارگذاری/ذخیره حاشیه‌نویسی‌ها</translation>
    </message>
    <message>
        <source>Save &amp;Automatically</source>
        <translation>ذخیره خودکار(&amp;A)</translation>
    </message>
    <message>
        <source>Save automatically</source>
        <translation>ذخیره خودکار</translation>
    </message>
    <message>
        <source>Save With Image Data</source>
        <translation>ذخیره با داده تصویر</translation>
    </message>
    <message>
        <source>Save image data in label file</source>
        <translation>ذخیره داده تصویر در فایل برچسب</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>بستن(&amp;C)</translation>
    </message>
    <message>
        <source>Close current file</source>
        <translation>بستن فایل فعلی</translation>
    </message>
    <message>
        <source>Keep Previous Annotation</source>
        <translation>نگه داشتن حاشیه‌نویسی قبلی</translation>
    </message>
    <message>
        <source>Start drawing polygons</source>
        <translation>شروع رسم چندضلعی</translation>
    </message>
    <message>
        <source>Start drawing rectangles</source>
        <translation>شروع رسم مستطیل</translation>
    </message>
    <message>
        <source>Start drawing circles</source>
        <translation>شروع رسم دایره</translation>
    </message>
    <message>
        <source>Start drawing lines</source>
        <translation>شروع رسم خط</translation>
    </message>
    <message>
        <source>Start drawing points</source>
        <translation>شروع رسم نقطه</translation>
    </message>
    <message>
        <source>Edit Shapes</source>
        <translation>ویرایش شکل</translation>
    </message>
    <message>
        <source>Move and edit the selected shapes</source>
        <translation>جابجایی و ویرایش شکل‌های انتخاب شده</translation>
    </message>
    <message>
        <source>Delete Shapes</source>
        <translation>حذف شکل</translation>
    </message>
    <message>
        <source>Delete the selected shapes</source>
        <translation>حذف شکل‌های انتخاب شده</translation>
    </message>
    <message>
        <source>Duplicate Shapes</source>
        <translation>تکثیر شکل</translation>
    </message>
    <message>
        <source>Create a duplicate of the selected shapes</source>
        <translation>ایجاد کپی از شکل‌های انتخاب شده</translation>
    </message>
    <message>
        <source>Undo last point</source>
        <translation>بازگشت آخرین نقطه</translation>
    </message>
    <message>
        <source>Undo last drawn point</source>
        <translation>بازگشت آخرین نقطه رسم شده</translation>
    </message>
    <message>
        <source>Remove Selected Point</source>
        <translation>حذف نقطه انتخاب شده</translation>
    </message>
    <message>
        <source>Remove selected point from polygon</source>
        <translation>حذف نقطه انتخاب شده از چندضلعی</translation>
    </message>
    <message>
        <source>Undo
</source>
        <translation>بازگشت</translation>
    </message>
    <message>
        <source>Undo last add and edit of shape</source>
        <translation>بازگشت آخرین افزودن و ویرایش شکل</translation>
    </message>
    <message>
        <source>&amp;Hide
Shapes</source>
        <translation>مخفی کردن شکل(&amp;H)</translation>
    </message>
    <message>
        <source>Hide all shapes</source>
        <translation>مخفی کردن همه شکل‌ها</translation>
    </message>
    <message>
        <source>&amp;Show
Shapes</source>
        <translation>نمایش شکل(&amp;S)</translation>
    </message>
    <message>
        <source>Show all shapes</source>
        <translation>نمایش همه شکل‌ها</translation>
    </message>
    <message>
        <source>&amp;Toggle
Shapes</source>
        <translation>تغییر وضعیت شکل(&amp;S)</translation>
    </message>
    <message>
        <source>Toggle all shapes</source>
        <translation>تغییر وضعیت همه شکل‌ها</translation>
    </message>
    <message>
        <source>&amp;Tutorial</source>
        <translation>آموزش(&amp;T)</translation>
    </message>
    <message>
        <source>Show tutorial page</source>
        <translation>نمایش صفحه آموزش</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation>زوم</translation>
    </message>
    <message>
        <source>Zoom &amp;In</source>
        <translation>بزرگ‌نمایی(&amp;I)</translation>
    </message>
    <message>
        <source>&amp;Zoom Out</source>
        <translation>کوچک‌نمایی(&amp;Z)</translation>
    </message>
    <message>
        <source>&amp;Brightness Contrast</source>
        <translation>روشنایی و کنتراست(&amp;B)</translation>
    </message>
    <message>
        <source>Adjust brightness and contrast</source>
        <translation>تنظیم روشنایی و کنتراست</translation>
    </message>
    <message>
        <source>&amp;Edit Label</source>
        <translation>ویرایش برچسب(&amp;E)</translation>
    </message>
    <message>
        <source>Save the labels under a new file name</source>
        <translation>ذخیره برچسب‌ها با نام فایل جدید</translation>
    </message>
    <message>
        <source>Modify the label of the selected shape</source>
        <translation>تغییر برچسب شکل انتخاب شده</translation>
    </message>
    <message>
        <source>Copy to Clipboard</source>
        <translation>کپی به کلیپ‌بورد</translation>
    </message>
    <message>
        <source>Place the selected shapes on the clipboard</source>
        <translation>قرار دادن شکل‌های انتخاب شده در کلیپ‌بورد</translation>
    </message>
    <message>
        <source>Paste from Clipboard</source>
        <translation>چسباندن از کلیپ‌بورد</translation>
    </message>
    <message>
        <source>Insert the clipboard shapes into this image</source>
        <translation>درج شکل‌های کلیپ‌بورد در این تصویر</translation>
    </message>
    <message>
        <source>Click to place linestrip points; Ctrl+click places the last one.</source>
        <translation>برای قرار دادن نقاط خط چندتکه‌ای کلیک کنید؛ Ctrl+کلیک نقطه آخر را قرار می‌دهد.</translation>
    </message>
    <message>
        <source>Fit to &amp;Window</source>
        <translation>تناسب با پنجره(&amp;W)</translation>
    </message>
    <message>
        <source>Keep the whole image visible when the window is resized</source>
        <translation>نمایان نگه داشتن کل تصویر هنگام تغییر اندازهٔ پنجره</translation>
    </message>
    <message>
        <source>Fit to Wi&amp;dth</source>
        <translation>تناسب با عرض(&amp;D)</translation>
    </message>
    <message>
        <source>Match the image width to the window when it is resized</source>
        <translation>تطبیق عرض تصویر با پنجره هنگام تغییر اندازهٔ آن</translation>
    </message>
    <message>
        <source>Make the image appear larger</source>
        <translation>نمایش تصویر در اندازهٔ بزرگ‌تر</translation>
    </message>
    <message>
        <source>Make the image appear smaller</source>
        <translation>نمایش تصویر در اندازهٔ کوچک‌تر</translation>
    </message>
    <message>
        <source>&amp;Actual Size</source>
        <translation>اندازهٔ &amp;واقعی</translation>
    </message>
    <message>
        <source>Show the image at 100%</source>
        <translation>نمایش تصویر در ۱۰۰٪</translation>
    </message>
    <message>
        <source>Fill Drawing Polygon</source>
        <translation>پر کردن چندضلعی رسم شده</translation>
    </message>
    <message>
        <source>Fill polygon while drawing</source>
        <translation>پر کردن چندضلعی هنگام رسم</translation>
    </message>
    <message>
        <source>Ctrl+Wheel zooms the canvas</source>
        <translation>Ctrl+چرخ روی بوم بزرگ‌نمایی می‌کند</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>فایل(&amp;F)</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>ویرایش(&amp;E)</translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation>نمایش(&amp;V)</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>راهنما(&amp;H)</translation>
    </message>
    <message>
        <source>%s started.</source>
        <translation>%s راه‌اندازی شد.</translation>
    </message>
    <message>
        <source>Mask Output Unavailable</source>
        <translation>خروجی ماسک در دسترس نیست</translation>
    </message>
    <message>
        <source>%s only detects bounding boxes and cannot create &apos;%s&apos; annotations.

Switch the AI Text-to-Annotation model to &apos;SAM3 (smart)&apos;, or set the output format to &apos;Rectangle&apos;.</source>
        <translation>%s فقط کادرهای محصور‌کننده را تشخیص می‌دهد و نمی‌تواند حاشیه‌نویسی &apos;%s&apos; ایجاد کند.

مدل AI Text-to-Annotation را به &apos;SAM3 (smart)&apos; تغییر دهید یا قالب خروجی را روی &apos;Rectangle&apos; تنظیم کنید.</translation>
    </message>
    <message>
        <source>Invalid label</source>
        <translation>برچسب نامعتبر</translation>
    </message>
    <message>
        <source>Invalid label &apos;{}&apos; with validation type &apos;{}&apos;</source>
        <translation>برچسب نامعتبر &apos;{}&apos; با نوع اعتبارسنجی &apos;{}&apos;</translation>
    </message>
    <message>
        <source>Error saving label data</source>
        <translation>خطا در ذخیره داده برچسب</translation>
    </message>
    <message>
        <source>&lt;b&gt;%s&lt;/b&gt;</source>
        <translation>&lt;b&gt;%s&lt;/b&gt;</translation>
    </message>
    <message>
        <source>AI inference failed: %s</source>
        <translation>استنتاج هوش مصنوعی ناموفق بود: %s</translation>
    </message>
    <message>
        <source>Error opening file</source>
        <translation>خطا در باز کردن فایل</translation>
    </message>
    <message>
        <source>No such file: &lt;b&gt;%s&lt;/b&gt;</source>
        <translation>چنین فایلی وجود ندارد: &lt;b&gt;%s&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Loading %s...</source>
        <translation>در حال بارگذاری %s...</translation>
    </message>
    <message>
        <source>Loaded %s</source>
        <translation>بارگذاری شد %s</translation>
    </message>
    <message>
        <source>Image &amp; Label files (%s)</source>
        <translation>فایل‌های تصویر و برچسب (%s)</translation>
    </message>
    <message>
        <source>%s - Choose Image or Label file</source>
        <translation>%s - انتخاب فایل تصویر یا برچسب</translation>
    </message>
    <message>
        <source>%s - Save/Load Annotations in Directory</source>
        <translation>%s - ذخیره/بارگذاری حاشیه‌نویسی‌ها در پوشه</translation>
    </message>
    <message>
        <source>%s . Annotations will be saved/loaded in %s</source>
        <translation>%s . حاشیه‌نویسی‌ها در %s ذخیره/بارگذاری خواهند شد</translation>
    </message>
    <message>
        <source>%s - Choose File</source>
        <translation>%s - انتخاب فایل</translation>
    </message>
    <message>
        <source>Label files (*%s)</source>
        <translation>فایل‌های برچسب (*%s)</translation>
    </message>
    <message>
        <source>Choose File</source>
        <translation>انتخاب فایل</translation>
    </message>
    <message>
        <source>Attention</source>
        <translation>توجه</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>حذف</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>لغو</translation>
    </message>
    <message>
        <source>Unavailable in AI-Points mode because this model does not support point prompts.</source>
        <translation>در حالت AI-Points در دسترس نیست، زیرا این مدل از دستورات نقطه‌ای پشتیبانی نمی‌کند.</translation>
    </message>
    <message>
        <source>Save annotations to &quot;{}&quot; before closing?</source>
        <translation>قبل از بستن، حاشیه‌نویسی‌ها را در &quot;{}&quot; ذخیره کنید؟</translation>
    </message>
    <message>
        <source>Save annotations?</source>
        <translation>ذخیره حاشیه‌نویسی‌ها؟</translation>
    </message>
    <message>
        <source>Delete {} shapes? You can restore them with Undo.</source>
        <translation>حذف {} شکل؟ می‌توانید آن‌ها را با بازگشت بازیابی کنید.</translation>
    </message>
    <message>
        <source>%s - Open Directory</source>
        <translation>%s - باز کردن پوشه</translation>
    </message>
    <message>
        <source>The image is too large to open: {width}x{height} pixels exceeds the {max_side} pixel per-side limit of the raster engine. Raising the decode limit will not help. Split the image into tiles (for example with gdal_retile.py) or open a smaller copy.</source>
        <translation>تصویر برای باز شدن بیش از حد بزرگ است: {width}x{height} پیکسل از محدودیت {max_side} پیکسل در هر ضلع موتور راستر فراتر می‌رود. افزایش محدودیت رمزگشایی کمکی نمی‌کند. تصویر را به کاشی‌ها تقسیم کنید (برای مثال با gdal_retile.py) یا نسخه کوچک‌تری را باز کنید.</translation>
    </message>
    <message>
        <source>The image is too large to open: {width}x{height} pixels needs about {required} MB, but the decode limit is {limit} MB. Split the image into tiles (for example with gdal_retile.py) or open a smaller copy.</source>
        <translation>تصویر برای باز شدن بیش از حد بزرگ است: {width}x{height} پیکسل به حدود {required} مگابایت نیاز دارد، اما محدودیت رمزگشایی {limit} مگابایت است. تصویر را به کاشی‌ها تقسیم کنید (برای مثال با gdal_retile.py) یا نسخه کوچک‌تری را باز کنید.</translation>
    </message>
    <message>
        <source>Toggle &quot;keep previous annotation&quot; mode</source>
        <translation>تغییر وضعیت حالت &quot;نگه داشتن حاشیه‌نویسی قبلی&quot;</translation>
    </message>
    <message>
        <source>Keep Previous Brightness/Contrast</source>
        <translation>نگه داشتن روشنایی/کنتراست قبلی</translation>
    </message>
    <message>
        <source>Configuration Errors</source>
        <translation>خطاهای پیکربندی</translation>
    </message>
    <message>
        <source>Errors were found while loading the configuration. Please review the errors below and reload your configuration or ignore the erroneous lines.</source>
        <translation>هنگام بارگیری پیکربندی خطاهایی یافت شد. لطفاً خطاهای زیر را بررسی کنید و پیکربندی خود را مجدداً بارگیری کنید یا خطوط نادرست را نادیده بگیرید.</translation>
    </message>
    <message>
        <source>Reset Layout</source>
        <translation>بازنشانی چیدمان</translation>
    </message>
    <message>
        <source>Polygon</source>
        <translation>چندضلعی</translation>
    </message>
    <message>
        <source>Rectangle</source>
        <translation>مستطیل</translation>
    </message>
    <message>
        <source>Circle</source>
        <translation>دایره</translation>
    </message>
    <message>
        <source>Line</source>
        <translation>خط</translation>
    </message>
    <message>
        <source>Point</source>
        <translation>نقطه</translation>
    </message>
    <message>
        <source>LineStrip</source>
        <translation>خط چندتکه‌ای</translation>
    </message>
    <message>
        <source>AI-Points</source>
        <translation>AI-Points</translation>
    </message>
    <message>
        <source>Click points to segment object. Ctrl+LeftClick ends creation.</source>
        <translation>روی نقاط کلیک کنید تا شیء بخش‌بندی شود. Ctrl+LeftClick ایجاد را پایان می‌دهد.</translation>
    </message>
    <message>
        <source>AI-Box</source>
        <translation>AI-Box</translation>
    </message>
    <message>
        <source>Draw a bounding box to segment object.</source>
        <translation>یک کادر محصورکننده برای قطعه‌بندی شیء رسم کنید.</translation>
    </message>
    <message>
        <source>AI-Points Unavailable</source>
        <translation>AI-Points در دسترس نیست</translation>
    </message>
    <message>
        <source>%s does not support point prompts.
Please select a different model or use AI-Box mode.</source>
        <translation>%s از دستورات نقطه‌ای پشتیبانی نمی‌کند.
لطفاً مدل دیگری انتخاب کنید یا از حالت AI-Box استفاده کنید.</translation>
    </message>
    <message>
        <source>File list is disabled when a label file is opened</source>
        <translation>فهرست فایل‌ها هنگام باز بودن یک فایل برچسب غیرفعال است</translation>
    </message>
    <message>
        <source>Add Point to Edge</source>
        <translation>افزودن نقطه به لبه</translation>
    </message>
    <message>
        <source>Insert a new point at the hovered polygon edge</source>
        <translation>درج یک نقطه جدید در لبه پلیگانی که اشاره‌گر روی آن است</translation>
    </message>
    <message>
        <source>&amp;Keep Previous Zoom</source>
        <translation>نگه داشتن بزرگ‌نمایی قبلی(&amp;K)</translation>
    </message>
    <message>
        <source>Permanently delete this label file? This action cannot be undone.</source>
        <translation>حذف دائمی این فایل برچسب؟ این عمل قابل بازگشت نیست.</translation>
    </message>
    <message>
        <source>Allowed formats: {formats}</source>
        <translation>قالب‌های مجاز: {formats}</translation>
    </message>
    <message>
        <source>The selected label file could not be opened: {path}</source>
        <translation>پرونده برچسب انتخاب‌شده باز نشد: {path}</translation>
    </message>
    <message>
        <source>The selected image file could not be opened: {path}</source>
        <translation>پرونده تصویر انتخاب‌شده باز نشد: {path}</translation>
    </message>
    <message>
        <source>Failed to load: {path}</source>
        <translation>بارگذاری ناموفق بود: {path}</translation>
    </message>
    <message>
        <source>Oriented Rectangle</source>
        <translation>مستطیل جهت‌دار</translation>
    </message>
    <message>
        <source>Start drawing oriented rectangles</source>
        <translation>شروع رسم مستطیل جهت‌دار</translation>
    </message>
    <message>
        <source>AI inference produced no new annotation.</source>
        <translation>استنتاج هوش مصنوعی حاشیه‌نویسی جدیدی تولید نکرد.</translation>
    </message>
    <message>
        <source>Shape had no area; nothing created.</source>
        <translation>شکل فاقد مساحت بود؛ چیزی ایجاد نشد.</translation>
    </message>
    <message>
        <source>Settings…</source>
        <translation>تنظیمات…</translation>
    </message>
    <message>
        <source>Edit settings</source>
        <translation>ویرایش تنظیمات</translation>
    </message>
    <message>
        <source>Settings are managed via --config for this session</source>
        <translation>تنظیمات این نشست از طریق --config مدیریت می‌شوند</translation>
    </message>
    <message>
        <source>Configuration Error</source>
        <translation>خطای پیکربندی</translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <source>Color theme</source>
        <translation>تم رنگ</translation>
    </message>
    <message>
        <source>System</source>
        <translation>سیستم</translation>
    </message>
    <message>
        <source>Light</source>
        <translation>روشن</translation>
    </message>
    <message>
        <source>Dark</source>
        <translation>تیره</translation>
    </message>
    <message>
        <source>Show label popup on new shape</source>
        <translation>نمایش پنجره برچسب هنگام رسم شکل جدید</translation>
    </message>
    <message>
        <source>Show shape labels on canvas</source>
        <translation>نمایش برچسب شکل‌ها روی بوم</translation>
    </message>
    <message>
        <source>Allow points outside the image boundary</source>
        <translation>اجازه دادن به نقاط خارج از مرز تصویر</translation>
    </message>
    <message>
        <source>Appearance and language</source>
        <translation>ظاهر و زبان</translation>
    </message>
    <message>
        <source>Files and saving</source>
        <translation>فایل‌ها و ذخیره‌سازی</translation>
    </message>
    <message>
        <source>Drawing and canvas</source>
        <translation>رسم و بوم</translation>
    </message>
    <message>
        <source>Continue between images</source>
        <translation>ادامه بین تصاویر</translation>
    </message>
    <message>
        <source>Label sources</source>
        <translation>منابع برچسب</translation>
    </message>
    <message>
        <source>Label behavior</source>
        <translation>رفتار برچسب</translation>
    </message>
    <message>
        <source>AI assist</source>
        <translation>دستیار هوش مصنوعی</translation>
    </message>
    <message>
        <source>Save automatically</source>
        <translation>ذخیره خودکار</translation>
    </message>
    <message>
        <source>Save image data in label file</source>
        <translation>ذخیره داده تصویر در فایل برچسب</translation>
    </message>
    <message>
        <source>Embeds the image in the label JSON file.</source>
        <translation>تصویر را در فایل JSON برچسب جاسازی می‌کند.</translation>
    </message>
    <message>
        <source>Shape Color Mode</source>
        <translation>حالت رنگ شکل</translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation>خودکار</translation>
    </message>
    <message>
        <source>Uniform</source>
        <translation>یکنواخت</translation>
    </message>
    <message>
        <source>By Label</source>
        <translation>بر اساس برچسب</translation>
    </message>
    <message>
        <source>Automatic palette shift</source>
        <translation>جابجایی خودکار پالت</translation>
    </message>
    <message>
        <source>Uniform mode color</source>
        <translation>رنگ حالت یکنواخت</translation>
    </message>
    <message>
        <source>By Label fallback color</source>
        <translation>رنگ جایگزین حالت بر اساس برچسب</translation>
    </message>
    <message>
        <source>Individual Label colors remain editable in the Config File.</source>
        <translation>رنگ هر برچسب همچنان در فایل پیکربندی قابل ویرایش است.</translation>
    </message>
    <message>
        <source>Keep previous annotation</source>
        <translation>نگه داشتن حاشیه‌نویسی قبلی</translation>
    </message>
    <message>
        <source>Keep previous zoom</source>
        <translation>نگه داشتن بزرگ‌نمایی قبلی</translation>
    </message>
    <message>
        <source>Keep previous brightness/contrast</source>
        <translation>نگه داشتن روشنایی/کنتراست قبلی</translation>
    </message>
    <message>
        <source>Fill polygon while drawing</source>
        <translation>پر کردن چندضلعی هنگام رسم</translation>
    </message>
    <message>
        <source>Let shape points extend beyond the image, e.g. for partially visible objects.</source>
        <translation>به نقاط شکل اجازه می‌دهد فراتر از تصویر امتداد یابند، مثلاً برای اشیای تا حدی قابل مشاهده.</translation>
    </message>
    <message>
        <source>Polygon detail</source>
        <translation>جزئیات چندضلعی</translation>
    </message>
    <message>
        <source>Higher values preserve more Mask boundary detail and smaller lands.</source>
        <translation>مقادیر بالاتر جزئیات بیشتری از مرز ماسک و نواحی کوچک‌تر را حفظ می‌کنند.</translation>
    </message>
    <message>
        <source>Predefined labels</source>
        <translation>برچسب‌های از پیش تعریف‌شده</translation>
    </message>
    <message>
        <source>Label validation</source>
        <translation>اعتبارسنجی برچسب</translation>
    </message>
    <message>
        <source>Sort labels</source>
        <translation>مرتب‌سازی برچسب‌ها</translation>
    </message>
    <message>
        <source>Sort the label list alphabetically instead of keeping the provided order.</source>
        <translation>فهرست برچسب‌ها را به‌جای حفظ ترتیب ارائه‌شده، به‌صورت الفبایی مرتب می‌کند.</translation>
    </message>
    <message>
        <source>Show label text field</source>
        <translation>نمایش فیلد متنی برچسب</translation>
    </message>
    <message>
        <source>Label completion</source>
        <translation>تکمیل خودکار برچسب</translation>
    </message>
    <message>
        <source>Starts with</source>
        <translation>شروع می‌شود با</translation>
    </message>
    <message>
        <source>Contains</source>
        <translation>شامل</translation>
    </message>
    <message>
        <source>Default model</source>
        <translation>مدل پیش‌فرض</translation>
    </message>
    <message>
        <source>EfficientSam (speed)</source>
        <translation>EfficientSam (سرعت)</translation>
    </message>
    <message>
        <source>EfficientSam (accuracy)</source>
        <translation>EfficientSam (دقت)</translation>
    </message>
    <message>
        <source>Sam (speed)</source>
        <translation>Sam (سرعت)</translation>
    </message>
    <message>
        <source>Sam (balanced)</source>
        <translation>Sam (متعادل)</translation>
    </message>
    <message>
        <source>Sam (accuracy)</source>
        <translation>Sam (دقت)</translation>
    </message>
    <message>
        <source>Sam2 (speed)</source>
        <translation>Sam2 (سرعت)</translation>
    </message>
    <message>
        <source>Sam2 (balanced)</source>
        <translation>Sam2 (متعادل)</translation>
    </message>
    <message>
        <source>Sam2 (accuracy)</source>
        <translation>Sam2 (دقت)</translation>
    </message>
    <message>
        <source>Sam3</source>
        <translation>Sam3</translation>
    </message>
    <message>
        <source>Suppress existing Shape matches</source>
        <translation>نادیده گرفتن موارد منطبق با شکل‌های موجود</translation>
    </message>
    <message>
        <source>When an AI Assist candidate matches an existing Shape, highlight that Shape instead of creating a new Shape.</source>
        <translation>هنگامی که یک پیشنهاد دستیار هوش مصنوعی با یک شکل موجود منطبق باشد، به جای ایجاد شکل جدید همان شکل برجسته می‌شود.</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>تنظیمات</translation>
    </message>
    <message>
        <source>Open config file as text…</source>
        <translation>باز کردن فایل پیکربندی به صورت متن…</translation>
    </message>
    <message>
        <source>Edits made in the text file apply after restart</source>
        <translation>تغییرات فایل متنی پس از راه‌اندازی مجدد اعمال می‌شوند</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>بستن</translation>
    </message>
    <message>
        <source>BETA</source>
        <translation>BETA</translation>
    </message>
    <message>
        <source>(none)</source>
        <translation>(هیچ‌کدام)</translation>
    </message>
    <message>
        <source>one item per line</source>
        <translation>یک مورد در هر خط</translation>
    </message>
    <message>
        <source>Configuration Error</source>
        <translation>خطای پیکربندی</translation>
    </message>
    <message>
        <source>Predefined labels cannot be empty while Label validation is set to exact. Disable exact validation first.</source>
        <translation>برچسب‌های از پیش تعریف‌شده نمی‌توانند خالی باشند در حالی که اعتبارسنجی برچسب روی «exact» تنظیم شده است. ابتدا اعتبارسنجی «exact» را غیرفعال کنید.</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>زبان</translation>
    </message>
    <message>
        <source>Takes effect after restart.</source>
        <translation>پس از راه‌اندازی مجدد اعمال می‌شود.</translation>
    </message>
    <message>
        <source>System default</source>
        <translation>پیش‌فرض سیستم</translation>
    </message>
    <message>
        <source>Predefined image flags</source>
        <translation>پرچم‌های تصویر از پیش تعریف‌شده</translation>
    </message>
</context>
<context>
    <name>_ColorSwatchButton</name>
    <message>
        <source>RGB: {red}, {green}, {blue}</source>
        <translation>RGB: {red}, {green}, {blue}</translation>
    </message>
</context>
<context>
    <name>_SettingsPage</name>
    <message>
        <source>Settings sections</source>
        <translation>بخش‌های تنظیمات</translation>
    </message>
</context>
</TS>
