<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ja_JP">
<context>
    <name>AiAssistedAnnotationWidget</name>
    <message>
        <source>AI-Assisted Annotation</source>
        <translation>AI支援アノテーション</translation>
    </message>
    <message>
        <source>AI suggests annotation in &apos;AI-Points&apos; and &apos;AI-Box&apos; modes</source>
        <translation>AIが&apos;AI-Points&apos;および&apos;AI-Box&apos;モードでアノテーションを提案</translation>
    </message>
    <message>
        <source>Polygon detail</source>
        <translation>ポリゴンの詳細度</translation>
    </message>
    <message>
        <source>Adjust polygon detail</source>
        <translation>ポリゴンの詳細度を調整</translation>
    </message>
    <message>
        <source>Smoother</source>
        <translation>より滑らか</translation>
    </message>
    <message>
        <source>More detail</source>
        <translation>より詳細</translation>
    </message>
    <message>
        <source>Select &apos;AI-Points&apos; or &apos;AI-Box&apos; mode to enable AI-Assisted Annotation</source>
        <translation>&apos;AI-Points&apos;または&apos;AI-Box&apos;モードを選択してAI支援アノテーションを有効化</translation>
    </message>
</context>
<context>
    <name>AiTextToAnnotationWidget</name>
    <message>
        <source>AI Text-to-Annotation</source>
        <translation>AIプロンプト</translation>
    </message>
    <message>
        <source>e.g., dog,cat,bird</source>
        <translation>例: dog,cat,bird</translation>
    </message>
    <message>
        <source>Run</source>
        <translation>実行</translation>
    </message>
    <message>
        <source>Score</source>
        <translation>スコア</translation>
    </message>
    <message>
        <source>IoU</source>
        <translation>IoU</translation>
    </message>
    <message>
        <source>AI creates annotations from the text prompt</source>
        <translation>AIがテキストプロンプトからアノテーションを作成</translation>
    </message>
    <message>
        <source>Select &apos;Polygon&apos;, &apos;Rectangle&apos;, or &apos;AI-Points&apos; mode to enable</source>
        <translation>「Polygon」「Rectangle」または「AI-Points」モードで有効</translation>
    </message>
</context>
<context>
    <name>BrightnessContrastDialog</name>
    <message>
        <source>Brightness/Contrast</source>
        <translation>明るさ/コントラスト</translation>
    </message>
    <message>
        <source>Brightness:</source>
        <translation>明るさ:</translation>
    </message>
    <message>
        <source>Contrast:</source>
        <translation>コントラスト:</translation>
    </message>
</context>
<context>
    <name>Canvas</name>
    <message>
        <source>Click &amp; drag to move point</source>
        <translation>クリック &amp; ドラッグで頂点を移動</translation>
    </message>
    <message>
        <source>Click &amp; drag to move shape</source>
        <translation>クリック &amp; ドラッグで図形を移動</translation>
    </message>
    <message>
        <source>Creating %r</source>
        <translation>%r を作成中</translation>
    </message>
    <message>
        <source>ESC to cancel</source>
        <translation>ESC でキャンセル</translation>
    </message>
    <message>
        <source>Enter or Space to finalize</source>
        <translation>Enter または Space で確定</translation>
    </message>
    <message>
        <source>Editing shapes</source>
        <translation>図形を編集中</translation>
    </message>
    <message>
        <source>Click start point for line</source>
        <translation>直線の始点をクリック</translation>
    </message>
    <message>
        <source>Click end point for line</source>
        <translation>直線の終点をクリック</translation>
    </message>
    <message>
        <source>Click start point for linestrip</source>
        <translation>折れ線の始点をクリック</translation>
    </message>
    <message>
        <source>Click next point or finish by Ctrl/Cmd+Click for linestrip</source>
        <translation>次の点をクリック、または Ctrl/Cmd+クリックで完了</translation>
    </message>
    <message>
        <source>Click center point for circle</source>
        <translation>円の中心点をクリック</translation>
    </message>
    <message>
        <source>Click point on circumference for circle</source>
        <translation>円周上の点をクリック</translation>
    </message>
    <message>
        <source>Click first corner for rectangle</source>
        <translation>矩形の最初の角をクリック</translation>
    </message>
    <message>
        <source>Click to add point</source>
        <translation>クリックで頂点を追加</translation>
    </message>
    <message>
        <source>ALT + SHIFT + Click to delete point</source>
        <translation>ALT + SHIFT + クリックで頂点を削除</translation>
    </message>
    <message>
        <source>ALT + Click to create point on shape</source>
        <translation>ALT + クリックで図形上に頂点を作成</translation>
    </message>
    <message>
        <source>Right-click &amp; drag to copy shape</source>
        <translation>右クリック &amp; ドラッグで図形をコピー</translation>
    </message>
    <message>
        <source>Click opposite corner for rectangle (Shift for square)</source>
        <translation>矩形の対角をクリック（Shiftで正方形）</translation>
    </message>
    <message>
        <source>Click points to include or Shift+Click to exclude. Ctrl+LeftClick ends creation.</source>
        <translation>クリックで含める点を、Shift+Clickで除外する点を指定。Ctrl+LeftClickで作成を完了。</translation>
    </message>
    <message>
        <source>Click first corner of bbox for AI segmentation</source>
        <translation>AIセグメンテーション用にbboxの最初の角をクリック</translation>
    </message>
    <message>
        <source>Click opposite corner to segment object</source>
        <translation>対角をクリックしてオブジェクトをセグメント</translation>
    </message>
    <message>
        <source>Click first corner for oriented rectangle</source>
        <translation>向き付き矩形の最初の角をクリック</translation>
    </message>
    <message>
        <source>Click second corner to set orientation</source>
        <translation>2番目の角をクリックして向きを設定</translation>
    </message>
    <message>
        <source>Click third corner to close oriented rectangle</source>
        <translation>3番目の角をクリックして向き付き矩形を閉じる</translation>
    </message>
    <message>
        <source>Click &amp; drag to rotate the shape</source>
        <translation>クリック &amp; ドラッグで図形を回転</translation>
    </message>
</context>
<context>
    <name>EmptyStateWidget</name>
    <message>
        <source>Start annotating</source>
        <translation>アノテーションを開始</translation>
    </message>
    <message>
        <source>Open an image or a directory of images to begin.</source>
        <translation>画像または画像フォルダーを開いて開始します。</translation>
    </message>
    <message>
        <source>Open Image</source>
        <translation>画像を開く</translation>
    </message>
    <message>
        <source>Open Directory</source>
        <translation>フォルダーを開く</translation>
    </message>
    <message>
        <source>Or drag and drop image files here</source>
        <translation>または、画像ファイルをここにドラッグ＆ドロップします</translation>
    </message>
</context>
<context>
    <name>LabelDialog</name>
    <message>
        <source>Shape Label</source>
        <translation>図形のラベル</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>ラベル</translation>
    </message>
    <message>
        <source>Group ID</source>
        <translation>グループ ID</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>説明</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Flags</source>
        <translation>フラグ</translation>
    </message>
    <message>
        <source>Shape List</source>
        <translation>図形一覧</translation>
    </message>
    <message>
        <source>Select label to start annotating for it. Press &apos;Esc&apos; to deselect.</source>
        <translation>ラベルを選択してアノテーションを開始。&apos;Esc&apos; で選択解除。</translation>
    </message>
    <message>
        <source>Label List</source>
        <translation>ラベル一覧</translation>
    </message>
    <message>
        <source>Search Filename</source>
        <translation>ファイル名で検索</translation>
    </message>
    <message>
        <source>File List</source>
        <translation>ファイル一覧</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation>終了(&amp;Q)</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>アプリケーションを終了</translation>
    </message>
    <message>
        <source>&amp;Open
</source>
        <translation>開く(&amp;O)
</translation>
    </message>
    <message>
        <source>Open image or label file</source>
        <translation>画像またはラベルファイルを開く</translation>
    </message>
    <message>
        <source>Open Dir</source>
        <translation>ディレクトリを
開く</translation>
    </message>
    <message>
        <source>&amp;Next Image</source>
        <translation>次の
画像(&amp;N)</translation>
    </message>
    <message>
        <source>Open next (hold Ctl+Shift to copy labels)</source>
        <translation>次を開く (Ctrl+Shift でラベルをコピー)</translation>
    </message>
    <message>
        <source>&amp;Prev Image</source>
        <translation>前の
画像(&amp;P)</translation>
    </message>
    <message>
        <source>Open prev (hold Ctl+Shift to copy labels)</source>
        <translation>前を開く (Ctrl+Shift でラベルをコピー)</translation>
    </message>
    <message>
        <source>&amp;Save
</source>
        <translation>保存(&amp;S)
</translation>
    </message>
    <message>
        <source>Save labels to file</source>
        <translation>ラベルをファイルに保存</translation>
    </message>
    <message>
        <source>&amp;Save As</source>
        <translation>名前を付けて保存(&amp;A)</translation>
    </message>
    <message>
        <source>&amp;Delete File</source>
        <translation>ファイルを
削除(&amp;D)</translation>
    </message>
    <message>
        <source>Delete current label file</source>
        <translation>現在のラベルファイルを削除</translation>
    </message>
    <message>
        <source>&amp;Change Output Dir</source>
        <translation>出力先を変更(&amp;C)</translation>
    </message>
    <message>
        <source>Change where annotations are loaded/saved</source>
        <translation>アノテーションの読み込み/保存先を変更</translation>
    </message>
    <message>
        <source>Save &amp;Automatically</source>
        <translation>自動保存(&amp;A)</translation>
    </message>
    <message>
        <source>Save automatically</source>
        <translation>自動で保存</translation>
    </message>
    <message>
        <source>Save With Image Data</source>
        <translation>画像データと共に保存</translation>
    </message>
    <message>
        <source>Save image data in label file</source>
        <translation>ラベルファイルに画像データを含める</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>閉じる(&amp;C)</translation>
    </message>
    <message>
        <source>Close current file</source>
        <translation>現在のファイルを閉じる</translation>
    </message>
    <message>
        <source>Keep Previous Annotation</source>
        <translation>前のアノテーションを保持</translation>
    </message>
    <message>
        <source>Start drawing polygons</source>
        <translation>ポリゴンの描画を開始</translation>
    </message>
    <message>
        <source>Start drawing rectangles</source>
        <translation>矩形の描画を開始</translation>
    </message>
    <message>
        <source>Start drawing circles</source>
        <translation>円の描画を開始</translation>
    </message>
    <message>
        <source>Start drawing lines</source>
        <translation>直線の描画を開始</translation>
    </message>
    <message>
        <source>Start drawing points</source>
        <translation>点の描画を開始</translation>
    </message>
    <message>
        <source>Edit Shapes</source>
        <translation>図形を
編集</translation>
    </message>
    <message>
        <source>Move and edit the selected shapes</source>
        <translation>選択した図形を移動・編集</translation>
    </message>
    <message>
        <source>Delete Shapes</source>
        <translation>図形を
削除</translation>
    </message>
    <message>
        <source>Delete the selected shapes</source>
        <translation>選択した図形を削除</translation>
    </message>
    <message>
        <source>Duplicate Shapes</source>
        <translation>図形を
複製</translation>
    </message>
    <message>
        <source>Create a duplicate of the selected shapes</source>
        <translation>選択した図形の複製を作成</translation>
    </message>
    <message>
        <source>Undo last point</source>
        <translation>最後の頂点を取り消し</translation>
    </message>
    <message>
        <source>Undo last drawn point</source>
        <translation>最後に描画した頂点を取り消し</translation>
    </message>
    <message>
        <source>Remove Selected Point</source>
        <translation>選択した頂点を削除</translation>
    </message>
    <message>
        <source>Remove selected point from polygon</source>
        <translation>ポリゴンから選択した頂点を削除</translation>
    </message>
    <message>
        <source>Undo
</source>
        <translation>元に戻す</translation>
    </message>
    <message>
        <source>Undo last add and edit of shape</source>
        <translation>最後の図形追加・編集を元に戻す</translation>
    </message>
    <message>
        <source>&amp;Hide
Shapes</source>
        <translation>図形を
非表示(&amp;H)</translation>
    </message>
    <message>
        <source>Hide all shapes</source>
        <translation>すべての図形を非表示</translation>
    </message>
    <message>
        <source>&amp;Show
Shapes</source>
        <translation>図形を
表示(&amp;S)</translation>
    </message>
    <message>
        <source>Show all shapes</source>
        <translation>すべての図形を表示</translation>
    </message>
    <message>
        <source>&amp;Toggle
Shapes</source>
        <translation>図形を
切り替え(&amp;T)</translation>
    </message>
    <message>
        <source>Toggle all shapes</source>
        <translation>すべての図形の表示を切り替え</translation>
    </message>
    <message>
        <source>&amp;Tutorial</source>
        <translation>チュートリアル(&amp;T)</translation>
    </message>
    <message>
        <source>Show tutorial page</source>
        <translation>チュートリアルページを表示</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation>ズーム</translation>
    </message>
    <message>
        <source>Zoom &amp;In</source>
        <translation>拡大(&amp;I)</translation>
    </message>
    <message>
        <source>&amp;Zoom Out</source>
        <translation>縮小(&amp;Z)</translation>
    </message>
    <message>
        <source>&amp;Brightness Contrast</source>
        <translation>明るさ・
コントラスト(&amp;B)</translation>
    </message>
    <message>
        <source>Adjust brightness and contrast</source>
        <translation>明るさとコントラストを調整</translation>
    </message>
    <message>
        <source>&amp;Edit Label</source>
        <translation>ラベルを編集(&amp;E)</translation>
    </message>
    <message>
        <source>Save the labels under a new file name</source>
        <translation>ラベルを新しいファイル名で保存</translation>
    </message>
    <message>
        <source>Modify the label of the selected shape</source>
        <translation>選択した図形のラベルを変更</translation>
    </message>
    <message>
        <source>Copy to Clipboard</source>
        <translation>クリップボードにコピー</translation>
    </message>
    <message>
        <source>Place the selected shapes on the clipboard</source>
        <translation>選択した図形をクリップボードに置く</translation>
    </message>
    <message>
        <source>Paste from Clipboard</source>
        <translation>クリップボードから貼り付け</translation>
    </message>
    <message>
        <source>Insert the clipboard shapes into this image</source>
        <translation>クリップボードの図形をこの画像に挿入</translation>
    </message>
    <message>
        <source>Click to place linestrip points; Ctrl+click places the last one.</source>
        <translation>クリックで折れ線の点を置き、Ctrl+クリックで最後の点を置きます。</translation>
    </message>
    <message>
        <source>Fit to &amp;Window</source>
        <translation>ウィンドウに
合わせる(&amp;W)</translation>
    </message>
    <message>
        <source>Keep the whole image visible when the window is resized</source>
        <translation>ウィンドウのサイズ変更時も画像全体を表示し続ける</translation>
    </message>
    <message>
        <source>Fit to Wi&amp;dth</source>
        <translation>幅に合わせる(&amp;D)</translation>
    </message>
    <message>
        <source>Match the image width to the window when it is resized</source>
        <translation>ウィンドウのサイズ変更時に画像の幅をウィンドウに揃える</translation>
    </message>
    <message>
        <source>Make the image appear larger</source>
        <translation>画像を大きく表示する</translation>
    </message>
    <message>
        <source>Make the image appear smaller</source>
        <translation>画像を小さく表示する</translation>
    </message>
    <message>
        <source>&amp;Actual Size</source>
        <translation>実際のサイズ(&amp;A)</translation>
    </message>
    <message>
        <source>Show the image at 100%</source>
        <translation>画像を100%で表示する</translation>
    </message>
    <message>
        <source>Fill Drawing Polygon</source>
        <translation>描画中のポリゴンを塗りつぶす</translation>
    </message>
    <message>
        <source>Fill polygon while drawing</source>
        <translation>描画中にポリゴンを塗りつぶす</translation>
    </message>
    <message>
        <source>Ctrl+Wheel zooms the canvas</source>
        <translation>Ctrl+ホイールでキャンバスをズームします</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>ファイル(&amp;F)</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>編集(&amp;E)</translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation>表示(&amp;V)</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>ヘルプ(&amp;H)</translation>
    </message>
    <message>
        <source>%s started.</source>
        <translation>%s を起動しました</translation>
    </message>
    <message>
        <source>Mask Output Unavailable</source>
        <translation>マスク出力は利用できません</translation>
    </message>
    <message>
        <source>%s only detects bounding boxes and cannot create &apos;%s&apos; annotations.

Switch the AI Text-to-Annotation model to &apos;SAM3 (smart)&apos;, or set the output format to &apos;Rectangle&apos;.</source>
        <translation>%s はバウンディングボックスのみを検出するため、&apos;%s&apos; アノテーションを作成できません。

AI Text-to-Annotation モデルを &apos;SAM3 (smart)&apos; に切り替えるか、出力形式を &apos;Rectangle&apos; に設定してください。</translation>
    </message>
    <message>
        <source>Invalid label</source>
        <translation>無効なラベル</translation>
    </message>
    <message>
        <source>Invalid label &apos;{}&apos; with validation type &apos;{}&apos;</source>
        <translation>ラベル &apos;{}&apos; は検証タイプ &apos;{}&apos; では無効です</translation>
    </message>
    <message>
        <source>Error saving label data</source>
        <translation>ラベルデータの保存エラー</translation>
    </message>
    <message>
        <source>&lt;b&gt;%s&lt;/b&gt;</source>
        <translation>&lt;b&gt;%s&lt;/b&gt;</translation>
    </message>
    <message>
        <source>AI inference failed: %s</source>
        <translation>AI推論に失敗しました: %s</translation>
    </message>
    <message>
        <source>Error opening file</source>
        <translation>ファイルを開けませんでした</translation>
    </message>
    <message>
        <source>No such file: &lt;b&gt;%s&lt;/b&gt;</source>
        <translation>ファイルが見つかりません: &lt;b&gt;%s&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Loading %s...</source>
        <translation>%s を読み込み中...</translation>
    </message>
    <message>
        <source>Loaded %s</source>
        <translation>%s を読み込みました</translation>
    </message>
    <message>
        <source>Image &amp; Label files (%s)</source>
        <translation>画像とラベルファイル (%s)</translation>
    </message>
    <message>
        <source>%s - Choose Image or Label file</source>
        <translation>%s - 画像またはラベルファイルを選択</translation>
    </message>
    <message>
        <source>%s - Save/Load Annotations in Directory</source>
        <translation>%s - アノテーションの保存/読み込みディレクトリ</translation>
    </message>
    <message>
        <source>%s . Annotations will be saved/loaded in %s</source>
        <translation>%s - アノテーションは %s に保存/読み込みされます</translation>
    </message>
    <message>
        <source>%s - Choose File</source>
        <translation>%s - ファイルを選択</translation>
    </message>
    <message>
        <source>Label files (*%s)</source>
        <translation>ラベルファイル (*%s)</translation>
    </message>
    <message>
        <source>Choose File</source>
        <translation>ファイルを選択</translation>
    </message>
    <message>
        <source>Attention</source>
        <translation>注意</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>削除</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>キャンセル</translation>
    </message>
    <message>
        <source>Unavailable in AI-Points mode because this model does not support point prompts.</source>
        <translation>このモデルはポイントプロンプトに対応していないため、AI-Points モードでは利用できません。</translation>
    </message>
    <message>
        <source>Save annotations to &quot;{}&quot; before closing?</source>
        <translation>閉じる前にアノテーションを &quot;{}&quot; に保存しますか？</translation>
    </message>
    <message>
        <source>Save annotations?</source>
        <translation>アノテーションを保存しますか？</translation>
    </message>
    <message>
        <source>Delete {} shapes? You can restore them with Undo.</source>
        <translation>{} 個の図形を削除しますか？「元に戻す」で復元できます。</translation>
    </message>
    <message>
        <source>%s - Open Directory</source>
        <translation>%s - ディレクトリを開く</translation>
    </message>
    <message>
        <source>The image is too large to open: {width}x{height} pixels exceeds the {max_side} pixel per-side limit of the raster engine. Raising the decode limit will not help. Split the image into tiles (for example with gdal_retile.py) or open a smaller copy.</source>
        <translation>画像が大きすぎて開けません: {width}x{height} ピクセルはラスターエンジンの1辺あたり {max_side} ピクセルの上限を超えています。デコード上限を上げても解決しません。画像をタイルに分割する(例: gdal_retile.py)か、より小さいコピーを開いてください。</translation>
    </message>
    <message>
        <source>The image is too large to open: {width}x{height} pixels needs about {required} MB, but the decode limit is {limit} MB. Split the image into tiles (for example with gdal_retile.py) or open a smaller copy.</source>
        <translation>画像が大きすぎて開けません: {width}x{height} ピクセルには約 {required} MB が必要ですが、デコード上限は {limit} MB です。画像をタイルに分割する(例: gdal_retile.py)か、より小さいコピーを開いてください。</translation>
    </message>
    <message>
        <source>Toggle &quot;keep previous annotation&quot; mode</source>
        <translation>「前のアノテーションを保持」モードを切り替え</translation>
    </message>
    <message>
        <source>Keep Previous Brightness/Contrast</source>
        <translation>前の明るさ/コントラストを保持</translation>
    </message>
    <message>
        <source>Configuration Errors</source>
        <translation>設定エラー</translation>
    </message>
    <message>
        <source>Errors were found while loading the configuration. Please review the errors below and reload your configuration or ignore the erroneous lines.</source>
        <translation>設定の読み込み中にエラーが見つかりました。以下のエラーを確認し、設定を再読み込みするか、エラーのある行を無視してください。</translation>
    </message>
    <message>
        <source>Reset Layout</source>
        <translation>レイアウトをリセット</translation>
    </message>
    <message>
        <source>Polygon</source>
        <translation>ポリゴン</translation>
    </message>
    <message>
        <source>Rectangle</source>
        <translation>矩形</translation>
    </message>
    <message>
        <source>Circle</source>
        <translation>円</translation>
    </message>
    <message>
        <source>Line</source>
        <translation>直線</translation>
    </message>
    <message>
        <source>Point</source>
        <translation>点</translation>
    </message>
    <message>
        <source>LineStrip</source>
        <translation>折れ線</translation>
    </message>
    <message>
        <source>AI-Points</source>
        <translation>AI-Points</translation>
    </message>
    <message>
        <source>Click points to segment object. Ctrl+LeftClick ends creation.</source>
        <translation>クリックでオブジェクトをセグメント。Ctrl+LeftClickで作成を完了。</translation>
    </message>
    <message>
        <source>AI-Box</source>
        <translation>AI-Box</translation>
    </message>
    <message>
        <source>Draw a bounding box to segment object.</source>
        <translation>バウンディングボックスを描画してオブジェクトをセグメント。</translation>
    </message>
    <message>
        <source>AI-Points Unavailable</source>
        <translation>AI-Pointsは利用できません</translation>
    </message>
    <message>
        <source>%s does not support point prompts.
Please select a different model or use AI-Box mode.</source>
        <translation>%s はポイントプロンプトに対応していません。
別のモデルを選択するか、AI-Boxモードを使用してください。</translation>
    </message>
    <message>
        <source>File list is disabled when a label file is opened</source>
        <translation>ラベルファイルを開いている場合、ファイルリストは無効です</translation>
    </message>
    <message>
        <source>Add Point to Edge</source>
        <translation>辺に頂点を追加</translation>
    </message>
    <message>
        <source>Insert a new point at the hovered polygon edge</source>
        <translation>カーソル位置のポリゴンの辺に新しい頂点を挿入</translation>
    </message>
    <message>
        <source>&amp;Keep Previous Zoom</source>
        <translation>前のズームを保持(&amp;K)</translation>
    </message>
    <message>
        <source>Permanently delete this label file? This action cannot be undone.</source>
        <translation>このラベルファイルを完全に削除しますか？この操作は元に戻せません。</translation>
    </message>
    <message>
        <source>Allowed formats: {formats}</source>
        <translation>対応形式: {formats}</translation>
    </message>
    <message>
        <source>The selected label file could not be opened: {path}</source>
        <translation>選択されたラベルファイルを開けませんでした: {path}</translation>
    </message>
    <message>
        <source>The selected image file could not be opened: {path}</source>
        <translation>選択された画像ファイルを開けませんでした: {path}</translation>
    </message>
    <message>
        <source>Failed to load: {path}</source>
        <translation>読み込みに失敗しました: {path}</translation>
    </message>
    <message>
        <source>Oriented Rectangle</source>
        <translation>向き付き矩形</translation>
    </message>
    <message>
        <source>Start drawing oriented rectangles</source>
        <translation>向き付き矩形の描画を開始</translation>
    </message>
    <message>
        <source>AI inference produced no new annotation.</source>
        <translation>AI推論で新しいアノテーションは生成されませんでした。</translation>
    </message>
    <message>
        <source>Shape had no area; nothing created.</source>
        <translation>図形に面積がないため、作成されませんでした。</translation>
    </message>
    <message>
        <source>Settings…</source>
        <translation>設定…</translation>
    </message>
    <message>
        <source>Edit settings</source>
        <translation>設定を編集</translation>
    </message>
    <message>
        <source>Settings are managed via --config for this session</source>
        <translation>このセッションの設定は --config で管理されています</translation>
    </message>
    <message>
        <source>Configuration Error</source>
        <translation>設定エラー</translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <source>Color theme</source>
        <translation>カラーテーマ</translation>
    </message>
    <message>
        <source>System</source>
        <translation>システム</translation>
    </message>
    <message>
        <source>Light</source>
        <translation>ライト</translation>
    </message>
    <message>
        <source>Dark</source>
        <translation>ダーク</translation>
    </message>
    <message>
        <source>Show label popup on new shape</source>
        <translation>新しい図形の作成時にラベルポップアップを表示</translation>
    </message>
    <message>
        <source>Show shape labels on canvas</source>
        <translation>図形のラベルをキャンバスに表示</translation>
    </message>
    <message>
        <source>Allow points outside the image boundary</source>
        <translation>画像の境界外への点の配置を許可する</translation>
    </message>
    <message>
        <source>Appearance and language</source>
        <translation>外観と言語</translation>
    </message>
    <message>
        <source>Files and saving</source>
        <translation>ファイルと保存</translation>
    </message>
    <message>
        <source>Drawing and canvas</source>
        <translation>描画とキャンバス</translation>
    </message>
    <message>
        <source>Continue between images</source>
        <translation>画像間で引き継ぐ</translation>
    </message>
    <message>
        <source>Label sources</source>
        <translation>ラベルのソース</translation>
    </message>
    <message>
        <source>Label behavior</source>
        <translation>ラベルの動作</translation>
    </message>
    <message>
        <source>AI assist</source>
        <translation>AI アシスト</translation>
    </message>
    <message>
        <source>Save automatically</source>
        <translation>自動で保存</translation>
    </message>
    <message>
        <source>Save image data in label file</source>
        <translation>ラベルファイルに画像データを含める</translation>
    </message>
    <message>
        <source>Embeds the image in the label JSON file.</source>
        <translation>画像をラベル JSON ファイルに埋め込みます。</translation>
    </message>
    <message>
        <source>Shape Color Mode</source>
        <translation>図形のカラーモード</translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation>自動</translation>
    </message>
    <message>
        <source>Uniform</source>
        <translation>均一</translation>
    </message>
    <message>
        <source>By Label</source>
        <translation>ラベル別</translation>
    </message>
    <message>
        <source>Automatic palette shift</source>
        <translation>自動パレットシフト</translation>
    </message>
    <message>
        <source>Uniform mode color</source>
        <translation>「均一」モードの色</translation>
    </message>
    <message>
        <source>By Label fallback color</source>
        <translation>「ラベル別」モードのフォールバック色</translation>
    </message>
    <message>
        <source>Individual Label colors remain editable in the Config File.</source>
        <translation>ラベルごとの色は引き続き設定ファイルで編集できます。</translation>
    </message>
    <message>
        <source>Keep previous annotation</source>
        <translation>前回のアノテーションを維持</translation>
    </message>
    <message>
        <source>Keep previous zoom</source>
        <translation>前回のズームを維持</translation>
    </message>
    <message>
        <source>Keep previous brightness/contrast</source>
        <translation>前回の明るさ/コントラストを維持</translation>
    </message>
    <message>
        <source>Fill polygon while drawing</source>
        <translation>描画中にポリゴンを塗りつぶす</translation>
    </message>
    <message>
        <source>Let shape points extend beyond the image, e.g. for partially visible objects.</source>
        <translation>図形の点が画像の外まで広がることを許可します（例: 部分的にしか見えない物体）。</translation>
    </message>
    <message>
        <source>Polygon detail</source>
        <translation>ポリゴンの詳細度</translation>
    </message>
    <message>
        <source>Higher values preserve more Mask boundary detail and smaller lands.</source>
        <translation>値を高くすると、マスク境界の詳細と小さな領域がより多く保持されます。</translation>
    </message>
    <message>
        <source>Predefined labels</source>
        <translation>定義済みラベル</translation>
    </message>
    <message>
        <source>Label validation</source>
        <translation>ラベルの検証</translation>
    </message>
    <message>
        <source>Sort labels</source>
        <translation>ラベルを並べ替える</translation>
    </message>
    <message>
        <source>Sort the label list alphabetically instead of keeping the provided order.</source>
        <translation>指定された順序を維持する代わりに、ラベル一覧をアルファベット順に並べ替えます。</translation>
    </message>
    <message>
        <source>Show label text field</source>
        <translation>ラベルのテキスト入力欄を表示</translation>
    </message>
    <message>
        <source>Label completion</source>
        <translation>ラベル補完</translation>
    </message>
    <message>
        <source>Starts with</source>
        <translation>先頭一致</translation>
    </message>
    <message>
        <source>Contains</source>
        <translation>含む</translation>
    </message>
    <message>
        <source>Default model</source>
        <translation>デフォルトモデル</translation>
    </message>
    <message>
        <source>EfficientSam (speed)</source>
        <translation>EfficientSam (高速)</translation>
    </message>
    <message>
        <source>EfficientSam (accuracy)</source>
        <translation>EfficientSam (高精度)</translation>
    </message>
    <message>
        <source>Sam (speed)</source>
        <translation>Sam (高速)</translation>
    </message>
    <message>
        <source>Sam (balanced)</source>
        <translation>Sam (バランス)</translation>
    </message>
    <message>
        <source>Sam (accuracy)</source>
        <translation>Sam (高精度)</translation>
    </message>
    <message>
        <source>Sam2 (speed)</source>
        <translation>Sam2 (高速)</translation>
    </message>
    <message>
        <source>Sam2 (balanced)</source>
        <translation>Sam2 (バランス)</translation>
    </message>
    <message>
        <source>Sam2 (accuracy)</source>
        <translation>Sam2 (高精度)</translation>
    </message>
    <message>
        <source>Sam3</source>
        <translation>Sam3</translation>
    </message>
    <message>
        <source>Suppress existing Shape matches</source>
        <translation>既存の図形と一致する候補を抑制</translation>
    </message>
    <message>
        <source>When an AI Assist candidate matches an existing Shape, highlight that Shape instead of creating a new Shape.</source>
        <translation>AI アシストの候補が既存の図形と一致する場合、新しい図形を作成せずにその図形を強調表示します。</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>設定</translation>
    </message>
    <message>
        <source>Open config file as text…</source>
        <translation>設定ファイルをテキストとして開く…</translation>
    </message>
    <message>
        <source>Edits made in the text file apply after restart</source>
        <translation>テキストファイルでの変更は再起動後に反映されます</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>閉じる</translation>
    </message>
    <message>
        <source>BETA</source>
        <translation>BETA</translation>
    </message>
    <message>
        <source>(none)</source>
        <translation>（なし）</translation>
    </message>
    <message>
        <source>one item per line</source>
        <translation>1行に1項目</translation>
    </message>
    <message>
        <source>Configuration Error</source>
        <translation>設定エラー</translation>
    </message>
    <message>
        <source>Predefined labels cannot be empty while Label validation is set to exact. Disable exact validation first.</source>
        <translation>ラベルの検証が「exact」に設定されている間は、定義済みラベルを空にできません。先に「exact」検証を無効にしてください。</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>言語</translation>
    </message>
    <message>
        <source>Takes effect after restart.</source>
        <translation>再起動後に反映されます。</translation>
    </message>
    <message>
        <source>System default</source>
        <translation>システム言語</translation>
    </message>
    <message>
        <source>Predefined image flags</source>
        <translation>定義済み画像フラグ</translation>
    </message>
</context>
<context>
    <name>_ColorSwatchButton</name>
    <message>
        <source>RGB: {red}, {green}, {blue}</source>
        <translation>RGB: {red}, {green}, {blue}</translation>
    </message>
</context>
<context>
    <name>_SettingsPage</name>
    <message>
        <source>Settings sections</source>
        <translation>設定セクション</translation>
    </message>
</context>
</TS>
