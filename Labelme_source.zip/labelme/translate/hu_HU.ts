<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="hu_HU">
<context>
    <name>AiAssistedAnnotationWidget</name>
    <message>
        <source>AI-Assisted Annotation</source>
        <translation>MI-támogatott annotáció</translation>
    </message>
    <message>
        <source>AI suggests annotation in &apos;AI-Points&apos; and &apos;AI-Box&apos; modes</source>
        <translation>Az AI annotációt javasol &apos;AI-Points&apos; és &apos;AI-Box&apos; módokban</translation>
    </message>
    <message>
        <source>Polygon detail</source>
        <translation>Poligon részletessége</translation>
    </message>
    <message>
        <source>Adjust polygon detail</source>
        <translation>Poligon részletességének beállítása</translation>
    </message>
    <message>
        <source>Smoother</source>
        <translation>Simább</translation>
    </message>
    <message>
        <source>More detail</source>
        <translation>Részletesebb</translation>
    </message>
    <message>
        <source>Select &apos;AI-Points&apos; or &apos;AI-Box&apos; mode to enable AI-Assisted Annotation</source>
        <translation>Válassza az &apos;AI-Points&apos; vagy &apos;AI-Box&apos; módot az AI-támogatott annotáció engedélyezéséhez</translation>
    </message>
</context>
<context>
    <name>AiTextToAnnotationWidget</name>
    <message>
        <source>AI Text-to-Annotation</source>
        <translation>AI prompt</translation>
    </message>
    <message>
        <source>e.g., dog,cat,bird</source>
        <translation>pl. kutya,macska,madár</translation>
    </message>
    <message>
        <source>Run</source>
        <translation>Futtatás</translation>
    </message>
    <message>
        <source>Score</source>
        <translation>Pontszám</translation>
    </message>
    <message>
        <source>IoU</source>
        <translation>IoU</translation>
    </message>
    <message>
        <source>AI creates annotations from the text prompt</source>
        <translation>Az AI annotációkat hoz létre a szöveges promptból</translation>
    </message>
    <message>
        <source>Select &apos;Polygon&apos;, &apos;Rectangle&apos;, or &apos;AI-Points&apos; mode to enable</source>
        <translation>Válassza a &apos;Polygon&apos;, &apos;Rectangle&apos; vagy &apos;AI-Points&apos; módot az engedélyezéshez</translation>
    </message>
</context>
<context>
    <name>BrightnessContrastDialog</name>
    <message>
        <source>Brightness/Contrast</source>
        <translation>Fényerő/Kontraszt</translation>
    </message>
    <message>
        <source>Brightness:</source>
        <translation>Fényerő:</translation>
    </message>
    <message>
        <source>Contrast:</source>
        <translation>Kontraszt:</translation>
    </message>
</context>
<context>
    <name>Canvas</name>
    <message>
        <source>Creating %r</source>
        <translation>%r létrehozása</translation>
    </message>
    <message>
        <source>ESC to cancel</source>
        <translation>ESC a megszakításhoz</translation>
    </message>
    <message>
        <source>Enter or Space to finalize</source>
        <translation>Enter vagy Szóköz a befejezéshez</translation>
    </message>
    <message>
        <source>Editing shapes</source>
        <translation>Alakzatok szerkesztése</translation>
    </message>
    <message>
        <source>Click start point for line</source>
        <translation>Kattintson a vonal kezdőpontjára</translation>
    </message>
    <message>
        <source>Click end point for line</source>
        <translation>Kattintson a vonal végpontjára</translation>
    </message>
    <message>
        <source>Click start point for linestrip</source>
        <translation>Kattintson a vonallánc kezdőpontjára</translation>
    </message>
    <message>
        <source>Click next point or finish by Ctrl/Cmd+Click for linestrip</source>
        <translation>Kattintson a következő pontra vagy Ctrl/Cmd+Kattintás a befejezéshez (vonallánc)</translation>
    </message>
    <message>
        <source>Click center point for circle</source>
        <translation>Kattintson a kör középpontjára</translation>
    </message>
    <message>
        <source>Click point on circumference for circle</source>
        <translation>Kattintson a kör kerületén lévő pontra</translation>
    </message>
    <message>
        <source>Click first corner for rectangle</source>
        <translation>Kattintson a téglalap első sarkára</translation>
    </message>
    <message>
        <source>Click to add point</source>
        <translation>Kattintson pont hozzáadásához</translation>
    </message>
    <message>
        <source>Click &amp; drag to move point</source>
        <translation>Kattintson és húzza a pont mozgatásához</translation>
    </message>
    <message>
        <source>ALT + SHIFT + Click to delete point</source>
        <translation>ALT + SHIFT + Kattintás a pont törléséhez</translation>
    </message>
    <message>
        <source>ALT + Click to create point on shape</source>
        <translation>ALT + Kattintás pont létrehozásához az alakzaton</translation>
    </message>
    <message>
        <source>Click &amp; drag to move shape</source>
        <translation>Kattintson és húzza az alakzat mozgatásához</translation>
    </message>
    <message>
        <source>Right-click &amp; drag to copy shape</source>
        <translation>Jobb gombbal kattintás és húzás az alakzat másolásához</translation>
    </message>
    <message>
        <source>Click opposite corner for rectangle (Shift for square)</source>
        <translation>Kattintson a téglalap ellentétes sarkára (Shift a négyzethez)</translation>
    </message>
    <message>
        <source>Click points to include or Shift+Click to exclude. Ctrl+LeftClick ends creation.</source>
        <translation>Kattintson pontokra a hozzáadáshoz vagy Shift+Click a kizáráshoz. Ctrl+LeftClick befejezi a létrehozást.</translation>
    </message>
    <message>
        <source>Click first corner of bbox for AI segmentation</source>
        <translation>Kattintson a bbox első sarkára az AI szegmentáláshoz</translation>
    </message>
    <message>
        <source>Click opposite corner to segment object</source>
        <translation>Kattintson az átellenes sarokra az objektum szegmentálásához</translation>
    </message>
    <message>
        <source>Click first corner for oriented rectangle</source>
        <translation>Kattintson az irányított téglalap első sarkára</translation>
    </message>
    <message>
        <source>Click second corner to set orientation</source>
        <translation>Kattintson a második sarokra az irány beállításához</translation>
    </message>
    <message>
        <source>Click third corner to close oriented rectangle</source>
        <translation>Kattintson a harmadik sarokra az irányított téglalap bezárásához</translation>
    </message>
    <message>
        <source>Click &amp; drag to rotate the shape</source>
        <translation>Kattintson és húzza az alakzat elforgatásához</translation>
    </message>
</context>
<context>
    <name>EmptyStateWidget</name>
    <message>
        <source>Start annotating</source>
        <translation>Annotálás indítása</translation>
    </message>
    <message>
        <source>Open an image or a directory of images to begin.</source>
        <translation>A kezdéshez nyisson meg egy képet vagy egy képeket tartalmazó mappát.</translation>
    </message>
    <message>
        <source>Open Image</source>
        <translation>Kép megnyitása</translation>
    </message>
    <message>
        <source>Open Directory</source>
        <translation>Mappa megnyitása</translation>
    </message>
    <message>
        <source>Or drag and drop image files here</source>
        <translation>Vagy húzzon ide képfájlokat</translation>
    </message>
</context>
<context>
    <name>LabelDialog</name>
    <message>
        <source>Shape Label</source>
        <translation>Alakzat címkéje</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Címke</translation>
    </message>
    <message>
        <source>Group ID</source>
        <translation>Csoportazonosító</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Leírás</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Flags</source>
        <translation>Jelzők</translation>
    </message>
    <message>
        <source>Shape List</source>
        <translation>Alakzatlista</translation>
    </message>
    <message>
        <source>Select label to start annotating for it. Press &apos;Esc&apos; to deselect.</source>
        <translation>Válasszon címkét az annotálás megkezdéséhez. Nyomja meg az &apos;Esc&apos; gombot a kijelölés megszüntetéséhez.</translation>
    </message>
    <message>
        <source>Label List</source>
        <translation>Címkelista</translation>
    </message>
    <message>
        <source>Search Filename</source>
        <translation>Fájlnév keresése</translation>
    </message>
    <message>
        <source>File List</source>
        <translation>Fájllista</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation>&amp;Kilépés</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>Alkalmazás bezárása</translation>
    </message>
    <message>
        <source>&amp;Open
</source>
        <translation>&amp;Megnyitás
</translation>
    </message>
    <message>
        <source>Open image or label file</source>
        <translation>Kép vagy címke fájl megnyitása</translation>
    </message>
    <message>
        <source>Open Dir</source>
        <translation>Könyvtár megnyitása</translation>
    </message>
    <message>
        <source>&amp;Next Image</source>
        <translation>&amp;Következő kép</translation>
    </message>
    <message>
        <source>Open next (hold Ctl+Shift to copy labels)</source>
        <translation>Következő megnyitása (tartsa lenyomva a Ctrl+Shift-et a címkék másolásához)</translation>
    </message>
    <message>
        <source>&amp;Prev Image</source>
        <translation>&amp;Előző kép</translation>
    </message>
    <message>
        <source>Open prev (hold Ctl+Shift to copy labels)</source>
        <translation>Előző megnyitása (tartsa lenyomva a Ctrl+Shift-et a címkék másolásához)</translation>
    </message>
    <message>
        <source>&amp;Save
</source>
        <translation>&amp;Mentés
</translation>
    </message>
    <message>
        <source>Save labels to file</source>
        <translation>Címkék mentése fájlba</translation>
    </message>
    <message>
        <source>&amp;Save As</source>
        <translation>Mentés &amp;másként</translation>
    </message>
    <message>
        <source>&amp;Delete File</source>
        <translation>&amp;Fájl törlése</translation>
    </message>
    <message>
        <source>Delete current label file</source>
        <translation>Jelenlegi címke fájl törlése</translation>
    </message>
    <message>
        <source>&amp;Change Output Dir</source>
        <translation>&amp;Kimeneti könyvtár módosítása</translation>
    </message>
    <message>
        <source>Change where annotations are loaded/saved</source>
        <translation>Az annotációk betöltési/mentési helyének módosítása</translation>
    </message>
    <message>
        <source>Save &amp;Automatically</source>
        <translation>&amp;Automatikus mentés</translation>
    </message>
    <message>
        <source>Save automatically</source>
        <translation>Automatikus mentés</translation>
    </message>
    <message>
        <source>Save With Image Data</source>
        <translation>Mentés kép adatokkal</translation>
    </message>
    <message>
        <source>Save image data in label file</source>
        <translation>Kép adatok mentése a címke fájlba</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Bezárás</translation>
    </message>
    <message>
        <source>Close current file</source>
        <translation>Jelenlegi fájl bezárása</translation>
    </message>
    <message>
        <source>Keep Previous Annotation</source>
        <translation>Előző annotáció megtartása</translation>
    </message>
    <message>
        <source>Toggle &quot;keep previous annotation&quot; mode</source>
        <translation>&quot;Előző annotáció megtartása&quot; mód váltása</translation>
    </message>
    <message>
        <source>Start drawing polygons</source>
        <translation>Sokszögek rajzolásának megkezdése</translation>
    </message>
    <message>
        <source>Start drawing rectangles</source>
        <translation>Téglalapok rajzolásának megkezdése</translation>
    </message>
    <message>
        <source>Start drawing circles</source>
        <translation>Körök rajzolásának megkezdése</translation>
    </message>
    <message>
        <source>Start drawing lines</source>
        <translation>Vonalak rajzolásának megkezdése</translation>
    </message>
    <message>
        <source>Start drawing points</source>
        <translation>Pontok rajzolásának megkezdése</translation>
    </message>
    <message>
        <source>Edit Shapes</source>
        <translation>Alakzatok szerkesztése</translation>
    </message>
    <message>
        <source>Move and edit the selected shapes</source>
        <translation>A kijelölt alakzatok mozgatása és szerkesztése</translation>
    </message>
    <message>
        <source>Delete Shapes</source>
        <translation>Alakzatok törlése</translation>
    </message>
    <message>
        <source>Delete the selected shapes</source>
        <translation>A kijelölt alakzatok törlése</translation>
    </message>
    <message>
        <source>Duplicate Shapes</source>
        <translation>Alakzatok duplikálása</translation>
    </message>
    <message>
        <source>Create a duplicate of the selected shapes</source>
        <translation>A kijelölt alakzatok másolatának létrehozása</translation>
    </message>
    <message>
        <source>Undo last point</source>
        <translation>Utolsó pont visszavonása</translation>
    </message>
    <message>
        <source>Undo last drawn point</source>
        <translation>Utolsó rajzolt pont visszavonása</translation>
    </message>
    <message>
        <source>Remove Selected Point</source>
        <translation>Kijelölt pont eltávolítása</translation>
    </message>
    <message>
        <source>Remove selected point from polygon</source>
        <translation>Kijelölt pont eltávolítása a sokszögből</translation>
    </message>
    <message>
        <source>Undo
</source>
        <translation>Visszavonás
</translation>
    </message>
    <message>
        <source>Undo last add and edit of shape</source>
        <translation>Alakzat utolsó hozzáadásának és szerkesztésének visszavonása</translation>
    </message>
    <message>
        <source>&amp;Hide
Shapes</source>
        <translation>Alakzatok
&amp;elrejtése</translation>
    </message>
    <message>
        <source>Hide all shapes</source>
        <translation>Összes alakzat elrejtése</translation>
    </message>
    <message>
        <source>&amp;Show
Shapes</source>
        <translation>Alakzatok
&amp;megjelenítése</translation>
    </message>
    <message>
        <source>Show all shapes</source>
        <translation>Összes alakzat megjelenítése</translation>
    </message>
    <message>
        <source>&amp;Toggle
Shapes</source>
        <translation>Alakzatok
&amp;váltása</translation>
    </message>
    <message>
        <source>Toggle all shapes</source>
        <translation>Összes alakzat váltása</translation>
    </message>
    <message>
        <source>&amp;Tutorial</source>
        <translation>&amp;Oktatóanyag</translation>
    </message>
    <message>
        <source>Show tutorial page</source>
        <translation>Oktatóanyag oldal megjelenítése</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation>Nagyítás</translation>
    </message>
    <message>
        <source>Zoom &amp;In</source>
        <translation>&amp;Nagyítás</translation>
    </message>
    <message>
        <source>&amp;Zoom Out</source>
        <translation>&amp;Kicsinyítés</translation>
    </message>
    <message>
        <source>&amp;Brightness Contrast</source>
        <translation>&amp;Fényerő/Kontraszt</translation>
    </message>
    <message>
        <source>Adjust brightness and contrast</source>
        <translation>Fényerő és kontraszt beállítása</translation>
    </message>
    <message>
        <source>&amp;Edit Label</source>
        <translation>&amp;Címke szerkesztése</translation>
    </message>
    <message>
        <source>Modify the label of the selected shape</source>
        <translation>A kijelölt alakzat címkéjének módosítása</translation>
    </message>
    <message>
        <source>Fill Drawing Polygon</source>
        <translation>Rajzolt sokszög kitöltése</translation>
    </message>
    <message>
        <source>Fill polygon while drawing</source>
        <translation>Sokszög kitöltése rajzolás közben</translation>
    </message>
    <message>
        <source>Keep Previous Brightness/Contrast</source>
        <translation>Előző fényerő/kontraszt megtartása</translation>
    </message>
    <message>
        <source>Save the labels under a new file name</source>
        <translation>Címkék mentése új fájlnéven</translation>
    </message>
    <message>
        <source>Copy to Clipboard</source>
        <translation>Másolás a vágólapra</translation>
    </message>
    <message>
        <source>Place the selected shapes on the clipboard</source>
        <translation>A kijelölt alakzatok vágólapra helyezése</translation>
    </message>
    <message>
        <source>Paste from Clipboard</source>
        <translation>Beillesztés a vágólapról</translation>
    </message>
    <message>
        <source>Insert the clipboard shapes into this image</source>
        <translation>A vágólap alakzatainak beszúrása ebbe a képbe</translation>
    </message>
    <message>
        <source>Click to place linestrip points; Ctrl+click places the last one.</source>
        <translation>Kattintson a vonallánc pontjainak elhelyezéséhez; Ctrl+kattintás helyezi el az utolsót.</translation>
    </message>
    <message>
        <source>Fit to &amp;Window</source>
        <translation>&amp;Ablakhoz igazítás</translation>
    </message>
    <message>
        <source>Keep the whole image visible when the window is resized</source>
        <translation>A teljes kép látható marad az ablak átméretezésekor</translation>
    </message>
    <message>
        <source>Fit to Wi&amp;dth</source>
        <translation>&amp;Szélességhez igazítás</translation>
    </message>
    <message>
        <source>Match the image width to the window when it is resized</source>
        <translation>A kép szélessége az ablakhoz igazodik annak átméretezésekor</translation>
    </message>
    <message>
        <source>Make the image appear larger</source>
        <translation>A kép nagyobb megjelenítése</translation>
    </message>
    <message>
        <source>Make the image appear smaller</source>
        <translation>A kép kisebb megjelenítése</translation>
    </message>
    <message>
        <source>&amp;Actual Size</source>
        <translation>&amp;Tényleges méret</translation>
    </message>
    <message>
        <source>Show the image at 100%</source>
        <translation>A kép megjelenítése 100%-on</translation>
    </message>
    <message>
        <source>Ctrl+Wheel zooms the canvas</source>
        <translation>A Ctrl+Görgő nagyítja a vásznat</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Fájl</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Szerkesztés</translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation>&amp;Nézet</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Súgó</translation>
    </message>
    <message>
        <source>%s started.</source>
        <translation>%s elindítva.</translation>
    </message>
    <message>
        <source>Mask Output Unavailable</source>
        <translation>A maszk kimenet nem érhető el</translation>
    </message>
    <message>
        <source>%s only detects bounding boxes and cannot create &apos;%s&apos; annotations.

Switch the AI Text-to-Annotation model to &apos;SAM3 (smart)&apos;, or set the output format to &apos;Rectangle&apos;.</source>
        <translation>A(z) %s csak határolókereteket észlel, és nem tud &apos;%s&apos; típusú annotációkat létrehozni.

Váltson az AI Text-to-Annotation modellnél &apos;SAM3 (smart)&apos;-re, vagy állítsa a kimeneti formátumot &apos;Rectangle&apos; értékre.</translation>
    </message>
    <message>
        <source>Invalid label</source>
        <translation>Érvénytelen címke</translation>
    </message>
    <message>
        <source>Invalid label &apos;{}&apos; with validation type &apos;{}&apos;</source>
        <translation>Érvénytelen címke &apos;{}&apos; &apos;{}&apos; validációs típussal</translation>
    </message>
    <message>
        <source>Error saving label data</source>
        <translation>Hiba a címke adatok mentésekor</translation>
    </message>
    <message>
        <source>&lt;b&gt;%s&lt;/b&gt;</source>
        <translation>&lt;b&gt;%s&lt;/b&gt;</translation>
    </message>
    <message>
        <source>AI inference failed: %s</source>
        <translation>Az MI-következtetés sikertelen volt: %s</translation>
    </message>
    <message>
        <source>Error opening file</source>
        <translation>Hiba a fájl megnyitásakor</translation>
    </message>
    <message>
        <source>No such file: &lt;b&gt;%s&lt;/b&gt;</source>
        <translation>Nincs ilyen fájl: &lt;b&gt;%s&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Loading %s...</source>
        <translation>%s betöltése...</translation>
    </message>
    <message>
        <source>Loaded %s</source>
        <translation>%s betöltve</translation>
    </message>
    <message>
        <source>Image &amp; Label files (%s)</source>
        <translation>Kép és címke fájlok (%s)</translation>
    </message>
    <message>
        <source>%s - Choose Image or Label file</source>
        <translation>%s - Válasszon képet vagy címke fájlt</translation>
    </message>
    <message>
        <source>%s - Save/Load Annotations in Directory</source>
        <translation>%s - Annotációk mentése/betöltése könyvtárból</translation>
    </message>
    <message>
        <source>%s . Annotations will be saved/loaded in %s</source>
        <translation>%s . Az annotációk a %s könyvtárban lesznek mentve/betöltve</translation>
    </message>
    <message>
        <source>%s - Choose File</source>
        <translation>%s - Fájl kiválasztása</translation>
    </message>
    <message>
        <source>Label files (*%s)</source>
        <translation>Címke fájlok (*%s)</translation>
    </message>
    <message>
        <source>Choose File</source>
        <translation>Fájl kiválasztása</translation>
    </message>
    <message>
        <source>Attention</source>
        <translation>Figyelem</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Törlés</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Mégse</translation>
    </message>
    <message>
        <source>Unavailable in AI-Points mode because this model does not support point prompts.</source>
        <translation>Nem érhető el AI-Points módban, mert ez a modell nem támogatja a pont alapú promptokat.</translation>
    </message>
    <message>
        <source>Save annotations to &quot;{}&quot; before closing?</source>
        <translation>Mentse az annotációkat a &quot;{}&quot; fájlba bezárás előtt?</translation>
    </message>
    <message>
        <source>Save annotations?</source>
        <translation>Mentse az annotációkat?</translation>
    </message>
    <message>
        <source>Delete {} shapes? You can restore them with Undo.</source>
        <translation>Törli a {} alakzatot? A Visszavonás paranccsal visszaállíthatja őket.</translation>
    </message>
    <message>
        <source>%s - Open Directory</source>
        <translation>%s - Könyvtár megnyitása</translation>
    </message>
    <message>
        <source>The image is too large to open: {width}x{height} pixels exceeds the {max_side} pixel per-side limit of the raster engine. Raising the decode limit will not help. Split the image into tiles (for example with gdal_retile.py) or open a smaller copy.</source>
        <translation>A kép túl nagy a megnyitáshoz: {width}x{height} pixel meghaladja a raszteres motor oldalankénti {max_side} pixeles korlátját. A dekódolási korlát növelése nem segít. Ossza fel a képet csempékre (például a gdal_retile.py segítségével), vagy nyisson meg egy kisebb másolatot.</translation>
    </message>
    <message>
        <source>The image is too large to open: {width}x{height} pixels needs about {required} MB, but the decode limit is {limit} MB. Split the image into tiles (for example with gdal_retile.py) or open a smaller copy.</source>
        <translation>A kép túl nagy a megnyitáshoz: {width}x{height} pixelhez körülbelül {required} MB szükséges, de a dekódolási korlát {limit} MB. Ossza fel a képet csempékre (például a gdal_retile.py segítségével), vagy nyisson meg egy kisebb másolatot.</translation>
    </message>
    <message>
        <source>Configuration Errors</source>
        <translation>Konfigurációs Hibák</translation>
    </message>
    <message>
        <source>Errors were found while loading the configuration. Please review the errors below and reload your configuration or ignore the erroneous lines.</source>
        <translation>Hibák találhatók a konfiguráció betöltése közben. Kérjük, tekintse át az alábbi hibákat, és töltse újra a konfigurációt, vagy hagyja figyelmen kívül a hibás sorokat.</translation>
    </message>
    <message>
        <source>Reset Layout</source>
        <translation>Elrendezés visszaállítása</translation>
    </message>
    <message>
        <source>Polygon</source>
        <translation>Sokszög</translation>
    </message>
    <message>
        <source>Rectangle</source>
        <translation>Téglalap</translation>
    </message>
    <message>
        <source>Circle</source>
        <translation>Kör</translation>
    </message>
    <message>
        <source>Line</source>
        <translation>Vonal</translation>
    </message>
    <message>
        <source>Point</source>
        <translation>Pont</translation>
    </message>
    <message>
        <source>LineStrip</source>
        <translation>Vonallánc</translation>
    </message>
    <message>
        <source>AI-Points</source>
        <translation>AI-Points</translation>
    </message>
    <message>
        <source>Click points to segment object. Ctrl+LeftClick ends creation.</source>
        <translation>Kattintson pontokra az objektum szegmentálásához. Ctrl+LeftClick befejezi a létrehozást.</translation>
    </message>
    <message>
        <source>AI-Box</source>
        <translation>AI-Box</translation>
    </message>
    <message>
        <source>Draw a bounding box to segment object.</source>
        <translation>Rajzoljon befoglaló keretet az objektum szegmentálásához.</translation>
    </message>
    <message>
        <source>AI-Points Unavailable</source>
        <translation>AI-Points nem elérhető</translation>
    </message>
    <message>
        <source>%s does not support point prompts.
Please select a different model or use AI-Box mode.</source>
        <translation>%s nem támogatja a pont alapú promptokat.
Kérjük, válasszon másik modellt vagy használja az AI-Box módot.</translation>
    </message>
    <message>
        <source>File list is disabled when a label file is opened</source>
        <translation>A fájllista le van tiltva, ha egy címke fájl van megnyitva</translation>
    </message>
    <message>
        <source>Add Point to Edge</source>
        <translation>Pont hozzáadása az élhez</translation>
    </message>
    <message>
        <source>Insert a new point at the hovered polygon edge</source>
        <translation>Új pont beszúrása a kijelölt sokszög élre</translation>
    </message>
    <message>
        <source>&amp;Keep Previous Zoom</source>
        <translation>&amp;Előző nagyítás megtartása</translation>
    </message>
    <message>
        <source>Permanently delete this label file? This action cannot be undone.</source>
        <translation>Véglegesen törli ezt a címke fájlt? Ez a művelet nem vonható vissza.</translation>
    </message>
    <message>
        <source>Allowed formats: {formats}</source>
        <translation>Megengedett formátumok: {formats}</translation>
    </message>
    <message>
        <source>The selected label file could not be opened: {path}</source>
        <translation>A kiválasztott címkefájl nem nyitható meg: {path}</translation>
    </message>
    <message>
        <source>The selected image file could not be opened: {path}</source>
        <translation>A kiválasztott képfájl nem nyitható meg: {path}</translation>
    </message>
    <message>
        <source>Failed to load: {path}</source>
        <translation>A betöltés sikertelen: {path}</translation>
    </message>
    <message>
        <source>Oriented Rectangle</source>
        <translation>Irányított téglalap</translation>
    </message>
    <message>
        <source>Start drawing oriented rectangles</source>
        <translation>Irányított téglalapok rajzolásának megkezdése</translation>
    </message>
    <message>
        <source>AI inference produced no new annotation.</source>
        <translation>Az MI-következtetés nem hozott létre új annotációt.</translation>
    </message>
    <message>
        <source>Shape had no area; nothing created.</source>
        <translation>Az alakzatnak nincs területe; nem jött létre semmi.</translation>
    </message>
    <message>
        <source>Settings…</source>
        <translation>Beállítások…</translation>
    </message>
    <message>
        <source>Edit settings</source>
        <translation>Beállítások szerkesztése</translation>
    </message>
    <message>
        <source>Settings are managed via --config for this session</source>
        <translation>A beállítások ebben a munkamenetben --config segítségével vannak kezelve</translation>
    </message>
    <message>
        <source>Configuration Error</source>
        <translation>Konfigurációs hiba</translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <source>Color theme</source>
        <translation>Színtéma</translation>
    </message>
    <message>
        <source>System</source>
        <translation>Rendszer</translation>
    </message>
    <message>
        <source>Light</source>
        <translation>Világos</translation>
    </message>
    <message>
        <source>Dark</source>
        <translation>Sötét</translation>
    </message>
    <message>
        <source>Show label popup on new shape</source>
        <translation>Címkefelugró ablak megjelenítése új alakzatnál</translation>
    </message>
    <message>
        <source>Show shape labels on canvas</source>
        <translation>Alakzatcímkék megjelenítése a vásznon</translation>
    </message>
    <message>
        <source>Allow points outside the image boundary</source>
        <translation>Pontok engedélyezése a kép határain kívül</translation>
    </message>
    <message>
        <source>Appearance and language</source>
        <translation>Megjelenés és nyelv</translation>
    </message>
    <message>
        <source>Files and saving</source>
        <translation>Fájlok és mentés</translation>
    </message>
    <message>
        <source>Drawing and canvas</source>
        <translation>Rajzolás és vászon</translation>
    </message>
    <message>
        <source>Continue between images</source>
        <translation>Folytatás képek között</translation>
    </message>
    <message>
        <source>Label sources</source>
        <translation>Címkeforrások</translation>
    </message>
    <message>
        <source>Label behavior</source>
        <translation>Címkeviselkedés</translation>
    </message>
    <message>
        <source>AI assist</source>
        <translation>AI-segítség</translation>
    </message>
    <message>
        <source>Save automatically</source>
        <translation>Automatikus mentés</translation>
    </message>
    <message>
        <source>Save image data in label file</source>
        <translation>Képadatok mentése a címkefájlba</translation>
    </message>
    <message>
        <source>Embeds the image in the label JSON file.</source>
        <translation>Beágyazza a képet a címke JSON-fájljába.</translation>
    </message>
    <message>
        <source>Shape Color Mode</source>
        <translation>Alakszín mód</translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation>Automatikus</translation>
    </message>
    <message>
        <source>Uniform</source>
        <translation>Egységes</translation>
    </message>
    <message>
        <source>By Label</source>
        <translation>Címke szerint</translation>
    </message>
    <message>
        <source>Automatic palette shift</source>
        <translation>Automatikus palettaeltolás</translation>
    </message>
    <message>
        <source>Uniform mode color</source>
        <translation>Az Egységes mód színe</translation>
    </message>
    <message>
        <source>By Label fallback color</source>
        <translation>A Címke szerint mód tartalék színe</translation>
    </message>
    <message>
        <source>Individual Label colors remain editable in the Config File.</source>
        <translation>Az egyes címkék színei továbbra is szerkeszthetők a konfigurációs fájlban.</translation>
    </message>
    <message>
        <source>Keep previous annotation</source>
        <translation>Előző annotáció megtartása</translation>
    </message>
    <message>
        <source>Keep previous zoom</source>
        <translation>Előző nagyítás megtartása</translation>
    </message>
    <message>
        <source>Keep previous brightness/contrast</source>
        <translation>Előző fényerő/kontraszt megtartása</translation>
    </message>
    <message>
        <source>Fill polygon while drawing</source>
        <translation>Sokszög kitöltése rajzolás közben</translation>
    </message>
    <message>
        <source>Let shape points extend beyond the image, e.g. for partially visible objects.</source>
        <translation>Lehetővé teszi, hogy az alakzatpontok túlnyúljanak a képen, pl. részben látható objektumokhoz.</translation>
    </message>
    <message>
        <source>Polygon detail</source>
        <translation>Poligon részletessége</translation>
    </message>
    <message>
        <source>Higher values preserve more Mask boundary detail and smaller lands.</source>
        <translation>A magasabb értékek több részletet őriznek meg a maszk határvonalából és a kisebb területekből.</translation>
    </message>
    <message>
        <source>Predefined labels</source>
        <translation>Előre definiált címkék</translation>
    </message>
    <message>
        <source>Label validation</source>
        <translation>Címkeellenőrzés</translation>
    </message>
    <message>
        <source>Sort labels</source>
        <translation>Címkék rendezése</translation>
    </message>
    <message>
        <source>Sort the label list alphabetically instead of keeping the provided order.</source>
        <translation>A címkelistát ábécérendbe rendezi a megadott sorrend megtartása helyett.</translation>
    </message>
    <message>
        <source>Show label text field</source>
        <translation>Címke szövegmezőjének megjelenítése</translation>
    </message>
    <message>
        <source>Label completion</source>
        <translation>Címkekiegészítés</translation>
    </message>
    <message>
        <source>Starts with</source>
        <translation>Ezzel kezdődik</translation>
    </message>
    <message>
        <source>Contains</source>
        <translation>Tartalmazza</translation>
    </message>
    <message>
        <source>Default model</source>
        <translation>Alapértelmezett modell</translation>
    </message>
    <message>
        <source>EfficientSam (speed)</source>
        <translation>EfficientSam (sebesség)</translation>
    </message>
    <message>
        <source>EfficientSam (accuracy)</source>
        <translation>EfficientSam (pontosság)</translation>
    </message>
    <message>
        <source>Sam (speed)</source>
        <translation>Sam (sebesség)</translation>
    </message>
    <message>
        <source>Sam (balanced)</source>
        <translation>Sam (kiegyensúlyozott)</translation>
    </message>
    <message>
        <source>Sam (accuracy)</source>
        <translation>Sam (pontosság)</translation>
    </message>
    <message>
        <source>Sam2 (speed)</source>
        <translation>Sam2 (sebesség)</translation>
    </message>
    <message>
        <source>Sam2 (balanced)</source>
        <translation>Sam2 (kiegyensúlyozott)</translation>
    </message>
    <message>
        <source>Sam2 (accuracy)</source>
        <translation>Sam2 (pontosság)</translation>
    </message>
    <message>
        <source>Sam3</source>
        <translation>Sam3</translation>
    </message>
    <message>
        <source>Suppress existing Shape matches</source>
        <translation>Meglévő alakzatokkal való egyezések elnyomása</translation>
    </message>
    <message>
        <source>When an AI Assist candidate matches an existing Shape, highlight that Shape instead of creating a new Shape.</source>
        <translation>Ha az AI-segítség egyik jelöltje megegyezik egy meglévő alakzattal, a program új alakzat létrehozása helyett kiemeli azt az alakzatot.</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Beállítások</translation>
    </message>
    <message>
        <source>Open config file as text…</source>
        <translation>Konfigurációs fájl megnyitása szövegként…</translation>
    </message>
    <message>
        <source>Edits made in the text file apply after restart</source>
        <translation>A szövegfájlban végzett módosítások újraindítás után lépnek érvénybe</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Bezárás</translation>
    </message>
    <message>
        <source>BETA</source>
        <translation>BETA</translation>
    </message>
    <message>
        <source>(none)</source>
        <translation>(nincs)</translation>
    </message>
    <message>
        <source>one item per line</source>
        <translation>soronként egy elem</translation>
    </message>
    <message>
        <source>Configuration Error</source>
        <translation>Konfigurációs hiba</translation>
    </message>
    <message>
        <source>Predefined labels cannot be empty while Label validation is set to exact. Disable exact validation first.</source>
        <translation>Az előre definiált címkék nem lehetnek üresek, amíg a címkeellenőrzés „exact” értékre van állítva. Először kapcsolja ki az „exact” ellenőrzést.</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Nyelv</translation>
    </message>
    <message>
        <source>Takes effect after restart.</source>
        <translation>Az újraindítás után lép érvénybe.</translation>
    </message>
    <message>
        <source>System default</source>
        <translation>Rendszer alapértelmezése</translation>
    </message>
    <message>
        <source>Predefined image flags</source>
        <translation>Előre definiált képjelzők</translation>
    </message>
</context>
<context>
    <name>_ColorSwatchButton</name>
    <message>
        <source>RGB: {red}, {green}, {blue}</source>
        <translation>RGB: {red}, {green}, {blue}</translation>
    </message>
</context>
<context>
    <name>_SettingsPage</name>
    <message>
        <source>Settings sections</source>
        <translation>Beállítások szakaszai</translation>
    </message>
</context>
</TS>
