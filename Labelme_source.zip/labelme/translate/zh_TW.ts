<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_TW">
<context>
    <name>AiAssistedAnnotationWidget</name>
    <message>
        <source>AI-Assisted Annotation</source>
        <translation>AI輔助標註</translation>
    </message>
    <message>
        <source>AI suggests annotation in &apos;AI-Points&apos; and &apos;AI-Box&apos; modes</source>
        <translation>AI在&apos;AI-Points&apos;和&apos;AI-Box&apos;模式下建議標註</translation>
    </message>
    <message>
        <source>Polygon detail</source>
        <translation>多邊形細節</translation>
    </message>
    <message>
        <source>Adjust polygon detail</source>
        <translation>調整多邊形細節</translation>
    </message>
    <message>
        <source>Smoother</source>
        <translation>更平滑</translation>
    </message>
    <message>
        <source>More detail</source>
        <translation>更多細節</translation>
    </message>
    <message>
        <source>Select &apos;AI-Points&apos; or &apos;AI-Box&apos; mode to enable AI-Assisted Annotation</source>
        <translation>選擇&apos;AI-Points&apos;或&apos;AI-Box&apos;模式以啟用AI輔助標註</translation>
    </message>
</context>
<context>
    <name>AiTextToAnnotationWidget</name>
    <message>
        <source>AI Text-to-Annotation</source>
        <translation>AI提示</translation>
    </message>
    <message>
        <source>e.g., dog,cat,bird</source>
        <translation>例如：狗,貓,鳥</translation>
    </message>
    <message>
        <source>Run</source>
        <translation>執行</translation>
    </message>
    <message>
        <source>Score</source>
        <translation>分數</translation>
    </message>
    <message>
        <source>IoU</source>
        <translation>IoU</translation>
    </message>
    <message>
        <source>AI creates annotations from the text prompt</source>
        <translation>AI根據文字提示創建標註</translation>
    </message>
    <message>
        <source>Select &apos;Polygon&apos;, &apos;Rectangle&apos;, or &apos;AI-Points&apos; mode to enable</source>
        <translation>選擇&apos;Polygon&apos;、&apos;Rectangle&apos;或&apos;AI-Points&apos;模式以啟用</translation>
    </message>
</context>
<context>
    <name>BrightnessContrastDialog</name>
    <message>
        <source>Brightness/Contrast</source>
        <translation>亮度/對比度</translation>
    </message>
    <message>
        <source>Brightness:</source>
        <translation>亮度:</translation>
    </message>
    <message>
        <source>Contrast:</source>
        <translation>對比度:</translation>
    </message>
</context>
<context>
    <name>Canvas</name>
    <message>
        <source>Click &amp; drag to move point</source>
        <translation>點按 &amp; 拖曳以移動點</translation>
    </message>
    <message>
        <source>Click &amp; drag to move shape</source>
        <translation>點擊並拖拽以移動形狀</translation>
    </message>
    <message>
        <source>Creating %r</source>
        <translation>正在創建 %r</translation>
    </message>
    <message>
        <source>ESC to cancel</source>
        <translation>按 ESC 取消</translation>
    </message>
    <message>
        <source>Enter or Space to finalize</source>
        <translation>按 Enter 或空格鍵完成</translation>
    </message>
    <message>
        <source>Editing shapes</source>
        <translation>編輯形狀</translation>
    </message>
    <message>
        <source>Click start point for line</source>
        <translation>點擊線段起點</translation>
    </message>
    <message>
        <source>Click end point for line</source>
        <translation>點擊線段終點</translation>
    </message>
    <message>
        <source>Click start point for linestrip</source>
        <translation>點擊折線起點</translation>
    </message>
    <message>
        <source>Click next point or finish by Ctrl/Cmd+Click for linestrip</source>
        <translation>點擊下一個點或 Ctrl/Cmd+點擊完成折線</translation>
    </message>
    <message>
        <source>Click center point for circle</source>
        <translation>點擊圓形中心點</translation>
    </message>
    <message>
        <source>Click point on circumference for circle</source>
        <translation>點擊圓周上的點</translation>
    </message>
    <message>
        <source>Click first corner for rectangle</source>
        <translation>點擊矩形第一個角</translation>
    </message>
    <message>
        <source>Click to add point</source>
        <translation>點擊以添加點</translation>
    </message>
    <message>
        <source>ALT + SHIFT + Click to delete point</source>
        <translation>ALT + SHIFT + 點擊以刪除點</translation>
    </message>
    <message>
        <source>ALT + Click to create point on shape</source>
        <translation>ALT + 點擊在形狀上創建點</translation>
    </message>
    <message>
        <source>Right-click &amp; drag to copy shape</source>
        <translation>右鍵點擊並拖拽以複製形狀</translation>
    </message>
    <message>
        <source>Click opposite corner for rectangle (Shift for square)</source>
        <translation>點擊矩形對角（Shift繪製正方形）</translation>
    </message>
    <message>
        <source>Click points to include or Shift+Click to exclude. Ctrl+LeftClick ends creation.</source>
        <translation>點擊添加包含點或Shift+Click添加排除點。Ctrl+LeftClick結束創建。</translation>
    </message>
    <message>
        <source>Click first corner of bbox for AI segmentation</source>
        <translation>點擊bbox的第一個角進行AI分割</translation>
    </message>
    <message>
        <source>Click opposite corner to segment object</source>
        <translation>點擊對角以分割物件</translation>
    </message>
    <message>
        <source>Click first corner for oriented rectangle</source>
        <translation>點擊有向矩形的第一個角</translation>
    </message>
    <message>
        <source>Click second corner to set orientation</source>
        <translation>點擊第二個角以設定方向</translation>
    </message>
    <message>
        <source>Click third corner to close oriented rectangle</source>
        <translation>點擊第三個角以閉合有向矩形</translation>
    </message>
    <message>
        <source>Click &amp; drag to rotate the shape</source>
        <translation>點擊並拖拽以旋轉形狀</translation>
    </message>
</context>
<context>
    <name>EmptyStateWidget</name>
    <message>
        <source>Start annotating</source>
        <translation>開始標註</translation>
    </message>
    <message>
        <source>Open an image or a directory of images to begin.</source>
        <translation>開啟影像或影像目錄以開始。</translation>
    </message>
    <message>
        <source>Open Image</source>
        <translation>開啟影像</translation>
    </message>
    <message>
        <source>Open Directory</source>
        <translation>開啟目錄</translation>
    </message>
    <message>
        <source>Or drag and drop image files here</source>
        <translation>或將影像檔案拖放到此處</translation>
    </message>
</context>
<context>
    <name>LabelDialog</name>
    <message>
        <source>Shape Label</source>
        <translation>圖形標籤</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>標籤</translation>
    </message>
    <message>
        <source>Group ID</source>
        <translation>群組 ID</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>描述</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Flags</source>
        <translation>旗標</translation>
    </message>
    <message>
        <source>Shape List</source>
        <translation>形狀清單</translation>
    </message>
    <message>
        <source>Select label to start annotating for it. Press &apos;Esc&apos; to deselect.</source>
        <translation>選取標籤以開始為其加上標註。按「Esc」取消選取。</translation>
    </message>
    <message>
        <source>Label List</source>
        <translation>標籤清單</translation>
    </message>
    <message>
        <source>Search Filename</source>
        <translation>搜尋檔案名稱</translation>
    </message>
    <message>
        <source>File List</source>
        <translation>檔案清單</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation>結束(&amp;Q)</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>結束應用程式</translation>
    </message>
    <message>
        <source>&amp;Open
</source>
        <translation>開啟(&amp;O)
</translation>
    </message>
    <message>
        <source>Open image or label file</source>
        <translation>開啟影像或標籤檔案</translation>
    </message>
    <message>
        <source>Open Dir</source>
        <translation>開啟資料夾</translation>
    </message>
    <message>
        <source>&amp;Next Image</source>
        <translation>下一張影像(&amp;N)</translation>
    </message>
    <message>
        <source>Open next (hold Ctl+Shift to copy labels)</source>
        <translation>開啟下一張影像（按住 Ctl+Shift 複製標籤）</translation>
    </message>
    <message>
        <source>&amp;Prev Image</source>
        <translation>上一張影像(&amp;P)</translation>
    </message>
    <message>
        <source>Open prev (hold Ctl+Shift to copy labels)</source>
        <translation>開啟上一張影像（按住 Ctl+Shift 複製標籤）</translation>
    </message>
    <message>
        <source>&amp;Save
</source>
        <translation>儲存(&amp;S)
</translation>
    </message>
    <message>
        <source>Save labels to file</source>
        <translation>將標籤儲存至檔案</translation>
    </message>
    <message>
        <source>&amp;Save As</source>
        <translation>另存新檔(&amp;S)</translation>
    </message>
    <message>
        <source>&amp;Delete File</source>
        <translation>刪除檔案(&amp;D)</translation>
    </message>
    <message>
        <source>Delete current label file</source>
        <translation>刪除目前的標籤檔案</translation>
    </message>
    <message>
        <source>&amp;Change Output Dir</source>
        <translation>變更輸出資料夾(&amp;C)</translation>
    </message>
    <message>
        <source>Change where annotations are loaded/saved</source>
        <translation>變更標註的載入與儲存位置</translation>
    </message>
    <message>
        <source>Save &amp;Automatically</source>
        <translation>自動儲存(&amp;A)</translation>
    </message>
    <message>
        <source>Save automatically</source>
        <translation>自動儲存</translation>
    </message>
    <message>
        <source>Save With Image Data</source>
        <translation>一併儲存影像資料</translation>
    </message>
    <message>
        <source>Save image data in label file</source>
        <translation>將影像資料儲存在標籤檔案中</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>關閉(&amp;C)</translation>
    </message>
    <message>
        <source>Close current file</source>
        <translation>關閉目前的檔案</translation>
    </message>
    <message>
        <source>Keep Previous Annotation</source>
        <translation>保留上一張標註</translation>
    </message>
    <message>
        <source>Start drawing polygons</source>
        <translation>開始繪製多邊形</translation>
    </message>
    <message>
        <source>Start drawing rectangles</source>
        <translation>開始繪製矩形</translation>
    </message>
    <message>
        <source>Start drawing circles</source>
        <translation>開始繪製圓形</translation>
    </message>
    <message>
        <source>Start drawing lines</source>
        <translation>開始繪製線段</translation>
    </message>
    <message>
        <source>Start drawing points</source>
        <translation>開始繪製點</translation>
    </message>
    <message>
        <source>Edit Shapes</source>
        <translation>編輯形狀</translation>
    </message>
    <message>
        <source>Move and edit the selected shapes</source>
        <translation>移動與編輯選取的形狀</translation>
    </message>
    <message>
        <source>Delete Shapes</source>
        <translation>刪除形狀</translation>
    </message>
    <message>
        <source>Delete the selected shapes</source>
        <translation>刪除選取的形狀</translation>
    </message>
    <message>
        <source>Duplicate Shapes</source>
        <translation>複製形狀</translation>
    </message>
    <message>
        <source>Create a duplicate of the selected shapes</source>
        <translation>建立選取形狀的複本</translation>
    </message>
    <message>
        <source>Undo last point</source>
        <translation>復原上一個點</translation>
    </message>
    <message>
        <source>Undo last drawn point</source>
        <translation>復原上一個繪製的點</translation>
    </message>
    <message>
        <source>Remove Selected Point</source>
        <translation>移除選取的點</translation>
    </message>
    <message>
        <source>Remove selected point from polygon</source>
        <translation>從多邊形中移除選取的點</translation>
    </message>
    <message>
        <source>Undo
</source>
        <translation>復原
</translation>
    </message>
    <message>
        <source>Undo last add and edit of shape</source>
        <translation>復原上一次新增或編輯形狀的操作</translation>
    </message>
    <message>
        <source>&amp;Hide
Shapes</source>
        <translation>隱藏(&amp;H)
形狀</translation>
    </message>
    <message>
        <source>Hide all shapes</source>
        <translation>隱藏所有形狀</translation>
    </message>
    <message>
        <source>&amp;Show
Shapes</source>
        <translation>顯示(&amp;S)
形狀</translation>
    </message>
    <message>
        <source>Show all shapes</source>
        <translation>顯示所有形狀</translation>
    </message>
    <message>
        <source>&amp;Toggle
Shapes</source>
        <translation>切換(&amp;T)
形狀顯示</translation>
    </message>
    <message>
        <source>Toggle all shapes</source>
        <translation>切換所有形狀的顯示狀態</translation>
    </message>
    <message>
        <source>&amp;Tutorial</source>
        <translation>教學(&amp;T)</translation>
    </message>
    <message>
        <source>Show tutorial page</source>
        <translation>顯示教學頁面</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation>縮放</translation>
    </message>
    <message>
        <source>Zoom &amp;In</source>
        <translation>放大(&amp;I)</translation>
    </message>
    <message>
        <source>&amp;Zoom Out</source>
        <translation>縮小(&amp;Z)</translation>
    </message>
    <message>
        <source>&amp;Brightness Contrast</source>
        <translation>亮度與對比(&amp;B)</translation>
    </message>
    <message>
        <source>Adjust brightness and contrast</source>
        <translation>調整亮度與對比</translation>
    </message>
    <message>
        <source>&amp;Edit Label</source>
        <translation>編輯標籤(&amp;E)</translation>
    </message>
    <message>
        <source>Save the labels under a new file name</source>
        <translation>以新的檔案名稱儲存標籤</translation>
    </message>
    <message>
        <source>Modify the label of the selected shape</source>
        <translation>修改選取形狀的標籤</translation>
    </message>
    <message>
        <source>Copy to Clipboard</source>
        <translation>複製到剪貼板</translation>
    </message>
    <message>
        <source>Place the selected shapes on the clipboard</source>
        <translation>將選中圖形放入剪貼板</translation>
    </message>
    <message>
        <source>Paste from Clipboard</source>
        <translation>從剪貼板粘貼</translation>
    </message>
    <message>
        <source>Insert the clipboard shapes into this image</source>
        <translation>將剪貼板中的圖形插入此圖片</translation>
    </message>
    <message>
        <source>Click to place linestrip points; Ctrl+click places the last one.</source>
        <translation>單擊放置折線的點；Ctrl+單擊放置最後一個點。</translation>
    </message>
    <message>
        <source>Fit to &amp;Window</source>
        <translation>適應窗口(&amp;W)</translation>
    </message>
    <message>
        <source>Keep the whole image visible when the window is resized</source>
        <translation>調整視窗大小時保持整張影像可見</translation>
    </message>
    <message>
        <source>Fit to Wi&amp;dth</source>
        <translation>適應寬度(&amp;D)</translation>
    </message>
    <message>
        <source>Match the image width to the window when it is resized</source>
        <translation>調整視窗大小時使影像寬度與視窗一致</translation>
    </message>
    <message>
        <source>Make the image appear larger</source>
        <translation>以較大的尺寸顯示影像</translation>
    </message>
    <message>
        <source>Make the image appear smaller</source>
        <translation>以較小的尺寸顯示影像</translation>
    </message>
    <message>
        <source>&amp;Actual Size</source>
        <translation>實際大小(&amp;A)</translation>
    </message>
    <message>
        <source>Show the image at 100%</source>
        <translation>以 100% 顯示影像</translation>
    </message>
    <message>
        <source>Fill Drawing Polygon</source>
        <translation>填滿正在繪製的多邊形</translation>
    </message>
    <message>
        <source>Fill polygon while drawing</source>
        <translation>繪製時填滿多邊形</translation>
    </message>
    <message>
        <source>Ctrl+Wheel zooms the canvas</source>
        <translation>Ctrl+滾輪縮放畫布</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>檔案(&amp;F)</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>編輯(&amp;E)</translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation>檢視(&amp;V)</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>說明(&amp;H)</translation>
    </message>
    <message>
        <source>%s started.</source>
        <translation>%s 已啟動。</translation>
    </message>
    <message>
        <source>Mask Output Unavailable</source>
        <translation>遮罩輸出無法使用</translation>
    </message>
    <message>
        <source>%s only detects bounding boxes and cannot create &apos;%s&apos; annotations.

Switch the AI Text-to-Annotation model to &apos;SAM3 (smart)&apos;, or set the output format to &apos;Rectangle&apos;.</source>
        <translation>%s 僅偵測邊界框，無法建立 &apos;%s&apos; 標註。

請將 AI Text-to-Annotation 模型切換為 &apos;SAM3 (smart)&apos;，或將輸出格式設定為 &apos;Rectangle&apos;。</translation>
    </message>
    <message>
        <source>Invalid label</source>
        <translation>無效的標籤</translation>
    </message>
    <message>
        <source>Invalid label &apos;{}&apos; with validation type &apos;{}&apos;</source>
        <translation>標籤「{}」不符合「{}」驗證類型</translation>
    </message>
    <message>
        <source>Error saving label data</source>
        <translation>儲存標籤資料時發生錯誤</translation>
    </message>
    <message>
        <source>&lt;b&gt;%s&lt;/b&gt;</source>
        <translation>&lt;b&gt;%s&lt;/b&gt;</translation>
    </message>
    <message>
        <source>AI inference failed: %s</source>
        <translation>AI 推理失敗: %s</translation>
    </message>
    <message>
        <source>Error opening file</source>
        <translation>開啟檔案時發生錯誤</translation>
    </message>
    <message>
        <source>No such file: &lt;b&gt;%s&lt;/b&gt;</source>
        <translation>檔案不存在：&lt;b&gt;%s&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Loading %s...</source>
        <translation>正在載入 %s...</translation>
    </message>
    <message>
        <source>Loaded %s</source>
        <translation>已載入 %s</translation>
    </message>
    <message>
        <source>Image &amp; Label files (%s)</source>
        <translation>影像 &amp; 標籤檔案 (%s)</translation>
    </message>
    <message>
        <source>%s - Choose Image or Label file</source>
        <translation>%s - 選擇影像或標籤檔案</translation>
    </message>
    <message>
        <source>%s - Save/Load Annotations in Directory</source>
        <translation>%s - 在資料夾中儲存或載入標註</translation>
    </message>
    <message>
        <source>%s . Annotations will be saved/loaded in %s</source>
        <translation>%s。標註將在 %s 中儲存或載入</translation>
    </message>
    <message>
        <source>%s - Choose File</source>
        <translation>%s - 選擇檔案</translation>
    </message>
    <message>
        <source>Label files (*%s)</source>
        <translation>標籤檔案 (*%s)</translation>
    </message>
    <message>
        <source>Choose File</source>
        <translation>選擇檔案</translation>
    </message>
    <message>
        <source>Attention</source>
        <translation>注意</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>刪除</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <source>Unavailable in AI-Points mode because this model does not support point prompts.</source>
        <translation>此模型不支援點提示，因此無法在 AI-Points 模式中使用。</translation>
    </message>
    <message>
        <source>Save annotations to &quot;{}&quot; before closing?</source>
        <translation>關閉前將標註儲存至「{}」？</translation>
    </message>
    <message>
        <source>Save annotations?</source>
        <translation>儲存標註？</translation>
    </message>
    <message>
        <source>Delete {} shapes? You can restore them with Undo.</source>
        <translation>刪除 {} 個圖形？可以使用「撤銷」復原。</translation>
    </message>
    <message>
        <source>%s - Open Directory</source>
        <translation>%s - 開啟資料夾</translation>
    </message>
    <message>
        <source>The image is too large to open: {width}x{height} pixels exceeds the {max_side} pixel per-side limit of the raster engine. Raising the decode limit will not help. Split the image into tiles (for example with gdal_retile.py) or open a smaller copy.</source>
        <translation>影像過大,無法開啟: {width}x{height} 像素超出光柵引擎每邊 {max_side} 像素的上限。提高解碼上限也無濟於事。請將影像切分為圖塊(例如使用 gdal_retile.py),或開啟較小的副本。</translation>
    </message>
    <message>
        <source>The image is too large to open: {width}x{height} pixels needs about {required} MB, but the decode limit is {limit} MB. Split the image into tiles (for example with gdal_retile.py) or open a smaller copy.</source>
        <translation>影像過大,無法開啟: {width}x{height} 像素約需 {required} MB,但解碼上限為 {limit} MB。請將影像切分為圖塊(例如使用 gdal_retile.py),或開啟較小的副本。</translation>
    </message>
    <message>
        <source>Toggle &quot;keep previous annotation&quot; mode</source>
        <translation>開關「保留上一個標註」模式</translation>
    </message>
    <message>
        <source>Keep Previous Brightness/Contrast</source>
        <translation>保留之前的亮度/對比度</translation>
    </message>
    <message>
        <source>Configuration Errors</source>
        <translation>設定錯誤</translation>
    </message>
    <message>
        <source>Errors were found while loading the configuration. Please review the errors below and reload your configuration or ignore the erroneous lines.</source>
        <translation>載入設定時發現錯誤。請檢查以下錯誤並重新載入設定，或忽略錯誤的行。</translation>
    </message>
    <message>
        <source>Reset Layout</source>
        <translation>重置佈局</translation>
    </message>
    <message>
        <source>Polygon</source>
        <translation>多邊形</translation>
    </message>
    <message>
        <source>Rectangle</source>
        <translation>矩形</translation>
    </message>
    <message>
        <source>Circle</source>
        <translation>圓形</translation>
    </message>
    <message>
        <source>Line</source>
        <translation>直線</translation>
    </message>
    <message>
        <source>Point</source>
        <translation>控制點</translation>
    </message>
    <message>
        <source>LineStrip</source>
        <translation>折線</translation>
    </message>
    <message>
        <source>AI-Points</source>
        <translation>AI-Points</translation>
    </message>
    <message>
        <source>Click points to segment object. Ctrl+LeftClick ends creation.</source>
        <translation>點擊添加點以分割對象。Ctrl+LeftClick結束創建。</translation>
    </message>
    <message>
        <source>AI-Box</source>
        <translation>AI-Box</translation>
    </message>
    <message>
        <source>Draw a bounding box to segment object.</source>
        <translation>繪製邊界框以分割物件。</translation>
    </message>
    <message>
        <source>AI-Points Unavailable</source>
        <translation>AI-Points 無法使用</translation>
    </message>
    <message>
        <source>%s does not support point prompts.
Please select a different model or use AI-Box mode.</source>
        <translation>%s 不支援點提示。
請選擇其他模型或使用 AI-Box 模式。</translation>
    </message>
    <message>
        <source>File list is disabled when a label file is opened</source>
        <translation>開啟標籤檔案時，檔案列表已停用</translation>
    </message>
    <message>
        <source>Add Point to Edge</source>
        <translation>在邊上新增頂點</translation>
    </message>
    <message>
        <source>Insert a new point at the hovered polygon edge</source>
        <translation>在游標所在的多邊形邊上插入新頂點</translation>
    </message>
    <message>
        <source>&amp;Keep Previous Zoom</source>
        <translation>保留上一個縮放(&amp;K)</translation>
    </message>
    <message>
        <source>Permanently delete this label file? This action cannot be undone.</source>
        <translation>永久刪除此標籤文件？此操作無法復原。</translation>
    </message>
    <message>
        <source>Allowed formats: {formats}</source>
        <translation>支援的格式: {formats}</translation>
    </message>
    <message>
        <source>The selected label file could not be opened: {path}</source>
        <translation>無法開啟所選標籤檔案: {path}</translation>
    </message>
    <message>
        <source>The selected image file could not be opened: {path}</source>
        <translation>無法開啟所選影像檔案: {path}</translation>
    </message>
    <message>
        <source>Failed to load: {path}</source>
        <translation>載入失敗：{path}</translation>
    </message>
    <message>
        <source>Oriented Rectangle</source>
        <translation>有向矩形</translation>
    </message>
    <message>
        <source>Start drawing oriented rectangles</source>
        <translation>開始繪製有向矩形</translation>
    </message>
    <message>
        <source>AI inference produced no new annotation.</source>
        <translation>AI 推理未產生新標註。</translation>
    </message>
    <message>
        <source>Shape had no area; nothing created.</source>
        <translation>形狀面積為零，未建立。</translation>
    </message>
    <message>
        <source>Settings…</source>
        <translation>設定…</translation>
    </message>
    <message>
        <source>Edit settings</source>
        <translation>編輯設定</translation>
    </message>
    <message>
        <source>Settings are managed via --config for this session</source>
        <translation>本次工作階段的設定由 --config 管理</translation>
    </message>
    <message>
        <source>Configuration Error</source>
        <translation>設定錯誤</translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <source>Color theme</source>
        <translation>顏色主題</translation>
    </message>
    <message>
        <source>System</source>
        <translation>跟隨系統</translation>
    </message>
    <message>
        <source>Light</source>
        <translation>淺色</translation>
    </message>
    <message>
        <source>Dark</source>
        <translation>深色</translation>
    </message>
    <message>
        <source>Show label popup on new shape</source>
        <translation>建立新形狀時顯示標籤快顯視窗</translation>
    </message>
    <message>
        <source>Show shape labels on canvas</source>
        <translation>在畫布上顯示形狀標籤</translation>
    </message>
    <message>
        <source>Allow points outside the image boundary</source>
        <translation>允許點超出影像邊界</translation>
    </message>
    <message>
        <source>Appearance and language</source>
        <translation>外觀與語言</translation>
    </message>
    <message>
        <source>Files and saving</source>
        <translation>文件與儲存</translation>
    </message>
    <message>
        <source>Drawing and canvas</source>
        <translation>繪製與畫布</translation>
    </message>
    <message>
        <source>Continue between images</source>
        <translation>在圖像間延續</translation>
    </message>
    <message>
        <source>Label sources</source>
        <translation>標籤來源</translation>
    </message>
    <message>
        <source>Label behavior</source>
        <translation>標籤行為</translation>
    </message>
    <message>
        <source>AI assist</source>
        <translation>AI 輔助</translation>
    </message>
    <message>
        <source>Save automatically</source>
        <translation>自動儲存</translation>
    </message>
    <message>
        <source>Save image data in label file</source>
        <translation>將影像資料儲存在標籤檔案中</translation>
    </message>
    <message>
        <source>Embeds the image in the label JSON file.</source>
        <translation>將圖像嵌入標籤 JSON 文件中。</translation>
    </message>
    <message>
        <source>Shape Color Mode</source>
        <translation>形狀顏色模式</translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation>自動</translation>
    </message>
    <message>
        <source>Uniform</source>
        <translation>統一</translation>
    </message>
    <message>
        <source>By Label</source>
        <translation>依標籤</translation>
    </message>
    <message>
        <source>Automatic palette shift</source>
        <translation>自動調色盤位移</translation>
    </message>
    <message>
        <source>Uniform mode color</source>
        <translation>「統一」模式顏色</translation>
    </message>
    <message>
        <source>By Label fallback color</source>
        <translation>「依標籤」模式備用顏色</translation>
    </message>
    <message>
        <source>Individual Label colors remain editable in the Config File.</source>
        <translation>仍可在設定檔中編輯各個標籤的顏色。</translation>
    </message>
    <message>
        <source>Keep previous annotation</source>
        <translation>保留之前的標註</translation>
    </message>
    <message>
        <source>Keep previous zoom</source>
        <translation>保留之前的縮放</translation>
    </message>
    <message>
        <source>Keep previous brightness/contrast</source>
        <translation>保留之前的亮度/對比度</translation>
    </message>
    <message>
        <source>Fill polygon while drawing</source>
        <translation>繪製時填滿多邊形</translation>
    </message>
    <message>
        <source>Let shape points extend beyond the image, e.g. for partially visible objects.</source>
        <translation>允許形狀的點延伸到影像之外，例如用於部分可見的物件。</translation>
    </message>
    <message>
        <source>Polygon detail</source>
        <translation>多邊形細節</translation>
    </message>
    <message>
        <source>Higher values preserve more Mask boundary detail and smaller lands.</source>
        <translation>值越高，保留的遮罩邊界細節和較小區域越多。</translation>
    </message>
    <message>
        <source>Predefined labels</source>
        <translation>預定義標籤</translation>
    </message>
    <message>
        <source>Label validation</source>
        <translation>標籤驗證</translation>
    </message>
    <message>
        <source>Sort labels</source>
        <translation>標籤排序</translation>
    </message>
    <message>
        <source>Sort the label list alphabetically instead of keeping the provided order.</source>
        <translation>按字母順序排序標籤列表，而非保留提供的順序。</translation>
    </message>
    <message>
        <source>Show label text field</source>
        <translation>顯示標籤文字欄位</translation>
    </message>
    <message>
        <source>Label completion</source>
        <translation>標籤自動完成</translation>
    </message>
    <message>
        <source>Starts with</source>
        <translation>開頭為</translation>
    </message>
    <message>
        <source>Contains</source>
        <translation>包含</translation>
    </message>
    <message>
        <source>Default model</source>
        <translation>預設模型</translation>
    </message>
    <message>
        <source>EfficientSam (speed)</source>
        <translation>EfficientSam (速度)</translation>
    </message>
    <message>
        <source>EfficientSam (accuracy)</source>
        <translation>EfficientSam (準確度)</translation>
    </message>
    <message>
        <source>Sam (speed)</source>
        <translation>Sam (速度)</translation>
    </message>
    <message>
        <source>Sam (balanced)</source>
        <translation>Sam (平衡)</translation>
    </message>
    <message>
        <source>Sam (accuracy)</source>
        <translation>Sam (準確度)</translation>
    </message>
    <message>
        <source>Sam2 (speed)</source>
        <translation>Sam2 (速度)</translation>
    </message>
    <message>
        <source>Sam2 (balanced)</source>
        <translation>Sam2 (平衡)</translation>
    </message>
    <message>
        <source>Sam2 (accuracy)</source>
        <translation>Sam2 (準確度)</translation>
    </message>
    <message>
        <source>Sam3</source>
        <translation>Sam3</translation>
    </message>
    <message>
        <source>Suppress existing Shape matches</source>
        <translation>抑制與現有圖形相符的結果</translation>
    </message>
    <message>
        <source>When an AI Assist candidate matches an existing Shape, highlight that Shape instead of creating a new Shape.</source>
        <translation>當 AI 輔助的候選結果與現有圖形相符時，會醒目提示該圖形，而不是建立新的圖形。</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>設定</translation>
    </message>
    <message>
        <source>Open config file as text…</source>
        <translation>以純文字開啟設定檔…</translation>
    </message>
    <message>
        <source>Edits made in the text file apply after restart</source>
        <translation>文字檔案中的變更將在重新啟動後生效</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>關閉</translation>
    </message>
    <message>
        <source>BETA</source>
        <translation>BETA</translation>
    </message>
    <message>
        <source>(none)</source>
        <translation>（無）</translation>
    </message>
    <message>
        <source>one item per line</source>
        <translation>每行一個項目</translation>
    </message>
    <message>
        <source>Configuration Error</source>
        <translation>設定錯誤</translation>
    </message>
    <message>
        <source>Predefined labels cannot be empty while Label validation is set to exact. Disable exact validation first.</source>
        <translation>當標籤驗證設定為「exact」時，預定義標籤不能為空。請先停用「exact」驗證。</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>語言</translation>
    </message>
    <message>
        <source>Takes effect after restart.</source>
        <translation>重新啟動後生效。</translation>
    </message>
    <message>
        <source>System default</source>
        <translation>系統預設</translation>
    </message>
    <message>
        <source>Predefined image flags</source>
        <translation>預定義影像標記</translation>
    </message>
</context>
<context>
    <name>_ColorSwatchButton</name>
    <message>
        <source>RGB: {red}, {green}, {blue}</source>
        <translation>RGB: {red}, {green}, {blue}</translation>
    </message>
</context>
<context>
    <name>_SettingsPage</name>
    <message>
        <source>Settings sections</source>
        <translation>設定區段</translation>
    </message>
</context>
</TS>
