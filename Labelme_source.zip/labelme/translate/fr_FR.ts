<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fr_FR">
<context>
    <name>AiAssistedAnnotationWidget</name>
    <message>
        <source>AI-Assisted Annotation</source>
        <translation>Annotation assistée par IA</translation>
    </message>
    <message>
        <source>AI suggests annotation in &apos;AI-Points&apos; and &apos;AI-Box&apos; modes</source>
        <translation>L&apos;IA suggère des annotations dans les modes &apos;AI-Points&apos; et &apos;AI-Box&apos;</translation>
    </message>
    <message>
        <source>Polygon detail</source>
        <translation>Détail du polygone</translation>
    </message>
    <message>
        <source>Adjust polygon detail</source>
        <translation>Ajuster le détail du polygone</translation>
    </message>
    <message>
        <source>Smoother</source>
        <translation>Plus lisse</translation>
    </message>
    <message>
        <source>More detail</source>
        <translation>Plus de détails</translation>
    </message>
    <message>
        <source>Select &apos;AI-Points&apos; or &apos;AI-Box&apos; mode to enable AI-Assisted Annotation</source>
        <translation>Sélectionnez le mode &apos;AI-Points&apos; ou &apos;AI-Box&apos; pour activer l&apos;annotation assistée par IA</translation>
    </message>
</context>
<context>
    <name>AiTextToAnnotationWidget</name>
    <message>
        <source>AI Text-to-Annotation</source>
        <translation>Invite IA</translation>
    </message>
    <message>
        <source>e.g., dog,cat,bird</source>
        <translation>ex. : chien,chat,oiseau</translation>
    </message>
    <message>
        <source>Run</source>
        <translation>Exécuter</translation>
    </message>
    <message>
        <source>Score</source>
        <translation>Score</translation>
    </message>
    <message>
        <source>IoU</source>
        <translation>IoU</translation>
    </message>
    <message>
        <source>AI creates annotations from the text prompt</source>
        <translation>L&apos;IA crée des annotations à partir du texte</translation>
    </message>
    <message>
        <source>Select &apos;Polygon&apos;, &apos;Rectangle&apos;, or &apos;AI-Points&apos; mode to enable</source>
        <translation>Sélectionner le mode &apos;Polygon&apos;, &apos;Rectangle&apos; ou &apos;AI-Points&apos; pour activer</translation>
    </message>
</context>
<context>
    <name>BrightnessContrastDialog</name>
    <message>
        <source>Brightness/Contrast</source>
        <translation>Luminosité/Contraste</translation>
    </message>
    <message>
        <source>Brightness:</source>
        <translation>Luminosité :</translation>
    </message>
    <message>
        <source>Contrast:</source>
        <translation>Contraste :</translation>
    </message>
</context>
<context>
    <name>Canvas</name>
    <message>
        <source>Click &amp; drag to move point</source>
        <translation>Cliquer et glisser pour déplacer le point</translation>
    </message>
    <message>
        <source>Click &amp; drag to move shape</source>
        <translation>Cliquer et glisser pour déplacer la forme</translation>
    </message>
    <message>
        <source>Creating %r</source>
        <translation>Création de %r</translation>
    </message>
    <message>
        <source>ESC to cancel</source>
        <translation>ESC pour annuler</translation>
    </message>
    <message>
        <source>Enter or Space to finalize</source>
        <translation>Entrée ou Espace pour finaliser</translation>
    </message>
    <message>
        <source>Editing shapes</source>
        <translation>Modification des formes</translation>
    </message>
    <message>
        <source>Click start point for line</source>
        <translation>Cliquer sur le point de départ de la ligne</translation>
    </message>
    <message>
        <source>Click end point for line</source>
        <translation>Cliquer sur le point d&apos;arrivée de la ligne</translation>
    </message>
    <message>
        <source>Click start point for linestrip</source>
        <translation>Cliquer sur le point de départ de la polyligne</translation>
    </message>
    <message>
        <source>Click next point or finish by Ctrl/Cmd+Click for linestrip</source>
        <translation>Cliquer sur le point suivant ou Ctrl/Cmd+Cliquer pour terminer la polyligne</translation>
    </message>
    <message>
        <source>Click center point for circle</source>
        <translation>Cliquer sur le point central du cercle</translation>
    </message>
    <message>
        <source>Click point on circumference for circle</source>
        <translation>Cliquer sur un point de la circonférence du cercle</translation>
    </message>
    <message>
        <source>Click first corner for rectangle</source>
        <translation>Cliquer sur le premier coin du rectangle</translation>
    </message>
    <message>
        <source>Click to add point</source>
        <translation>Cliquer pour ajouter un point</translation>
    </message>
    <message>
        <source>ALT + SHIFT + Click to delete point</source>
        <translation>ALT + MAJ + Cliquer pour supprimer le point</translation>
    </message>
    <message>
        <source>ALT + Click to create point on shape</source>
        <translation>ALT + Cliquer pour créer un point sur la forme</translation>
    </message>
    <message>
        <source>Right-click &amp; drag to copy shape</source>
        <translation>Clic droit et glisser pour copier la forme</translation>
    </message>
    <message>
        <source>Click opposite corner for rectangle (Shift for square)</source>
        <translation>Cliquer sur le coin opposé du rectangle (Shift pour carré)</translation>
    </message>
    <message>
        <source>Click points to include or Shift+Click to exclude. Ctrl+LeftClick ends creation.</source>
        <translation>Cliquer sur les points à inclure ou Shift+Click pour exclure. Ctrl+LeftClick termine la création.</translation>
    </message>
    <message>
        <source>Click first corner of bbox for AI segmentation</source>
        <translation>Cliquez sur le premier coin de la bbox pour la segmentation IA</translation>
    </message>
    <message>
        <source>Click opposite corner to segment object</source>
        <translation>Cliquez sur le coin opposé pour segmenter l&apos;objet</translation>
    </message>
    <message>
        <source>Click first corner for oriented rectangle</source>
        <translation>Cliquer sur le premier coin du rectangle orienté</translation>
    </message>
    <message>
        <source>Click second corner to set orientation</source>
        <translation>Cliquer sur le deuxième coin pour définir l&apos;orientation</translation>
    </message>
    <message>
        <source>Click third corner to close oriented rectangle</source>
        <translation>Cliquer sur le troisième coin pour fermer le rectangle orienté</translation>
    </message>
    <message>
        <source>Click &amp; drag to rotate the shape</source>
        <translation>Cliquer et glisser pour faire pivoter la forme</translation>
    </message>
</context>
<context>
    <name>EmptyStateWidget</name>
    <message>
        <source>Start annotating</source>
        <translation>Commencer l’annotation</translation>
    </message>
    <message>
        <source>Open an image or a directory of images to begin.</source>
        <translation>Ouvrez une image ou un dossier d’images pour commencer.</translation>
    </message>
    <message>
        <source>Open Image</source>
        <translation>Ouvrir une image</translation>
    </message>
    <message>
        <source>Open Directory</source>
        <translation>Ouvrir un dossier</translation>
    </message>
    <message>
        <source>Or drag and drop image files here</source>
        <translation>Ou glissez-déposez des fichiers image ici</translation>
    </message>
</context>
<context>
    <name>LabelDialog</name>
    <message>
        <source>Shape Label</source>
        <translation>Étiquette de forme</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Étiquette</translation>
    </message>
    <message>
        <source>Group ID</source>
        <translation>Identifiant du groupe</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Description</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Flags</source>
        <translation>Drapeaux</translation>
    </message>
    <message>
        <source>Shape List</source>
        <translation>Liste des formes</translation>
    </message>
    <message>
        <source>Select label to start annotating for it. Press &apos;Esc&apos; to deselect.</source>
        <translation>Sélectionner une étiquette pour commencer l&apos;annotation. Appuyer sur &apos;Esc&apos; pour désélectionner.</translation>
    </message>
    <message>
        <source>Label List</source>
        <translation>Liste des étiquettes</translation>
    </message>
    <message>
        <source>Search Filename</source>
        <translation>Rechercher un nom de fichier</translation>
    </message>
    <message>
        <source>File List</source>
        <translation>Liste des fichiers</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation>&amp;Quitter</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>Quitter l&apos;application</translation>
    </message>
    <message>
        <source>&amp;Open
</source>
        <translation>&amp;Ouvrir
</translation>
    </message>
    <message>
        <source>Open image or label file</source>
        <translation>Ouvrir une image ou un fichier d&apos;étiquettes</translation>
    </message>
    <message>
        <source>Open Dir</source>
        <translation>Ouvrir le répertoire</translation>
    </message>
    <message>
        <source>&amp;Next Image</source>
        <translation>Image &amp;suivante</translation>
    </message>
    <message>
        <source>Open next (hold Ctl+Shift to copy labels)</source>
        <translation>Ouvrir la suivante (maintenir Ctrl+Maj pour copier les étiquettes)</translation>
    </message>
    <message>
        <source>&amp;Prev Image</source>
        <translation>Image &amp;précédente</translation>
    </message>
    <message>
        <source>Open prev (hold Ctl+Shift to copy labels)</source>
        <translation>Ouvrir la précédente (maintenir Ctrl+Maj pour copier les étiquettes)</translation>
    </message>
    <message>
        <source>&amp;Save
</source>
        <translation>&amp;Enregistrer
</translation>
    </message>
    <message>
        <source>Save labels to file</source>
        <translation>Enregistrer les étiquettes dans un fichier</translation>
    </message>
    <message>
        <source>&amp;Save As</source>
        <translation>Enregistrer &amp;sous</translation>
    </message>
    <message>
        <source>&amp;Delete File</source>
        <translation>&amp;Supprimer le fichier</translation>
    </message>
    <message>
        <source>Delete current label file</source>
        <translation>Supprimer le fichier d&apos;étiquettes actuel</translation>
    </message>
    <message>
        <source>&amp;Change Output Dir</source>
        <translation>&amp;Changer le répertoire de sortie</translation>
    </message>
    <message>
        <source>Change where annotations are loaded/saved</source>
        <translation>Changer où les annotations sont chargées/enregistrées</translation>
    </message>
    <message>
        <source>Save &amp;Automatically</source>
        <translation>Enregistrer &amp;automatiquement</translation>
    </message>
    <message>
        <source>Save automatically</source>
        <translation>Enregistrer automatiquement</translation>
    </message>
    <message>
        <source>Save With Image Data</source>
        <translation>Enregistrer avec les données d&apos;image</translation>
    </message>
    <message>
        <source>Save image data in label file</source>
        <translation>Enregistrer les données d&apos;image dans le fichier d&apos;étiquettes</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Fermer</translation>
    </message>
    <message>
        <source>Close current file</source>
        <translation>Fermer le fichier actuel</translation>
    </message>
    <message>
        <source>Keep Previous Annotation</source>
        <translation>Conserver l&apos;annotation précédente</translation>
    </message>
    <message>
        <source>Start drawing polygons</source>
        <translation>Commencer à dessiner des polygones</translation>
    </message>
    <message>
        <source>Start drawing rectangles</source>
        <translation>Commencer à dessiner des rectangles</translation>
    </message>
    <message>
        <source>Start drawing circles</source>
        <translation>Commencer à dessiner des cercles</translation>
    </message>
    <message>
        <source>Start drawing lines</source>
        <translation>Commencer à dessiner des lignes</translation>
    </message>
    <message>
        <source>Start drawing points</source>
        <translation>Commencer à dessiner des points</translation>
    </message>
    <message>
        <source>Edit Shapes</source>
        <translation>Modifier les formes</translation>
    </message>
    <message>
        <source>Move and edit the selected shapes</source>
        <translation>Déplacer et modifier les formes sélectionnées</translation>
    </message>
    <message>
        <source>Delete Shapes</source>
        <translation>Supprimer les formes</translation>
    </message>
    <message>
        <source>Delete the selected shapes</source>
        <translation>Supprimer les formes sélectionnées</translation>
    </message>
    <message>
        <source>Duplicate Shapes</source>
        <translation>Dupliquer les formes</translation>
    </message>
    <message>
        <source>Create a duplicate of the selected shapes</source>
        <translation>Créer un doublon des formes sélectionnées</translation>
    </message>
    <message>
        <source>Undo last point</source>
        <translation>Annuler le dernier point</translation>
    </message>
    <message>
        <source>Undo last drawn point</source>
        <translation>Annuler le dernier point dessiné</translation>
    </message>
    <message>
        <source>Remove Selected Point</source>
        <translation>Supprimer le point sélectionné</translation>
    </message>
    <message>
        <source>Remove selected point from polygon</source>
        <translation>Supprimer le point sélectionné du polygone</translation>
    </message>
    <message>
        <source>Undo
</source>
        <translation>Annuler
</translation>
    </message>
    <message>
        <source>Undo last add and edit of shape</source>
        <translation>Annuler le dernier ajout et la dernière modification de forme</translation>
    </message>
    <message>
        <source>&amp;Hide
Shapes</source>
        <translation>&amp;Masquer
les formes</translation>
    </message>
    <message>
        <source>Hide all shapes</source>
        <translation>Masquer toutes les formes</translation>
    </message>
    <message>
        <source>&amp;Show
Shapes</source>
        <translation>&amp;Afficher
les formes</translation>
    </message>
    <message>
        <source>Show all shapes</source>
        <translation>Afficher toutes les formes</translation>
    </message>
    <message>
        <source>&amp;Toggle
Shapes</source>
        <translation>&amp;Basculer
les formes</translation>
    </message>
    <message>
        <source>Toggle all shapes</source>
        <translation>Basculer toutes les formes</translation>
    </message>
    <message>
        <source>&amp;Tutorial</source>
        <translation>&amp;Tutoriel</translation>
    </message>
    <message>
        <source>Show tutorial page</source>
        <translation>Afficher la page du tutoriel</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation>Zoom</translation>
    </message>
    <message>
        <source>Zoom &amp;In</source>
        <translation>Zoom &amp;avant</translation>
    </message>
    <message>
        <source>&amp;Zoom Out</source>
        <translation>Zoom &amp;arrière</translation>
    </message>
    <message>
        <source>&amp;Brightness Contrast</source>
        <translation>&amp;Luminosité et contraste</translation>
    </message>
    <message>
        <source>Adjust brightness and contrast</source>
        <translation>Ajuster la luminosité et le contraste</translation>
    </message>
    <message>
        <source>&amp;Edit Label</source>
        <translation>&amp;Modifier l&apos;étiquette</translation>
    </message>
    <message>
        <source>Save the labels under a new file name</source>
        <translation>Enregistrer les étiquettes sous un nouveau nom de fichier</translation>
    </message>
    <message>
        <source>Modify the label of the selected shape</source>
        <translation>Modifier l&apos;étiquette de la forme sélectionnée</translation>
    </message>
    <message>
        <source>Copy to Clipboard</source>
        <translation>Copier dans le presse-papiers</translation>
    </message>
    <message>
        <source>Place the selected shapes on the clipboard</source>
        <translation>Placer les formes sélectionnées dans le presse-papiers</translation>
    </message>
    <message>
        <source>Paste from Clipboard</source>
        <translation>Coller depuis le presse-papiers</translation>
    </message>
    <message>
        <source>Insert the clipboard shapes into this image</source>
        <translation>Insérer dans cette image les formes du presse-papiers</translation>
    </message>
    <message>
        <source>Click to place linestrip points; Ctrl+click places the last one.</source>
        <translation>Cliquez pour placer les points de la polyligne ; Ctrl+clic place le dernier.</translation>
    </message>
    <message>
        <source>Fit to &amp;Window</source>
        <translation>&amp;Adapter à la fenêtre</translation>
    </message>
    <message>
        <source>Keep the whole image visible when the window is resized</source>
        <translation>Garder l&apos;image entière visible lorsque la fenêtre est redimensionnée</translation>
    </message>
    <message>
        <source>Fit to Wi&amp;dth</source>
        <translation>Adapter la &amp;largeur</translation>
    </message>
    <message>
        <source>Match the image width to the window when it is resized</source>
        <translation>Aligner la largeur de l&apos;image sur la fenêtre lorsqu&apos;elle est redimensionnée</translation>
    </message>
    <message>
        <source>Make the image appear larger</source>
        <translation>Afficher l&apos;image en plus grand</translation>
    </message>
    <message>
        <source>Make the image appear smaller</source>
        <translation>Afficher l&apos;image en plus petit</translation>
    </message>
    <message>
        <source>&amp;Actual Size</source>
        <translation>&amp;Taille réelle</translation>
    </message>
    <message>
        <source>Show the image at 100%</source>
        <translation>Afficher l&apos;image à 100 %</translation>
    </message>
    <message>
        <source>Fill Drawing Polygon</source>
        <translation>Remplir le polygone en cours de dessin</translation>
    </message>
    <message>
        <source>Fill polygon while drawing</source>
        <translation>Remplir le polygone pendant le dessin</translation>
    </message>
    <message>
        <source>Ctrl+Wheel zooms the canvas</source>
        <translation>Ctrl+Molette zoome le canevas</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Fichier</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Modifier</translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation>&amp;Affichage</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Aide</translation>
    </message>
    <message>
        <source>%s started.</source>
        <translation>%s démarré.</translation>
    </message>
    <message>
        <source>Mask Output Unavailable</source>
        <translation>Sortie de masque indisponible</translation>
    </message>
    <message>
        <source>%s only detects bounding boxes and cannot create &apos;%s&apos; annotations.

Switch the AI Text-to-Annotation model to &apos;SAM3 (smart)&apos;, or set the output format to &apos;Rectangle&apos;.</source>
        <translation>%s ne détecte que les cadres englobants et ne peut pas créer d&apos;annotations &apos;%s&apos;.

Changez le modèle AI Text-to-Annotation pour &apos;SAM3 (smart)&apos;, ou définissez le format de sortie sur &apos;Rectangle&apos;.</translation>
    </message>
    <message>
        <source>Invalid label</source>
        <translation>Étiquette invalide</translation>
    </message>
    <message>
        <source>Invalid label &apos;{}&apos; with validation type &apos;{}&apos;</source>
        <translation>Étiquette invalide &apos;{}&apos; avec le type de validation &apos;{}&apos;</translation>
    </message>
    <message>
        <source>Error saving label data</source>
        <translation>Erreur lors de l&apos;enregistrement des données d&apos;étiquettes</translation>
    </message>
    <message>
        <source>&lt;b&gt;%s&lt;/b&gt;</source>
        <translation>&lt;b&gt;%s&lt;/b&gt;</translation>
    </message>
    <message>
        <source>AI inference failed: %s</source>
        <translation>Échec de l&apos;inférence IA : %s</translation>
    </message>
    <message>
        <source>Error opening file</source>
        <translation>Erreur lors de l&apos;ouverture du fichier</translation>
    </message>
    <message>
        <source>No such file: &lt;b&gt;%s&lt;/b&gt;</source>
        <translation>Fichier introuvable : &lt;b&gt;%s&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Loading %s...</source>
        <translation>Chargement de %s...</translation>
    </message>
    <message>
        <source>Loaded %s</source>
        <translation>%s chargé</translation>
    </message>
    <message>
        <source>Image &amp; Label files (%s)</source>
        <translation>Fichiers Image &amp; Étiquettes (%s)</translation>
    </message>
    <message>
        <source>%s - Choose Image or Label file</source>
        <translation>%s - Choisir un fichier Image ou Étiquette</translation>
    </message>
    <message>
        <source>%s - Save/Load Annotations in Directory</source>
        <translation>%s - Enregistrer/Charger les annotations dans le répertoire</translation>
    </message>
    <message>
        <source>%s . Annotations will be saved/loaded in %s</source>
        <translation>%s . Les annotations seront enregistrées/chargées dans %s</translation>
    </message>
    <message>
        <source>%s - Choose File</source>
        <translation>%s - Choisir un fichier</translation>
    </message>
    <message>
        <source>Label files (*%s)</source>
        <translation>Fichiers d&apos;étiquettes (*%s)</translation>
    </message>
    <message>
        <source>Choose File</source>
        <translation>Choisir un fichier</translation>
    </message>
    <message>
        <source>Attention</source>
        <translation>Attention</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>
    <message>
        <source>Unavailable in AI-Points mode because this model does not support point prompts.</source>
        <translation>Indisponible en mode AI-Points, car ce modèle ne prend pas en charge les prompts de points.</translation>
    </message>
    <message>
        <source>Save annotations to &quot;{}&quot; before closing?</source>
        <translation>Enregistrer les annotations dans &quot;{}&quot; avant de fermer ?</translation>
    </message>
    <message>
        <source>Save annotations?</source>
        <translation>Enregistrer les annotations ?</translation>
    </message>
    <message>
        <source>Delete {} shapes? You can restore them with Undo.</source>
        <translation>Supprimer {} formes ? Vous pouvez les restaurer avec la commande Annuler.</translation>
    </message>
    <message>
        <source>%s - Open Directory</source>
        <translation>%s - Ouvrir le répertoire</translation>
    </message>
    <message>
        <source>The image is too large to open: {width}x{height} pixels exceeds the {max_side} pixel per-side limit of the raster engine. Raising the decode limit will not help. Split the image into tiles (for example with gdal_retile.py) or open a smaller copy.</source>
        <translation>L&apos;image est trop grande pour être ouverte : {width}x{height} pixels dépasse la limite de {max_side} pixels par côté du moteur raster. Augmenter la limite de décodage n&apos;y changera rien. Découpez l&apos;image en tuiles (par exemple avec gdal_retile.py) ou ouvrez une copie plus petite.</translation>
    </message>
    <message>
        <source>The image is too large to open: {width}x{height} pixels needs about {required} MB, but the decode limit is {limit} MB. Split the image into tiles (for example with gdal_retile.py) or open a smaller copy.</source>
        <translation>L&apos;image est trop grande pour être ouverte : {width}x{height} pixels nécessite environ {required} Mo, mais la limite de décodage est de {limit} Mo. Découpez l&apos;image en tuiles (par exemple avec gdal_retile.py) ou ouvrez une copie plus petite.</translation>
    </message>
    <message>
        <source>Toggle &quot;keep previous annotation&quot; mode</source>
        <translation>Activer/désactiver le mode &quot;conserver l&apos;annotation précédente&quot;</translation>
    </message>
    <message>
        <source>Keep Previous Brightness/Contrast</source>
        <translation>Conserver les réglages de luminosité/contraste</translation>
    </message>
    <message>
        <source>Configuration Errors</source>
        <translation>Erreurs de Configuration</translation>
    </message>
    <message>
        <source>Errors were found while loading the configuration. Please review the errors below and reload your configuration or ignore the erroneous lines.</source>
        <translation>Des erreurs ont été trouvées lors du chargement de la configuration. Veuillez examiner les erreurs ci-dessous et recharger votre configuration ou ignorer les lignes erronées.</translation>
    </message>
    <message>
        <source>Reset Layout</source>
        <translation>Réinitialiser la disposition</translation>
    </message>
    <message>
        <source>Polygon</source>
        <translation>Polygone</translation>
    </message>
    <message>
        <source>Rectangle</source>
        <translation>Rectangle</translation>
    </message>
    <message>
        <source>Circle</source>
        <translation>Cercle</translation>
    </message>
    <message>
        <source>Line</source>
        <translation>Ligne</translation>
    </message>
    <message>
        <source>Point</source>
        <translation>Point</translation>
    </message>
    <message>
        <source>LineStrip</source>
        <translation>Polyligne</translation>
    </message>
    <message>
        <source>AI-Points</source>
        <translation>AI-Points</translation>
    </message>
    <message>
        <source>Click points to segment object. Ctrl+LeftClick ends creation.</source>
        <translation>Cliquer sur les points pour segmenter l&apos;objet. Ctrl+LeftClick termine la création.</translation>
    </message>
    <message>
        <source>AI-Box</source>
        <translation>AI-Box</translation>
    </message>
    <message>
        <source>Draw a bounding box to segment object.</source>
        <translation>Dessinez un cadre englobant pour segmenter l&apos;objet.</translation>
    </message>
    <message>
        <source>AI-Points Unavailable</source>
        <translation>AI-Points indisponible</translation>
    </message>
    <message>
        <source>%s does not support point prompts.
Please select a different model or use AI-Box mode.</source>
        <translation>%s ne prend pas en charge les invites par points.
Veuillez sélectionner un autre modèle ou utiliser le mode AI-Box.</translation>
    </message>
    <message>
        <source>File list is disabled when a label file is opened</source>
        <translation>La liste des fichiers est désactivée lorsqu&apos;un fichier d&apos;étiquettes est ouvert</translation>
    </message>
    <message>
        <source>Add Point to Edge</source>
        <translation>Ajouter un point à l&apos;arête</translation>
    </message>
    <message>
        <source>Insert a new point at the hovered polygon edge</source>
        <translation>Insérer un nouveau point sur l&apos;arête du polygone survolée</translation>
    </message>
    <message>
        <source>&amp;Keep Previous Zoom</source>
        <translation>&amp;Conserver le zoom précédent</translation>
    </message>
    <message>
        <source>Permanently delete this label file? This action cannot be undone.</source>
        <translation>Supprimer définitivement ce fichier d&apos;étiquettes ? Cette action est irréversible.</translation>
    </message>
    <message>
        <source>Allowed formats: {formats}</source>
        <translation>Formats autorisés : {formats}</translation>
    </message>
    <message>
        <source>The selected label file could not be opened: {path}</source>
        <translation>Impossible d&apos;ouvrir le fichier d&apos;étiquettes sélectionné : {path}</translation>
    </message>
    <message>
        <source>The selected image file could not be opened: {path}</source>
        <translation>Impossible d&apos;ouvrir le fichier image sélectionné : {path}</translation>
    </message>
    <message>
        <source>Failed to load: {path}</source>
        <translation>Échec du chargement : {path}</translation>
    </message>
    <message>
        <source>Oriented Rectangle</source>
        <translation>Rectangle Orienté</translation>
    </message>
    <message>
        <source>Start drawing oriented rectangles</source>
        <translation>Commencer à dessiner des rectangles orientés</translation>
    </message>
    <message>
        <source>AI inference produced no new annotation.</source>
        <translation>L&apos;inférence IA n&apos;a produit aucune nouvelle annotation.</translation>
    </message>
    <message>
        <source>Shape had no area; nothing created.</source>
        <translation>La forme était vide&#xa0;; rien n&apos;a été créé.</translation>
    </message>
    <message>
        <source>Settings…</source>
        <translation>Réglages…</translation>
    </message>
    <message>
        <source>Edit settings</source>
        <translation>Modifier les réglages</translation>
    </message>
    <message>
        <source>Settings are managed via --config for this session</source>
        <translation>Les réglages sont gérés via --config pour cette session</translation>
    </message>
    <message>
        <source>Configuration Error</source>
        <translation>Erreur de configuration</translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <source>Color theme</source>
        <translation>Thème de couleur</translation>
    </message>
    <message>
        <source>System</source>
        <translation>Système</translation>
    </message>
    <message>
        <source>Light</source>
        <translation>Clair</translation>
    </message>
    <message>
        <source>Dark</source>
        <translation>Sombre</translation>
    </message>
    <message>
        <source>Show label popup on new shape</source>
        <translation>Afficher la fenêtre d&apos;étiquette à la création d&apos;une forme</translation>
    </message>
    <message>
        <source>Show shape labels on canvas</source>
        <translation>Afficher les étiquettes des formes sur le canevas</translation>
    </message>
    <message>
        <source>Allow points outside the image boundary</source>
        <translation>Autoriser les points en dehors des limites de l&apos;image</translation>
    </message>
    <message>
        <source>Appearance and language</source>
        <translation>Apparence et langue</translation>
    </message>
    <message>
        <source>Files and saving</source>
        <translation>Fichiers et enregistrement</translation>
    </message>
    <message>
        <source>Drawing and canvas</source>
        <translation>Dessin et canevas</translation>
    </message>
    <message>
        <source>Continue between images</source>
        <translation>Continuer d’une image à l’autre</translation>
    </message>
    <message>
        <source>Label sources</source>
        <translation>Sources d’étiquettes</translation>
    </message>
    <message>
        <source>Label behavior</source>
        <translation>Comportement des étiquettes</translation>
    </message>
    <message>
        <source>AI assist</source>
        <translation>Assistance par IA</translation>
    </message>
    <message>
        <source>Save automatically</source>
        <translation>Enregistrer automatiquement</translation>
    </message>
    <message>
        <source>Save image data in label file</source>
        <translation>Enregistrer les données d&apos;image dans le fichier d&apos;étiquettes</translation>
    </message>
    <message>
        <source>Embeds the image in the label JSON file.</source>
        <translation>Intègre l’image dans le fichier JSON d’étiquettes.</translation>
    </message>
    <message>
        <source>Shape Color Mode</source>
        <translation>Mode de couleur des formes</translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation>Automatique</translation>
    </message>
    <message>
        <source>Uniform</source>
        <translation>Uniforme</translation>
    </message>
    <message>
        <source>By Label</source>
        <translation>Par étiquette</translation>
    </message>
    <message>
        <source>Automatic palette shift</source>
        <translation>Décalage automatique de la palette</translation>
    </message>
    <message>
        <source>Uniform mode color</source>
        <translation>Couleur du mode Uniforme</translation>
    </message>
    <message>
        <source>By Label fallback color</source>
        <translation>Couleur de secours du mode Par étiquette</translation>
    </message>
    <message>
        <source>Individual Label colors remain editable in the Config File.</source>
        <translation>Les couleurs individuelles des étiquettes restent modifiables dans le fichier de configuration.</translation>
    </message>
    <message>
        <source>Keep previous annotation</source>
        <translation>Conserver l’annotation précédente</translation>
    </message>
    <message>
        <source>Keep previous zoom</source>
        <translation>Conserver le zoom précédent</translation>
    </message>
    <message>
        <source>Keep previous brightness/contrast</source>
        <translation>Conserver la luminosité/le contraste précédents</translation>
    </message>
    <message>
        <source>Fill polygon while drawing</source>
        <translation>Remplir le polygone pendant le dessin</translation>
    </message>
    <message>
        <source>Let shape points extend beyond the image, e.g. for partially visible objects.</source>
        <translation>Permet aux points des formes de dépasser l&apos;image, par exemple pour les objets partiellement visibles.</translation>
    </message>
    <message>
        <source>Polygon detail</source>
        <translation>Détail du polygone</translation>
    </message>
    <message>
        <source>Higher values preserve more Mask boundary detail and smaller lands.</source>
        <translation>Les valeurs élevées préservent davantage de détails du contour du masque et les petites régions.</translation>
    </message>
    <message>
        <source>Predefined labels</source>
        <translation>Étiquettes prédéfinies</translation>
    </message>
    <message>
        <source>Label validation</source>
        <translation>Validation des étiquettes</translation>
    </message>
    <message>
        <source>Sort labels</source>
        <translation>Trier les étiquettes</translation>
    </message>
    <message>
        <source>Sort the label list alphabetically instead of keeping the provided order.</source>
        <translation>Trie la liste des étiquettes par ordre alphabétique au lieu de conserver l’ordre fourni.</translation>
    </message>
    <message>
        <source>Show label text field</source>
        <translation>Afficher le champ de texte de l’étiquette</translation>
    </message>
    <message>
        <source>Label completion</source>
        <translation>Autocomplétion des étiquettes</translation>
    </message>
    <message>
        <source>Starts with</source>
        <translation>Commence par</translation>
    </message>
    <message>
        <source>Contains</source>
        <translation>Contient</translation>
    </message>
    <message>
        <source>Default model</source>
        <translation>Modèle par défaut</translation>
    </message>
    <message>
        <source>EfficientSam (speed)</source>
        <translation>EfficientSam (vitesse)</translation>
    </message>
    <message>
        <source>EfficientSam (accuracy)</source>
        <translation>EfficientSam (précision)</translation>
    </message>
    <message>
        <source>Sam (speed)</source>
        <translation>Sam (vitesse)</translation>
    </message>
    <message>
        <source>Sam (balanced)</source>
        <translation>Sam (équilibré)</translation>
    </message>
    <message>
        <source>Sam (accuracy)</source>
        <translation>Sam (précision)</translation>
    </message>
    <message>
        <source>Sam2 (speed)</source>
        <translation>Sam2 (vitesse)</translation>
    </message>
    <message>
        <source>Sam2 (balanced)</source>
        <translation>Sam2 (équilibré)</translation>
    </message>
    <message>
        <source>Sam2 (accuracy)</source>
        <translation>Sam2 (précision)</translation>
    </message>
    <message>
        <source>Sam3</source>
        <translation>Sam3</translation>
    </message>
    <message>
        <source>Suppress existing Shape matches</source>
        <translation>Ignorer les correspondances avec les formes existantes</translation>
    </message>
    <message>
        <source>When an AI Assist candidate matches an existing Shape, highlight that Shape instead of creating a new Shape.</source>
        <translation>Lorsqu&apos;un candidat de l&apos;Assistance par IA correspond à une forme existante, cette forme est mise en évidence au lieu de créer une nouvelle forme.</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Réglages</translation>
    </message>
    <message>
        <source>Open config file as text…</source>
        <translation>Ouvrir le fichier de configuration en texte…</translation>
    </message>
    <message>
        <source>Edits made in the text file apply after restart</source>
        <translation>Les modifications dans le fichier texte s&apos;appliquent après redémarrage</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Fermer</translation>
    </message>
    <message>
        <source>BETA</source>
        <translation>BETA</translation>
    </message>
    <message>
        <source>(none)</source>
        <translation>(aucun)</translation>
    </message>
    <message>
        <source>one item per line</source>
        <translation>un élément par ligne</translation>
    </message>
    <message>
        <source>Configuration Error</source>
        <translation>Erreur de configuration</translation>
    </message>
    <message>
        <source>Predefined labels cannot be empty while Label validation is set to exact. Disable exact validation first.</source>
        <translation>Les étiquettes prédéfinies ne peuvent pas être vides lorsque la validation des étiquettes est définie sur « exact ». Désactivez d’abord la validation « exact ».</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Langue</translation>
    </message>
    <message>
        <source>Takes effect after restart.</source>
        <translation>Prend effet après le redémarrage.</translation>
    </message>
    <message>
        <source>System default</source>
        <translation>Langue du système</translation>
    </message>
    <message>
        <source>Predefined image flags</source>
        <translation>Indicateurs d&apos;image prédéfinis</translation>
    </message>
</context>
<context>
    <name>_ColorSwatchButton</name>
    <message>
        <source>RGB: {red}, {green}, {blue}</source>
        <translation>RVB: {red}, {green}, {blue}</translation>
    </message>
</context>
<context>
    <name>_SettingsPage</name>
    <message>
        <source>Settings sections</source>
        <translation>Sections des réglages</translation>
    </message>
</context>
</TS>
