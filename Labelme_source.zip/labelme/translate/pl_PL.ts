<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="pl_PL">
<context>
    <name>AiAssistedAnnotationWidget</name>
    <message>
        <source>AI-Assisted Annotation</source>
        <translation>Adnotacja wspomagana przez AI</translation>
    </message>
    <message>
        <source>AI suggests annotation in &apos;AI-Points&apos; and &apos;AI-Box&apos; modes</source>
        <translation>AI sugeruje adnotacje w trybach &apos;AI-Points&apos; i &apos;AI-Box&apos;</translation>
    </message>
    <message>
        <source>Polygon detail</source>
        <translation>Szczegółowość wielokąta</translation>
    </message>
    <message>
        <source>Adjust polygon detail</source>
        <translation>Dostosuj szczegółowość wielokąta</translation>
    </message>
    <message>
        <source>Smoother</source>
        <translation>Gładszy</translation>
    </message>
    <message>
        <source>More detail</source>
        <translation>Więcej szczegółów</translation>
    </message>
    <message>
        <source>Select &apos;AI-Points&apos; or &apos;AI-Box&apos; mode to enable AI-Assisted Annotation</source>
        <translation>Wybierz tryb &apos;AI-Points&apos; lub &apos;AI-Box&apos;, aby włączyć adnotację wspomaganą przez AI</translation>
    </message>
</context>
<context>
    <name>AiTextToAnnotationWidget</name>
    <message>
        <source>AI Text-to-Annotation</source>
        <translation>AI — tekst na adnotację</translation>
    </message>
    <message>
        <source>e.g., dog,cat,bird</source>
        <translation>np. pies,kot,ptak</translation>
    </message>
    <message>
        <source>Run</source>
        <translation>Uruchom</translation>
    </message>
    <message>
        <source>Score</source>
        <translation>Wynik</translation>
    </message>
    <message>
        <source>IoU</source>
        <translation>IoU</translation>
    </message>
    <message>
        <source>AI creates annotations from the text prompt</source>
        <translation>AI tworzy adnotacje na podstawie podanego tekstu</translation>
    </message>
    <message>
        <source>Select &apos;Polygon&apos;, &apos;Rectangle&apos;, or &apos;AI-Points&apos; mode to enable</source>
        <translation>Wybierz tryb &apos;Polygon&apos;, &apos;Rectangle&apos; lub &apos;AI-Points&apos;, aby włączyć</translation>
    </message>
</context>
<context>
    <name>BrightnessContrastDialog</name>
    <message>
        <source>Brightness/Contrast</source>
        <translation>Jasność/Kontrast</translation>
    </message>
    <message>
        <source>Brightness:</source>
        <translation>Jasność:</translation>
    </message>
    <message>
        <source>Contrast:</source>
        <translation>Kontrast:</translation>
    </message>
</context>
<context>
    <name>Canvas</name>
    <message>
        <source>Click &amp; drag to move point</source>
        <translation>Kliknij i przeciągnij, aby przesunąć punkt</translation>
    </message>
    <message>
        <source>Click &amp; drag to move shape</source>
        <translation>Kliknij i przeciągnij, aby przesunąć kształt</translation>
    </message>
    <message>
        <source>Creating %r</source>
        <translation>Tworzenie %r</translation>
    </message>
    <message>
        <source>ESC to cancel</source>
        <translation>ESC — anuluj</translation>
    </message>
    <message>
        <source>Enter or Space to finalize</source>
        <translation>Enter lub Spacja — zatwierdź</translation>
    </message>
    <message>
        <source>Editing shapes</source>
        <translation>Edycja kształtów</translation>
    </message>
    <message>
        <source>Click start point for line</source>
        <translation>Kliknij punkt początkowy linii</translation>
    </message>
    <message>
        <source>Click end point for line</source>
        <translation>Kliknij punkt końcowy linii</translation>
    </message>
    <message>
        <source>Click start point for linestrip</source>
        <translation>Kliknij punkt początkowy polilinii</translation>
    </message>
    <message>
        <source>Click next point or finish by Ctrl/Cmd+Click for linestrip</source>
        <translation>Kliknij następny punkt lub Ctrl/Cmd+Klik, aby zakończyć polilinię</translation>
    </message>
    <message>
        <source>Click center point for circle</source>
        <translation>Kliknij środek okręgu</translation>
    </message>
    <message>
        <source>Click point on circumference for circle</source>
        <translation>Kliknij punkt na obwodzie okręgu</translation>
    </message>
    <message>
        <source>Click first corner for rectangle</source>
        <translation>Kliknij pierwszy róg prostokąta</translation>
    </message>
    <message>
        <source>Click to add point</source>
        <translation>Kliknij, aby dodać punkt</translation>
    </message>
    <message>
        <source>ALT + SHIFT + Click to delete point</source>
        <translation>ALT + SHIFT + Klik — usuń punkt</translation>
    </message>
    <message>
        <source>ALT + Click to create point on shape</source>
        <translation>ALT + Klik — utwórz punkt na kształcie</translation>
    </message>
    <message>
        <source>Right-click &amp; drag to copy shape</source>
        <translation>Prawy przycisk i przeciągnij — skopiuj kształt</translation>
    </message>
    <message>
        <source>Click opposite corner for rectangle (Shift for square)</source>
        <translation>Kliknij przeciwległy róg prostokąta (Shift — kwadrat)</translation>
    </message>
    <message>
        <source>Click points to include or Shift+Click to exclude. Ctrl+LeftClick ends creation.</source>
        <translation>Kliknij punkty, aby dodać, lub Shift+Click, aby wykluczyć. Ctrl+LeftClick kończy tworzenie.</translation>
    </message>
    <message>
        <source>Click first corner of bbox for AI segmentation</source>
        <translation>Kliknij pierwszy róg bbox dla segmentacji AI</translation>
    </message>
    <message>
        <source>Click opposite corner to segment object</source>
        <translation>Kliknij przeciwległy róg, aby segmentować obiekt</translation>
    </message>
    <message>
        <source>Click first corner for oriented rectangle</source>
        <translation>Kliknij pierwszy róg prostokąta zorientowanego</translation>
    </message>
    <message>
        <source>Click second corner to set orientation</source>
        <translation>Kliknij drugi róg, aby ustawić orientację</translation>
    </message>
    <message>
        <source>Click third corner to close oriented rectangle</source>
        <translation>Kliknij trzeci róg, aby zamknąć prostokąt zorientowany</translation>
    </message>
    <message>
        <source>Click &amp; drag to rotate the shape</source>
        <translation>Kliknij i przeciągnij — obróć kształt</translation>
    </message>
</context>
<context>
    <name>EmptyStateWidget</name>
    <message>
        <source>Start annotating</source>
        <translation>Rozpocznij adnotowanie</translation>
    </message>
    <message>
        <source>Open an image or a directory of images to begin.</source>
        <translation>Aby rozpocząć, otwórz obraz lub folder z obrazami.</translation>
    </message>
    <message>
        <source>Open Image</source>
        <translation>Otwórz obraz</translation>
    </message>
    <message>
        <source>Open Directory</source>
        <translation>Otwórz folder</translation>
    </message>
    <message>
        <source>Or drag and drop image files here</source>
        <translation>Lub przeciągnij i upuść pliki obrazów tutaj</translation>
    </message>
</context>
<context>
    <name>LabelDialog</name>
    <message>
        <source>Shape Label</source>
        <translation>Etykieta kształtu</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Etykieta</translation>
    </message>
    <message>
        <source>Group ID</source>
        <translation>Identyfikator grupy</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Opis</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Flags</source>
        <translation>Flagi</translation>
    </message>
    <message>
        <source>Shape List</source>
        <translation>Lista kształtów</translation>
    </message>
    <message>
        <source>Select label to start annotating for it. Press &apos;Esc&apos; to deselect.</source>
        <translation>Wybierz etykietę, aby zacząć adnotację. Naciśnij &apos;Esc&apos;, aby odznaczyć.</translation>
    </message>
    <message>
        <source>Label List</source>
        <translation>Lista etykiet</translation>
    </message>
    <message>
        <source>Search Filename</source>
        <translation>Szukaj nazwy pliku</translation>
    </message>
    <message>
        <source>File List</source>
        <translation>Lista plików</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation>&amp;Zakończ</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>Zamknij aplikację</translation>
    </message>
    <message>
        <source>&amp;Open
</source>
        <translation>&amp;Otwórz</translation>
    </message>
    <message>
        <source>Open image or label file</source>
        <translation>Otwórz obraz lub plik etykiet</translation>
    </message>
    <message>
        <source>Open Dir</source>
        <translation>Otwórz folder</translation>
    </message>
    <message>
        <source>&amp;Next Image</source>
        <translation>&amp;Następny obraz</translation>
    </message>
    <message>
        <source>Open next (hold Ctl+Shift to copy labels)</source>
        <translation>Otwórz następny (Ctrl+Shift — kopiuj etykiety)</translation>
    </message>
    <message>
        <source>&amp;Prev Image</source>
        <translation>&amp;Poprzedni obraz</translation>
    </message>
    <message>
        <source>Open prev (hold Ctl+Shift to copy labels)</source>
        <translation>Otwórz poprzedni (Ctrl+Shift — kopiuj etykiety)</translation>
    </message>
    <message>
        <source>&amp;Save
</source>
        <translation>&amp;Zapisz</translation>
    </message>
    <message>
        <source>Save labels to file</source>
        <translation>Zapisz etykiety do pliku</translation>
    </message>
    <message>
        <source>&amp;Save As</source>
        <translation>Zapisz &amp;jako</translation>
    </message>
    <message>
        <source>&amp;Delete File</source>
        <translation>&amp;Usuń plik</translation>
    </message>
    <message>
        <source>Delete current label file</source>
        <translation>Usuń bieżący plik etykiet</translation>
    </message>
    <message>
        <source>&amp;Change Output Dir</source>
        <translation>&amp;Zmień folder wynikowy</translation>
    </message>
    <message>
        <source>Change where annotations are loaded/saved</source>
        <translation>Zmień miejsce wczytywania/zapisywania adnotacji</translation>
    </message>
    <message>
        <source>Save &amp;Automatically</source>
        <translation>Zapisuj &amp;automatycznie</translation>
    </message>
    <message>
        <source>Save automatically</source>
        <translation>Zapisuj automatycznie</translation>
    </message>
    <message>
        <source>Save With Image Data</source>
        <translation>Zapisz z danymi obrazu</translation>
    </message>
    <message>
        <source>Save image data in label file</source>
        <translation>Zapisz dane obrazu w pliku etykiet</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Zamknij</translation>
    </message>
    <message>
        <source>Close current file</source>
        <translation>Zamknij bieżący plik</translation>
    </message>
    <message>
        <source>Keep Previous Annotation</source>
        <translation>Zachowaj poprzednią adnotację</translation>
    </message>
    <message>
        <source>Start drawing polygons</source>
        <translation>Rozpocznij rysowanie wielokątów</translation>
    </message>
    <message>
        <source>Start drawing rectangles</source>
        <translation>Rozpocznij rysowanie prostokątów</translation>
    </message>
    <message>
        <source>Start drawing circles</source>
        <translation>Rozpocznij rysowanie okręgów</translation>
    </message>
    <message>
        <source>Start drawing lines</source>
        <translation>Rozpocznij rysowanie linii</translation>
    </message>
    <message>
        <source>Start drawing points</source>
        <translation>Rozpocznij rysowanie punktów</translation>
    </message>
    <message>
        <source>Edit Shapes</source>
        <translation>Edytuj kształty</translation>
    </message>
    <message>
        <source>Move and edit the selected shapes</source>
        <translation>Przesuń i edytuj zaznaczone kształty</translation>
    </message>
    <message>
        <source>Delete Shapes</source>
        <translation>Usuń kształty</translation>
    </message>
    <message>
        <source>Delete the selected shapes</source>
        <translation>Usuń zaznaczone kształty</translation>
    </message>
    <message>
        <source>Duplicate Shapes</source>
        <translation>Duplikuj kształty</translation>
    </message>
    <message>
        <source>Create a duplicate of the selected shapes</source>
        <translation>Utwórz duplikat zaznaczonych kształtów</translation>
    </message>
    <message>
        <source>Undo last point</source>
        <translation>Cofnij ostatni punkt</translation>
    </message>
    <message>
        <source>Undo last drawn point</source>
        <translation>Cofnij ostatnio narysowany punkt</translation>
    </message>
    <message>
        <source>Remove Selected Point</source>
        <translation>Usuń zaznaczony punkt</translation>
    </message>
    <message>
        <source>Remove selected point from polygon</source>
        <translation>Usuń zaznaczony punkt z wielokąta</translation>
    </message>
    <message>
        <source>Undo
</source>
        <translation>Cofnij</translation>
    </message>
    <message>
        <source>Undo last add and edit of shape</source>
        <translation>Cofnij ostatnie dodanie i edycję kształtu</translation>
    </message>
    <message>
        <source>&amp;Hide
Shapes</source>
        <translation>&amp;Ukryj kształty</translation>
    </message>
    <message>
        <source>Hide all shapes</source>
        <translation>Ukryj wszystkie kształty</translation>
    </message>
    <message>
        <source>&amp;Show
Shapes</source>
        <translation>&amp;Pokaż kształty</translation>
    </message>
    <message>
        <source>Show all shapes</source>
        <translation>Pokaż wszystkie kształty</translation>
    </message>
    <message>
        <source>&amp;Toggle
Shapes</source>
        <translation>Przełącz &amp;kształty</translation>
    </message>
    <message>
        <source>Toggle all shapes</source>
        <translation>Przełącz widoczność wszystkich kształtów</translation>
    </message>
    <message>
        <source>&amp;Tutorial</source>
        <translation>&amp;Samouczek</translation>
    </message>
    <message>
        <source>Show tutorial page</source>
        <translation>Pokaż stronę samouczka</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation>Powiększenie</translation>
    </message>
    <message>
        <source>Zoom &amp;In</source>
        <translation>Powiększ (&amp;I)</translation>
    </message>
    <message>
        <source>&amp;Zoom Out</source>
        <translation>Pomniejsz (&amp;Z)</translation>
    </message>
    <message>
        <source>&amp;Brightness Contrast</source>
        <translation>Jasność i kontrast (&amp;B)</translation>
    </message>
    <message>
        <source>Adjust brightness and contrast</source>
        <translation>Dostosuj jasność i kontrast</translation>
    </message>
    <message>
        <source>&amp;Edit Label</source>
        <translation>&amp;Edytuj etykietę</translation>
    </message>
    <message>
        <source>Save the labels under a new file name</source>
        <translation>Zapisz etykiety pod nową nazwą pliku</translation>
    </message>
    <message>
        <source>Modify the label of the selected shape</source>
        <translation>Zmień etykietę zaznaczonego kształtu</translation>
    </message>
    <message>
        <source>Copy to Clipboard</source>
        <translation>Kopiuj do schowka</translation>
    </message>
    <message>
        <source>Place the selected shapes on the clipboard</source>
        <translation>Umieść zaznaczone kształty w schowku</translation>
    </message>
    <message>
        <source>Paste from Clipboard</source>
        <translation>Wklej ze schowka</translation>
    </message>
    <message>
        <source>Insert the clipboard shapes into this image</source>
        <translation>Wstaw kształty ze schowka do tego obrazu</translation>
    </message>
    <message>
        <source>Click to place linestrip points; Ctrl+click places the last one.</source>
        <translation>Kliknij, aby umieścić punkty polilinii; Ctrl+kliknięcie umieszcza ostatni.</translation>
    </message>
    <message>
        <source>Fit to &amp;Window</source>
        <translation>Dopasuj do okna (&amp;W)</translation>
    </message>
    <message>
        <source>Keep the whole image visible when the window is resized</source>
        <translation>Cały obraz pozostaje widoczny przy zmianie rozmiaru okna</translation>
    </message>
    <message>
        <source>Fit to Wi&amp;dth</source>
        <translation>Dopasuj szerokość (&amp;D)</translation>
    </message>
    <message>
        <source>Match the image width to the window when it is resized</source>
        <translation>Szerokość obrazu dopasowuje się do okna przy zmianie jego rozmiaru</translation>
    </message>
    <message>
        <source>Make the image appear larger</source>
        <translation>Wyświetl obraz w większym rozmiarze</translation>
    </message>
    <message>
        <source>Make the image appear smaller</source>
        <translation>Wyświetl obraz w mniejszym rozmiarze</translation>
    </message>
    <message>
        <source>&amp;Actual Size</source>
        <translation>&amp;Rzeczywisty rozmiar</translation>
    </message>
    <message>
        <source>Show the image at 100%</source>
        <translation>Wyświetl obraz w skali 100%</translation>
    </message>
    <message>
        <source>Fill Drawing Polygon</source>
        <translation>Wypełnij rysowany wielokąt</translation>
    </message>
    <message>
        <source>Fill polygon while drawing</source>
        <translation>Wypełniaj wielokąt podczas rysowania</translation>
    </message>
    <message>
        <source>Ctrl+Wheel zooms the canvas</source>
        <translation>Ctrl+kółko powiększa płótno</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Plik</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Edycja</translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation>&amp;Widok</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Pomoc</translation>
    </message>
    <message>
        <source>%s started.</source>
        <translation>%s uruchomiono.</translation>
    </message>
    <message>
        <source>Mask Output Unavailable</source>
        <translation>Wyjście maski niedostępne</translation>
    </message>
    <message>
        <source>%s only detects bounding boxes and cannot create &apos;%s&apos; annotations.

Switch the AI Text-to-Annotation model to &apos;SAM3 (smart)&apos;, or set the output format to &apos;Rectangle&apos;.</source>
        <translation>%s wykrywa tylko ramki ograniczające i nie może utworzyć adnotacji &apos;%s&apos;.

Zmień model AI Text-to-Annotation na &apos;SAM3 (smart)&apos; lub ustaw format wyjściowy na &apos;Rectangle&apos;.</translation>
    </message>
    <message>
        <source>Invalid label</source>
        <translation>Nieprawidłowa etykieta</translation>
    </message>
    <message>
        <source>Invalid label &apos;{}&apos; with validation type &apos;{}&apos;</source>
        <translation>Nieprawidłowa etykieta &apos;{}&apos; dla typu walidacji &apos;{}&apos;</translation>
    </message>
    <message>
        <source>Error saving label data</source>
        <translation>Błąd zapisu etykiet</translation>
    </message>
    <message>
        <source>&lt;b&gt;%s&lt;/b&gt;</source>
        <translation>&lt;b&gt;%s&lt;/b&gt;</translation>
    </message>
    <message>
        <source>AI inference failed: %s</source>
        <translation>Wnioskowanie AI nie powiodło się: %s</translation>
    </message>
    <message>
        <source>Error opening file</source>
        <translation>Błąd otwarcia pliku</translation>
    </message>
    <message>
        <source>No such file: &lt;b&gt;%s&lt;/b&gt;</source>
        <translation>Brak pliku: &lt;b&gt;%s&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Loading %s...</source>
        <translation>Wczytywanie %s...</translation>
    </message>
    <message>
        <source>Loaded %s</source>
        <translation>Wczytano %s</translation>
    </message>
    <message>
        <source>Image &amp; Label files (%s)</source>
        <translation>Pliki obrazów i etykiet (%s)</translation>
    </message>
    <message>
        <source>%s - Choose Image or Label file</source>
        <translation>%s — Wybierz plik obrazu lub etykiet</translation>
    </message>
    <message>
        <source>%s - Save/Load Annotations in Directory</source>
        <translation>%s — Zapisz/wczytaj adnotacje w folderze</translation>
    </message>
    <message>
        <source>%s . Annotations will be saved/loaded in %s</source>
        <translation>%s. Adnotacje będą zapisywane/wczytywane w %s</translation>
    </message>
    <message>
        <source>%s - Choose File</source>
        <translation>%s — Wybierz plik</translation>
    </message>
    <message>
        <source>Label files (*%s)</source>
        <translation>Pliki etykiet (*%s)</translation>
    </message>
    <message>
        <source>Choose File</source>
        <translation>Wybierz plik</translation>
    </message>
    <message>
        <source>Attention</source>
        <translation>Uwaga</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Anuluj</translation>
    </message>
    <message>
        <source>Unavailable in AI-Points mode because this model does not support point prompts.</source>
        <translation>Niedostępne w trybie AI-Points, ponieważ ten model nie obsługuje poleceń punktowych.</translation>
    </message>
    <message>
        <source>Save annotations to &quot;{}&quot; before closing?</source>
        <translation>Zapisać adnotacje do &quot;{}&quot; przed zamknięciem?</translation>
    </message>
    <message>
        <source>Save annotations?</source>
        <translation>Zapisać adnotacje?</translation>
    </message>
    <message>
        <source>Delete {} shapes? You can restore them with Undo.</source>
        <translation>Usunąć {} kształtów? Możesz je przywrócić poleceniem Cofnij.</translation>
    </message>
    <message>
        <source>%s - Open Directory</source>
        <translation>%s — Otwórz folder</translation>
    </message>
    <message>
        <source>The image is too large to open: {width}x{height} pixels exceeds the {max_side} pixel per-side limit of the raster engine. Raising the decode limit will not help. Split the image into tiles (for example with gdal_retile.py) or open a smaller copy.</source>
        <translation>Obraz jest zbyt duży, aby go otworzyć: {width}x{height} pikseli przekracza limit {max_side} pikseli na bok silnika rastrowego. Zwiększenie limitu dekodowania nie pomoże. Podziel obraz na kafelki (na przykład za pomocą gdal_retile.py) lub otwórz mniejszą kopię.</translation>
    </message>
    <message>
        <source>The image is too large to open: {width}x{height} pixels needs about {required} MB, but the decode limit is {limit} MB. Split the image into tiles (for example with gdal_retile.py) or open a smaller copy.</source>
        <translation>Obraz jest zbyt duży, aby go otworzyć: {width}x{height} pikseli wymaga około {required} MB, ale limit dekodowania wynosi {limit} MB. Podziel obraz na kafelki (na przykład za pomocą gdal_retile.py) lub otwórz mniejszą kopię.</translation>
    </message>
    <message>
        <source>Toggle &quot;keep previous annotation&quot; mode</source>
        <translation>Przełącz tryb „zachowaj poprzednią adnotację”</translation>
    </message>
    <message>
        <source>Keep Previous Brightness/Contrast</source>
        <translation>Zachowaj poprzednią jasność/kontrast</translation>
    </message>
    <message>
        <source>Configuration Errors</source>
        <translation>Błędy konfiguracji</translation>
    </message>
    <message>
        <source>Errors were found while loading the configuration. Please review the errors below and reload your configuration or ignore the erroneous lines.</source>
        <translation>Wystąpiły błędy podczas wczytywania konfiguracji. Sprawdź listę poniżej i przeładuj konfigurację lub zignoruj błędne wiersze.</translation>
    </message>
    <message>
        <source>Reset Layout</source>
        <translation>Zresetuj układ</translation>
    </message>
    <message>
        <source>Polygon</source>
        <translation>Wielokąt</translation>
    </message>
    <message>
        <source>Rectangle</source>
        <translation>Prostokąt</translation>
    </message>
    <message>
        <source>Circle</source>
        <translation>Okrąg</translation>
    </message>
    <message>
        <source>Line</source>
        <translation>Linia</translation>
    </message>
    <message>
        <source>Point</source>
        <translation>Punkt</translation>
    </message>
    <message>
        <source>LineStrip</source>
        <translation>Łamana</translation>
    </message>
    <message>
        <source>AI-Points</source>
        <translation>AI-Points</translation>
    </message>
    <message>
        <source>Click points to segment object. Ctrl+LeftClick ends creation.</source>
        <translation>Kliknij punkty, aby segmentować obiekt. Ctrl+LeftClick kończy tworzenie.</translation>
    </message>
    <message>
        <source>AI-Box</source>
        <translation>AI-Box</translation>
    </message>
    <message>
        <source>Draw a bounding box to segment object.</source>
        <translation>Narysuj ramkę ograniczającą, aby segmentować obiekt.</translation>
    </message>
    <message>
        <source>AI-Points Unavailable</source>
        <translation>AI-Points niedostępne</translation>
    </message>
    <message>
        <source>%s does not support point prompts.
Please select a different model or use AI-Box mode.</source>
        <translation>%s nie obsługuje poleceń punktowych.
Wybierz inny model lub użyj trybu AI-Box.</translation>
    </message>
    <message>
        <source>File list is disabled when a label file is opened</source>
        <translation>Lista plików jest wyłączona, gdy otwarty jest plik etykiet</translation>
    </message>
    <message>
        <source>Add Point to Edge</source>
        <translation>Dodaj punkt do krawędzi</translation>
    </message>
    <message>
        <source>Insert a new point at the hovered polygon edge</source>
        <translation>Wstaw nowy punkt na wskazywanej krawędzi wielokąta</translation>
    </message>
    <message>
        <source>&amp;Keep Previous Zoom</source>
        <translation>Zachowaj poprzedni zoom (&amp;K)</translation>
    </message>
    <message>
        <source>Permanently delete this label file? This action cannot be undone.</source>
        <translation>Trwale usunąć ten plik etykiet? Tej operacji nie można cofnąć.</translation>
    </message>
    <message>
        <source>Allowed formats: {formats}</source>
        <translation>Dozwolone formaty: {formats}</translation>
    </message>
    <message>
        <source>The selected label file could not be opened: {path}</source>
        <translation>Nie można otworzyć wybranego pliku etykiet: {path}</translation>
    </message>
    <message>
        <source>The selected image file could not be opened: {path}</source>
        <translation>Nie można otworzyć wybranego pliku obrazu: {path}</translation>
    </message>
    <message>
        <source>Failed to load: {path}</source>
        <translation>Nie udało się wczytać: {path}</translation>
    </message>
    <message>
        <source>Oriented Rectangle</source>
        <translation>Prostokąt Zorientowany</translation>
    </message>
    <message>
        <source>Start drawing oriented rectangles</source>
        <translation>Rozpocznij rysowanie prostokątów zorientowanych</translation>
    </message>
    <message>
        <source>AI inference produced no new annotation.</source>
        <translation>Wnioskowanie AI nie utworzyło nowej adnotacji.</translation>
    </message>
    <message>
        <source>Shape had no area; nothing created.</source>
        <translation>Kształt nie ma obszaru; nic nie zostało utworzone.</translation>
    </message>
    <message>
        <source>Settings…</source>
        <translation>Ustawienia…</translation>
    </message>
    <message>
        <source>Edit settings</source>
        <translation>Edytuj ustawienia</translation>
    </message>
    <message>
        <source>Settings are managed via --config for this session</source>
        <translation>Ustawienia są zarządzane przez --config w tej sesji</translation>
    </message>
    <message>
        <source>Configuration Error</source>
        <translation>Błąd konfiguracji</translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <source>Color theme</source>
        <translation>Motyw kolorystyczny</translation>
    </message>
    <message>
        <source>System</source>
        <translation>Systemowy</translation>
    </message>
    <message>
        <source>Light</source>
        <translation>Jasny</translation>
    </message>
    <message>
        <source>Dark</source>
        <translation>Ciemny</translation>
    </message>
    <message>
        <source>Show label popup on new shape</source>
        <translation>Pokaż okno etykiety przy nowym kształcie</translation>
    </message>
    <message>
        <source>Show shape labels on canvas</source>
        <translation>Pokaż etykiety kształtów na płótnie</translation>
    </message>
    <message>
        <source>Allow points outside the image boundary</source>
        <translation>Zezwalaj na punkty poza granicami obrazu</translation>
    </message>
    <message>
        <source>Appearance and language</source>
        <translation>Wygląd i język</translation>
    </message>
    <message>
        <source>Files and saving</source>
        <translation>Pliki i zapisywanie</translation>
    </message>
    <message>
        <source>Drawing and canvas</source>
        <translation>Rysowanie i płótno</translation>
    </message>
    <message>
        <source>Continue between images</source>
        <translation>Kontynuacja między obrazami</translation>
    </message>
    <message>
        <source>Label sources</source>
        <translation>Źródła etykiet</translation>
    </message>
    <message>
        <source>Label behavior</source>
        <translation>Zachowanie etykiet</translation>
    </message>
    <message>
        <source>AI assist</source>
        <translation>Pomoc AI</translation>
    </message>
    <message>
        <source>Save automatically</source>
        <translation>Zapisuj automatycznie</translation>
    </message>
    <message>
        <source>Save image data in label file</source>
        <translation>Zapisz dane obrazu w pliku etykiet</translation>
    </message>
    <message>
        <source>Embeds the image in the label JSON file.</source>
        <translation>Osadza obraz w pliku JSON etykiety.</translation>
    </message>
    <message>
        <source>Shape Color Mode</source>
        <translation>Tryb koloru kształtu</translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation>Automatyczny</translation>
    </message>
    <message>
        <source>Uniform</source>
        <translation>Jednolity</translation>
    </message>
    <message>
        <source>By Label</source>
        <translation>Według etykiety</translation>
    </message>
    <message>
        <source>Automatic palette shift</source>
        <translation>Automatyczne przesunięcie palety</translation>
    </message>
    <message>
        <source>Uniform mode color</source>
        <translation>Kolor trybu Jednolity</translation>
    </message>
    <message>
        <source>By Label fallback color</source>
        <translation>Kolor zastępczy trybu Według etykiety</translation>
    </message>
    <message>
        <source>Individual Label colors remain editable in the Config File.</source>
        <translation>Kolory poszczególnych etykiet nadal można edytować w pliku konfiguracyjnym.</translation>
    </message>
    <message>
        <source>Keep previous annotation</source>
        <translation>Zachowaj poprzednią adnotację</translation>
    </message>
    <message>
        <source>Keep previous zoom</source>
        <translation>Zachowaj poprzedni zoom</translation>
    </message>
    <message>
        <source>Keep previous brightness/contrast</source>
        <translation>Zachowaj poprzednią jasność/kontrast</translation>
    </message>
    <message>
        <source>Fill polygon while drawing</source>
        <translation>Wypełniaj wielokąt podczas rysowania</translation>
    </message>
    <message>
        <source>Let shape points extend beyond the image, e.g. for partially visible objects.</source>
        <translation>Pozwala punktom kształtu wykraczać poza obraz, np. dla częściowo widocznych obiektów.</translation>
    </message>
    <message>
        <source>Polygon detail</source>
        <translation>Szczegółowość wielokąta</translation>
    </message>
    <message>
        <source>Higher values preserve more Mask boundary detail and smaller lands.</source>
        <translation>Wyższe wartości zachowują więcej szczegółów granicy maski i mniejsze obszary.</translation>
    </message>
    <message>
        <source>Predefined labels</source>
        <translation>Predefiniowane etykiety</translation>
    </message>
    <message>
        <source>Label validation</source>
        <translation>Walidacja etykiet</translation>
    </message>
    <message>
        <source>Sort labels</source>
        <translation>Sortuj etykiety</translation>
    </message>
    <message>
        <source>Sort the label list alphabetically instead of keeping the provided order.</source>
        <translation>Sortuje listę etykiet alfabetycznie zamiast zachowywać podaną kolejność.</translation>
    </message>
    <message>
        <source>Show label text field</source>
        <translation>Pokaż pole tekstowe etykiety</translation>
    </message>
    <message>
        <source>Label completion</source>
        <translation>Uzupełnianie etykiet</translation>
    </message>
    <message>
        <source>Starts with</source>
        <translation>Zaczyna się od</translation>
    </message>
    <message>
        <source>Contains</source>
        <translation>Zawiera</translation>
    </message>
    <message>
        <source>Default model</source>
        <translation>Domyślny model</translation>
    </message>
    <message>
        <source>EfficientSam (speed)</source>
        <translation>EfficientSam (szybkość)</translation>
    </message>
    <message>
        <source>EfficientSam (accuracy)</source>
        <translation>EfficientSam (dokładność)</translation>
    </message>
    <message>
        <source>Sam (speed)</source>
        <translation>Sam (szybkość)</translation>
    </message>
    <message>
        <source>Sam (balanced)</source>
        <translation>Sam (zrównoważony)</translation>
    </message>
    <message>
        <source>Sam (accuracy)</source>
        <translation>Sam (dokładność)</translation>
    </message>
    <message>
        <source>Sam2 (speed)</source>
        <translation>Sam2 (szybkość)</translation>
    </message>
    <message>
        <source>Sam2 (balanced)</source>
        <translation>Sam2 (zrównoważony)</translation>
    </message>
    <message>
        <source>Sam2 (accuracy)</source>
        <translation>Sam2 (dokładność)</translation>
    </message>
    <message>
        <source>Sam3</source>
        <translation>Sam3</translation>
    </message>
    <message>
        <source>Suppress existing Shape matches</source>
        <translation>Pomijaj dopasowania do istniejących kształtów</translation>
    </message>
    <message>
        <source>When an AI Assist candidate matches an existing Shape, highlight that Shape instead of creating a new Shape.</source>
        <translation>Gdy kandydat Pomocy AI pasuje do istniejącego kształtu, ten kształt zostanie wyróżniony zamiast utworzenia nowego kształtu.</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Ustawienia</translation>
    </message>
    <message>
        <source>Open config file as text…</source>
        <translation>Otwórz plik konfiguracji jako tekst…</translation>
    </message>
    <message>
        <source>Edits made in the text file apply after restart</source>
        <translation>Zmiany w pliku tekstowym zostaną zastosowane po ponownym uruchomieniu</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Zamknij</translation>
    </message>
    <message>
        <source>BETA</source>
        <translation>BETA</translation>
    </message>
    <message>
        <source>(none)</source>
        <translation>(brak)</translation>
    </message>
    <message>
        <source>one item per line</source>
        <translation>jeden element na wiersz</translation>
    </message>
    <message>
        <source>Configuration Error</source>
        <translation>Błąd konfiguracji</translation>
    </message>
    <message>
        <source>Predefined labels cannot be empty while Label validation is set to exact. Disable exact validation first.</source>
        <translation>Predefiniowane etykiety nie mogą być puste, gdy walidacja etykiet jest ustawiona na „exact”. Najpierw wyłącz walidację „exact”.</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Język</translation>
    </message>
    <message>
        <source>Takes effect after restart.</source>
        <translation>Zmiana zostanie zastosowana po ponownym uruchomieniu.</translation>
    </message>
    <message>
        <source>System default</source>
        <translation>Domyślny systemu</translation>
    </message>
    <message>
        <source>Predefined image flags</source>
        <translation>Predefiniowane flagi obrazu</translation>
    </message>
</context>
<context>
    <name>_ColorSwatchButton</name>
    <message>
        <source>RGB: {red}, {green}, {blue}</source>
        <translation>RGB: {red}, {green}, {blue}</translation>
    </message>
</context>
<context>
    <name>_SettingsPage</name>
    <message>
        <source>Settings sections</source>
        <translation>Sekcje ustawień</translation>
    </message>
</context>
</TS>
