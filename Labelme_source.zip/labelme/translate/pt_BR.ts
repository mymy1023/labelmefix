<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="pt_BR">
<context>
    <name>AiAssistedAnnotationWidget</name>
    <message>
        <source>AI-Assisted Annotation</source>
        <translation>Anotação Assistida por IA</translation>
    </message>
    <message>
        <source>AI suggests annotation in &apos;AI-Points&apos; and &apos;AI-Box&apos; modes</source>
        <translation>A IA sugere anotações nos modos &apos;AI-Points&apos; e &apos;AI-Box&apos;</translation>
    </message>
    <message>
        <source>Polygon detail</source>
        <translation>Detalhe do polígono</translation>
    </message>
    <message>
        <source>Adjust polygon detail</source>
        <translation>Ajustar detalhe do polígono</translation>
    </message>
    <message>
        <source>Smoother</source>
        <translation>Mais suave</translation>
    </message>
    <message>
        <source>More detail</source>
        <translation>Mais detalhes</translation>
    </message>
    <message>
        <source>Select &apos;AI-Points&apos; or &apos;AI-Box&apos; mode to enable AI-Assisted Annotation</source>
        <translation>Selecione o modo &apos;AI-Points&apos; ou &apos;AI-Box&apos; para habilitar a Anotação Assistida por IA</translation>
    </message>
</context>
<context>
    <name>AiTextToAnnotationWidget</name>
    <message>
        <source>AI Text-to-Annotation</source>
        <translation>Texto para Anotação IA</translation>
    </message>
    <message>
        <source>AI creates annotations from the text prompt</source>
        <translation>IA cria anotações a partir do prompt de texto</translation>
    </message>
    <message>
        <source>e.g., dog,cat,bird</source>
        <translation>ex.: cachorro, gato, pássaro</translation>
    </message>
    <message>
        <source>Run</source>
        <translation>Executar</translation>
    </message>
    <message>
        <source>Score</source>
        <translation>Pontuação</translation>
    </message>
    <message>
        <source>IoU</source>
        <translation>IoU</translation>
    </message>
    <message>
        <source>Select &apos;Polygon&apos;, &apos;Rectangle&apos;, or &apos;AI-Points&apos; mode to enable</source>
        <translation>Selecione o modo &apos;Polygon&apos;, &apos;Rectangle&apos; ou &apos;AI-Points&apos; para ativar</translation>
    </message>
</context>
<context>
    <name>BrightnessContrastDialog</name>
    <message>
        <source>Brightness/Contrast</source>
        <translation>Brilho/Contraste</translation>
    </message>
    <message>
        <source>Brightness:</source>
        <translation>Brilho:</translation>
    </message>
    <message>
        <source>Contrast:</source>
        <translation>Contraste:</translation>
    </message>
</context>
<context>
    <name>Canvas</name>
    <message>
        <source>Click &amp; drag to move point</source>
        <translation>Clique e arraste para mover o ponto</translation>
    </message>
    <message>
        <source>Click &amp; drag to move shape</source>
        <translation>Clique e arraste para mover a forma</translation>
    </message>
    <message>
        <source>Creating %r</source>
        <translation>Criando %r</translation>
    </message>
    <message>
        <source>ESC to cancel</source>
        <translation>ESC para cancelar</translation>
    </message>
    <message>
        <source>Enter or Space to finalize</source>
        <translation>Enter ou Espaço para finalizar</translation>
    </message>
    <message>
        <source>Editing shapes</source>
        <translation>Editando formas</translation>
    </message>
    <message>
        <source>Click start point for line</source>
        <translation>Clique no ponto inicial da linha</translation>
    </message>
    <message>
        <source>Click end point for line</source>
        <translation>Clique no ponto final da linha</translation>
    </message>
    <message>
        <source>Click start point for linestrip</source>
        <translation>Clique no ponto inicial da linha contínua</translation>
    </message>
    <message>
        <source>Click next point or finish by Ctrl/Cmd+Click for linestrip</source>
        <translation>Clique no próximo ponto ou Ctrl/Cmd+Clique para finalizar (linha contínua)</translation>
    </message>
    <message>
        <source>Click center point for circle</source>
        <translation>Clique no ponto central do círculo</translation>
    </message>
    <message>
        <source>Click point on circumference for circle</source>
        <translation>Clique em um ponto da circunferência do círculo</translation>
    </message>
    <message>
        <source>Click first corner for rectangle</source>
        <translation>Clique na primeira esquina do retângulo</translation>
    </message>
    <message>
        <source>Click to add point</source>
        <translation>Clique para adicionar um ponto</translation>
    </message>
    <message>
        <source>ALT + SHIFT + Click to delete point</source>
        <translation>ALT + SHIFT + Clique para excluir o ponto</translation>
    </message>
    <message>
        <source>ALT + Click to create point on shape</source>
        <translation>ALT + Clique para criar um ponto na forma</translation>
    </message>
    <message>
        <source>Right-click &amp; drag to copy shape</source>
        <translation>Clique com o botão direito e arraste para copiar a forma</translation>
    </message>
    <message>
        <source>Click opposite corner for rectangle (Shift for square)</source>
        <translation>Clique na esquina oposta do retângulo (Shift para quadrado)</translation>
    </message>
    <message>
        <source>Click points to include or Shift+Click to exclude. Ctrl+LeftClick ends creation.</source>
        <translation>Clique em pontos para incluir ou Shift+Click para excluir. Ctrl+LeftClick finaliza a criação.</translation>
    </message>
    <message>
        <source>Click first corner of bbox for AI segmentation</source>
        <translation>Clique no primeiro canto do bbox para segmentação com IA</translation>
    </message>
    <message>
        <source>Click opposite corner to segment object</source>
        <translation>Clique no canto oposto para segmentar o objeto</translation>
    </message>
    <message>
        <source>Click first corner for oriented rectangle</source>
        <translation>Clique na primeira esquina do retângulo orientado</translation>
    </message>
    <message>
        <source>Click second corner to set orientation</source>
        <translation>Clique na segunda esquina para definir a orientação</translation>
    </message>
    <message>
        <source>Click third corner to close oriented rectangle</source>
        <translation>Clique na terceira esquina para fechar o retângulo orientado</translation>
    </message>
    <message>
        <source>Click &amp; drag to rotate the shape</source>
        <translation>Clique e arraste para girar a forma</translation>
    </message>
</context>
<context>
    <name>EmptyStateWidget</name>
    <message>
        <source>Start annotating</source>
        <translation>Começar a anotar</translation>
    </message>
    <message>
        <source>Open an image or a directory of images to begin.</source>
        <translation>Abra uma imagem ou uma pasta de imagens para começar.</translation>
    </message>
    <message>
        <source>Open Image</source>
        <translation>Abrir imagem</translation>
    </message>
    <message>
        <source>Open Directory</source>
        <translation>Abrir pasta</translation>
    </message>
    <message>
        <source>Or drag and drop image files here</source>
        <translation>Ou arraste e solte arquivos de imagem aqui</translation>
    </message>
</context>
<context>
    <name>LabelDialog</name>
    <message>
        <source>Shape Label</source>
        <translation>Rótulo da forma</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Rótulo</translation>
    </message>
    <message>
        <source>Group ID</source>
        <translation>ID do grupo</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Descrição</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Flags</source>
        <translation>Marcadores</translation>
    </message>
    <message>
        <source>Shape List</source>
        <translation>Lista de Formas</translation>
    </message>
    <message>
        <source>Select label to start annotating for it. Press &apos;Esc&apos; to deselect.</source>
        <translation>Selecione um rótulo para começar a anotar. Pressione &apos;Esc&apos; para desmarcar.</translation>
    </message>
    <message>
        <source>Label List</source>
        <translation>Lista de Rótulos</translation>
    </message>
    <message>
        <source>Search Filename</source>
        <translation>Buscar Nome do Arquivo</translation>
    </message>
    <message>
        <source>File List</source>
        <translation>Lista de Arquivos</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation>&amp;Sair</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>Sair do aplicativo</translation>
    </message>
    <message>
        <source>&amp;Open
</source>
        <translation>&amp;Abrir</translation>
    </message>
    <message>
        <source>Open image or label file</source>
        <translation>Abrir arquivo de imagem ou rótulo</translation>
    </message>
    <message>
        <source>Open Dir</source>
        <translation>Abrir Diretório</translation>
    </message>
    <message>
        <source>&amp;Next Image</source>
        <translation>Imagem &amp;Seguinte</translation>
    </message>
    <message>
        <source>Open next (hold Ctl+Shift to copy labels)</source>
        <translation>Abrir seguinte (mantenha Ctrl+Shift para copiar rótulos)</translation>
    </message>
    <message>
        <source>&amp;Prev Image</source>
        <translation>Imagem &amp;Anterior</translation>
    </message>
    <message>
        <source>Open prev (hold Ctl+Shift to copy labels)</source>
        <translation>Abrir anterior (mantenha Ctrl+Shift para copiar rótulos)</translation>
    </message>
    <message>
        <source>&amp;Save
</source>
        <translation>&amp;Salvar</translation>
    </message>
    <message>
        <source>Save labels to file</source>
        <translation>Salvar rótulos no arquivo</translation>
    </message>
    <message>
        <source>&amp;Save As</source>
        <translation>Salvar &amp;Como</translation>
    </message>
    <message>
        <source>&amp;Delete File</source>
        <translation>&amp;Excluir Arquivo</translation>
    </message>
    <message>
        <source>Delete current label file</source>
        <translation>Excluir arquivo de rótulo atual</translation>
    </message>
    <message>
        <source>&amp;Change Output Dir</source>
        <translation>Alterar Diretório de &amp;Saída</translation>
    </message>
    <message>
        <source>Change where annotations are loaded/saved</source>
        <translation>Alterar onde as anotações são carregadas/salvas</translation>
    </message>
    <message>
        <source>Save &amp;Automatically</source>
        <translation>Salvar &amp;Automaticamente</translation>
    </message>
    <message>
        <source>Save automatically</source>
        <translation>Salvar automaticamente</translation>
    </message>
    <message>
        <source>Save With Image Data</source>
        <translation>Salvar com Dados da Imagem</translation>
    </message>
    <message>
        <source>Save image data in label file</source>
        <translation>Salvar dados da imagem no arquivo de rótulo</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Fechar</translation>
    </message>
    <message>
        <source>Close current file</source>
        <translation>Fechar arquivo atual</translation>
    </message>
    <message>
        <source>Keep Previous Annotation</source>
        <translation>Manter Anotação Anterior</translation>
    </message>
    <message>
        <source>Start drawing polygons</source>
        <translation>Começar a desenhar polígonos</translation>
    </message>
    <message>
        <source>Start drawing rectangles</source>
        <translation>Começar a desenhar retângulos</translation>
    </message>
    <message>
        <source>Start drawing circles</source>
        <translation>Começar a desenhar círculos</translation>
    </message>
    <message>
        <source>Start drawing lines</source>
        <translation>Começar a desenhar linhas</translation>
    </message>
    <message>
        <source>Start drawing points</source>
        <translation>Começar a desenhar pontos</translation>
    </message>
    <message>
        <source>Edit Shapes</source>
        <translation>Editar Formas</translation>
    </message>
    <message>
        <source>Move and edit the selected shapes</source>
        <translation>Mover e editar as formas selecionadas</translation>
    </message>
    <message>
        <source>Delete Shapes</source>
        <translation>Excluir Formas</translation>
    </message>
    <message>
        <source>Delete the selected shapes</source>
        <translation>Excluir as formas selecionadas</translation>
    </message>
    <message>
        <source>Duplicate Shapes</source>
        <translation>Duplicar Formas</translation>
    </message>
    <message>
        <source>Create a duplicate of the selected shapes</source>
        <translation>Criar uma cópia das formas selecionadas</translation>
    </message>
    <message>
        <source>Undo last point</source>
        <translation>Desfazer último ponto</translation>
    </message>
    <message>
        <source>Undo last drawn point</source>
        <translation>Desfazer último ponto desenhado</translation>
    </message>
    <message>
        <source>Remove Selected Point</source>
        <translation>Remover Ponto Selecionado</translation>
    </message>
    <message>
        <source>Remove selected point from polygon</source>
        <translation>Remover ponto selecionado do polígono</translation>
    </message>
    <message>
        <source>Undo
</source>
        <translation>Desfazer</translation>
    </message>
    <message>
        <source>Undo last add and edit of shape</source>
        <translation>Desfazer última adição e edição de forma</translation>
    </message>
    <message>
        <source>&amp;Hide
Shapes</source>
        <translation>Ocultar &amp;Formas</translation>
    </message>
    <message>
        <source>Hide all shapes</source>
        <translation>Ocultar todas as formas</translation>
    </message>
    <message>
        <source>&amp;Show
Shapes</source>
        <translation>Mostrar &amp;Formas</translation>
    </message>
    <message>
        <source>Show all shapes</source>
        <translation>Mostrar todas as formas</translation>
    </message>
    <message>
        <source>&amp;Toggle
Shapes</source>
        <translation>Alternar &amp;Formas</translation>
    </message>
    <message>
        <source>Toggle all shapes</source>
        <translation>Alternar todas as formas</translation>
    </message>
    <message>
        <source>&amp;Tutorial</source>
        <translation>&amp;Tutorial</translation>
    </message>
    <message>
        <source>Show tutorial page</source>
        <translation>Mostrar página do tutorial</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation>Zoom</translation>
    </message>
    <message>
        <source>Zoom &amp;In</source>
        <translation>&amp;Aproximar</translation>
    </message>
    <message>
        <source>&amp;Zoom Out</source>
        <translation>&amp;Afastar</translation>
    </message>
    <message>
        <source>&amp;Brightness Contrast</source>
        <translation>Brilho e &amp;Contraste</translation>
    </message>
    <message>
        <source>Adjust brightness and contrast</source>
        <translation>Ajustar brilho e contraste</translation>
    </message>
    <message>
        <source>&amp;Edit Label</source>
        <translation>&amp;Editar Rótulo</translation>
    </message>
    <message>
        <source>Save the labels under a new file name</source>
        <translation>Salvar os rótulos com um novo nome de arquivo</translation>
    </message>
    <message>
        <source>Modify the label of the selected shape</source>
        <translation>Modificar o rótulo da forma selecionada</translation>
    </message>
    <message>
        <source>Copy to Clipboard</source>
        <translation>Copiar para a Área de Transferência</translation>
    </message>
    <message>
        <source>Place the selected shapes on the clipboard</source>
        <translation>Colocar as formas selecionadas na área de transferência</translation>
    </message>
    <message>
        <source>Paste from Clipboard</source>
        <translation>Colar da Área de Transferência</translation>
    </message>
    <message>
        <source>Insert the clipboard shapes into this image</source>
        <translation>Inserir nesta imagem as formas da área de transferência</translation>
    </message>
    <message>
        <source>Click to place linestrip points; Ctrl+click places the last one.</source>
        <translation>Clique para posicionar pontos da linha contínua; Ctrl+clique posiciona o último.</translation>
    </message>
    <message>
        <source>Fit to &amp;Window</source>
        <translation>Ajustar à &amp;Janela</translation>
    </message>
    <message>
        <source>Keep the whole image visible when the window is resized</source>
        <translation>Manter a imagem inteira visível quando a janela for redimensionada</translation>
    </message>
    <message>
        <source>Fit to Wi&amp;dth</source>
        <translation>Ajustar à &amp;Largura</translation>
    </message>
    <message>
        <source>Match the image width to the window when it is resized</source>
        <translation>Igualar a largura da imagem à janela quando ela for redimensionada</translation>
    </message>
    <message>
        <source>Make the image appear larger</source>
        <translation>Mostrar a imagem maior</translation>
    </message>
    <message>
        <source>Make the image appear smaller</source>
        <translation>Mostrar a imagem menor</translation>
    </message>
    <message>
        <source>&amp;Actual Size</source>
        <translation>Tamanho &amp;real</translation>
    </message>
    <message>
        <source>Show the image at 100%</source>
        <translation>Mostrar a imagem em 100%</translation>
    </message>
    <message>
        <source>Fill Drawing Polygon</source>
        <translation>Preencher Polígono ao Desenhar</translation>
    </message>
    <message>
        <source>Fill polygon while drawing</source>
        <translation>Preencher polígono enquanto desenha</translation>
    </message>
    <message>
        <source>Ctrl+Wheel zooms the canvas</source>
        <translation>Ctrl+Roda amplia a tela</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Arquivo</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Editar</translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation>&amp;Visualizar</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Ajuda</translation>
    </message>
    <message>
        <source>%s started.</source>
        <translation>%s iniciado.</translation>
    </message>
    <message>
        <source>Mask Output Unavailable</source>
        <translation>Saída de máscara indisponível</translation>
    </message>
    <message>
        <source>%s only detects bounding boxes and cannot create &apos;%s&apos; annotations.

Switch the AI Text-to-Annotation model to &apos;SAM3 (smart)&apos;, or set the output format to &apos;Rectangle&apos;.</source>
        <translation>%s detecta apenas caixas delimitadoras e não pode criar anotações &apos;%s&apos;.

Mude o modelo de AI Text-to-Annotation para &apos;SAM3 (smart)&apos; ou defina o formato de saída como &apos;Rectangle&apos;.</translation>
    </message>
    <message>
        <source>Invalid label</source>
        <translation>Rótulo inválido</translation>
    </message>
    <message>
        <source>Invalid label &apos;{}&apos; with validation type &apos;{}&apos;</source>
        <translation>Rótulo inválido &apos;{}&apos; com tipo de validação &apos;{}&apos;</translation>
    </message>
    <message>
        <source>Error saving label data</source>
        <translation>Erro ao salvar dados do rótulo</translation>
    </message>
    <message>
        <source>&lt;b&gt;%s&lt;/b&gt;</source>
        <translation>&lt;b&gt;%s&lt;/b&gt;</translation>
    </message>
    <message>
        <source>AI inference failed: %s</source>
        <translation>Falha na inferência de IA: %s</translation>
    </message>
    <message>
        <source>Error opening file</source>
        <translation>Erro ao abrir arquivo</translation>
    </message>
    <message>
        <source>No such file: &lt;b&gt;%s&lt;/b&gt;</source>
        <translation>Arquivo não encontrado: &lt;b&gt;%s&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Loading %s...</source>
        <translation>Carregando %s...</translation>
    </message>
    <message>
        <source>Loaded %s</source>
        <translation>Carregado %s</translation>
    </message>
    <message>
        <source>Image &amp; Label files (%s)</source>
        <translation>Arquivos de Imagem e Rótulo (%s)</translation>
    </message>
    <message>
        <source>%s - Choose Image or Label file</source>
        <translation>%s - Escolher Arquivo de Imagem ou Rótulo</translation>
    </message>
    <message>
        <source>%s - Save/Load Annotations in Directory</source>
        <translation>%s - Salvar/Carregar Anotações no Diretório</translation>
    </message>
    <message>
        <source>%s . Annotations will be saved/loaded in %s</source>
        <translation>%s . As anotações serão salvas/carregadas em %s</translation>
    </message>
    <message>
        <source>%s - Choose File</source>
        <translation>%s - Escolher Arquivo</translation>
    </message>
    <message>
        <source>Label files (*%s)</source>
        <translation>Arquivos de rótulo (*%s)</translation>
    </message>
    <message>
        <source>Choose File</source>
        <translation>Escolher Arquivo</translation>
    </message>
    <message>
        <source>Attention</source>
        <translation>Atenção</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Excluir</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Unavailable in AI-Points mode because this model does not support point prompts.</source>
        <translation>Indisponível no modo AI-Points porque este modelo não oferece suporte a prompts de pontos.</translation>
    </message>
    <message>
        <source>Save annotations to &quot;{}&quot; before closing?</source>
        <translation>Salvar anotações em &quot;{}&quot; antes de fechar?</translation>
    </message>
    <message>
        <source>Save annotations?</source>
        <translation>Salvar anotações?</translation>
    </message>
    <message>
        <source>Delete {} shapes? You can restore them with Undo.</source>
        <translation>Excluir {} formas? Você pode restaurá-las com Desfazer.</translation>
    </message>
    <message>
        <source>%s - Open Directory</source>
        <translation>%s - Abrir Diretório</translation>
    </message>
    <message>
        <source>The image is too large to open: {width}x{height} pixels exceeds the {max_side} pixel per-side limit of the raster engine. Raising the decode limit will not help. Split the image into tiles (for example with gdal_retile.py) or open a smaller copy.</source>
        <translation>A imagem é grande demais para ser aberta: {width}x{height} pixels excede o limite de {max_side} pixels por lado do mecanismo raster. Aumentar o limite de decodificação não vai ajudar. Divida a imagem em blocos (por exemplo com gdal_retile.py) ou abra uma cópia menor.</translation>
    </message>
    <message>
        <source>The image is too large to open: {width}x{height} pixels needs about {required} MB, but the decode limit is {limit} MB. Split the image into tiles (for example with gdal_retile.py) or open a smaller copy.</source>
        <translation>A imagem é grande demais para ser aberta: {width}x{height} pixels precisa de cerca de {required} MB, mas o limite de decodificação é {limit} MB. Divida a imagem em blocos (por exemplo com gdal_retile.py) ou abra uma cópia menor.</translation>
    </message>
    <message>
        <source>Toggle &quot;keep previous annotation&quot; mode</source>
        <translation>Alternar modo &quot;manter anotação anterior&quot;</translation>
    </message>
    <message>
        <source>Keep Previous Brightness/Contrast</source>
        <translation>Manter Brilho/Contraste Anterior</translation>
    </message>
    <message>
        <source>Configuration Errors</source>
        <translation>Erros de Configuração</translation>
    </message>
    <message>
        <source>Errors were found while loading the configuration. Please review the errors below and reload your configuration or ignore the erroneous lines.</source>
        <translation>Foram encontrados erros ao carregar a configuração. Por favor, revise os erros abaixo e recarregue sua configuração ou ignore as linhas com erro.</translation>
    </message>
    <message>
        <source>Reset Layout</source>
        <translation>Redefinir layout</translation>
    </message>
    <message>
        <source>Polygon</source>
        <translation>Polígono</translation>
    </message>
    <message>
        <source>Rectangle</source>
        <translation>Retângulo</translation>
    </message>
    <message>
        <source>Circle</source>
        <translation>Círculo</translation>
    </message>
    <message>
        <source>Line</source>
        <translation>Linha</translation>
    </message>
    <message>
        <source>Point</source>
        <translation>Ponto</translation>
    </message>
    <message>
        <source>LineStrip</source>
        <translation>Linha Contínua</translation>
    </message>
    <message>
        <source>AI-Points</source>
        <translation>AI-Points</translation>
    </message>
    <message>
        <source>Click points to segment object. Ctrl+LeftClick ends creation.</source>
        <translation>Clique em pontos para segmentar o objeto. Ctrl+LeftClick finaliza a criação.</translation>
    </message>
    <message>
        <source>AI-Box</source>
        <translation>AI-Box</translation>
    </message>
    <message>
        <source>Draw a bounding box to segment object.</source>
        <translation>Desenhe uma caixa delimitadora para segmentar o objeto.</translation>
    </message>
    <message>
        <source>AI-Points Unavailable</source>
        <translation>AI-Points indisponível</translation>
    </message>
    <message>
        <source>%s does not support point prompts.
Please select a different model or use AI-Box mode.</source>
        <translation>%s não suporta prompts de pontos.
Selecione um modelo diferente ou use o modo AI-Box.</translation>
    </message>
    <message>
        <source>File list is disabled when a label file is opened</source>
        <translation>A lista de arquivos está desativada quando um arquivo de rótulos é aberto</translation>
    </message>
    <message>
        <source>Add Point to Edge</source>
        <translation>Adicionar ponto à aresta</translation>
    </message>
    <message>
        <source>Insert a new point at the hovered polygon edge</source>
        <translation>Inserir um novo ponto na aresta do polígono em foco</translation>
    </message>
    <message>
        <source>&amp;Keep Previous Zoom</source>
        <translation>Manter Zoom &amp;Anterior</translation>
    </message>
    <message>
        <source>Permanently delete this label file? This action cannot be undone.</source>
        <translation>Excluir permanentemente este arquivo de rótulo? Esta ação não pode ser desfeita.</translation>
    </message>
    <message>
        <source>Allowed formats: {formats}</source>
        <translation>Formatos permitidos: {formats}</translation>
    </message>
    <message>
        <source>The selected label file could not be opened: {path}</source>
        <translation>Não foi possível abrir o arquivo de rótulo selecionado: {path}</translation>
    </message>
    <message>
        <source>The selected image file could not be opened: {path}</source>
        <translation>Não foi possível abrir o arquivo de imagem selecionado: {path}</translation>
    </message>
    <message>
        <source>Failed to load: {path}</source>
        <translation>Falha ao carregar: {path}</translation>
    </message>
    <message>
        <source>Oriented Rectangle</source>
        <translation>Retângulo Orientado</translation>
    </message>
    <message>
        <source>Start drawing oriented rectangles</source>
        <translation>Começar a desenhar retângulos orientados</translation>
    </message>
    <message>
        <source>AI inference produced no new annotation.</source>
        <translation>A inferência de IA não produziu nenhuma nova anotação.</translation>
    </message>
    <message>
        <source>Shape had no area; nothing created.</source>
        <translation>A forma não tinha área; nenhum objeto criado.</translation>
    </message>
    <message>
        <source>Settings…</source>
        <translation>Configurações…</translation>
    </message>
    <message>
        <source>Edit settings</source>
        <translation>Editar configurações</translation>
    </message>
    <message>
        <source>Settings are managed via --config for this session</source>
        <translation>As configurações desta sessão são gerenciadas via --config</translation>
    </message>
    <message>
        <source>Configuration Error</source>
        <translation>Erro de Configuração</translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <source>Color theme</source>
        <translation>Tema de cores</translation>
    </message>
    <message>
        <source>System</source>
        <translation>Sistema</translation>
    </message>
    <message>
        <source>Light</source>
        <translation>Claro</translation>
    </message>
    <message>
        <source>Dark</source>
        <translation>Escuro</translation>
    </message>
    <message>
        <source>Show label popup on new shape</source>
        <translation>Mostrar popup de rótulo ao criar nova forma</translation>
    </message>
    <message>
        <source>Show shape labels on canvas</source>
        <translation>Mostrar rótulos das formas na tela</translation>
    </message>
    <message>
        <source>Allow points outside the image boundary</source>
        <translation>Permitir pontos fora dos limites da imagem</translation>
    </message>
    <message>
        <source>Appearance and language</source>
        <translation>Aparência e idioma</translation>
    </message>
    <message>
        <source>Files and saving</source>
        <translation>Arquivos e salvamento</translation>
    </message>
    <message>
        <source>Drawing and canvas</source>
        <translation>Desenho e tela</translation>
    </message>
    <message>
        <source>Continue between images</source>
        <translation>Continuar entre imagens</translation>
    </message>
    <message>
        <source>Label sources</source>
        <translation>Fontes de rótulos</translation>
    </message>
    <message>
        <source>Label behavior</source>
        <translation>Comportamento dos rótulos</translation>
    </message>
    <message>
        <source>AI assist</source>
        <translation>Assistência de IA</translation>
    </message>
    <message>
        <source>Save automatically</source>
        <translation>Salvar automaticamente</translation>
    </message>
    <message>
        <source>Save image data in label file</source>
        <translation>Salvar dados da imagem no arquivo de rótulo</translation>
    </message>
    <message>
        <source>Embeds the image in the label JSON file.</source>
        <translation>Incorpora a imagem no arquivo JSON de rótulos.</translation>
    </message>
    <message>
        <source>Shape Color Mode</source>
        <translation>Modo de cor da forma</translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation>Automático</translation>
    </message>
    <message>
        <source>Uniform</source>
        <translation>Uniforme</translation>
    </message>
    <message>
        <source>By Label</source>
        <translation>Por rótulo</translation>
    </message>
    <message>
        <source>Automatic palette shift</source>
        <translation>Deslocamento automático da paleta</translation>
    </message>
    <message>
        <source>Uniform mode color</source>
        <translation>Cor do modo Uniforme</translation>
    </message>
    <message>
        <source>By Label fallback color</source>
        <translation>Cor alternativa do modo Por rótulo</translation>
    </message>
    <message>
        <source>Individual Label colors remain editable in the Config File.</source>
        <translation>As cores individuais dos rótulos continuam editáveis no arquivo de configuração.</translation>
    </message>
    <message>
        <source>Keep previous annotation</source>
        <translation>Manter anotação anterior</translation>
    </message>
    <message>
        <source>Keep previous zoom</source>
        <translation>Manter zoom anterior</translation>
    </message>
    <message>
        <source>Keep previous brightness/contrast</source>
        <translation>Manter brilho/contraste anteriores</translation>
    </message>
    <message>
        <source>Fill polygon while drawing</source>
        <translation>Preencher polígono enquanto desenha</translation>
    </message>
    <message>
        <source>Let shape points extend beyond the image, e.g. for partially visible objects.</source>
        <translation>Permite que os pontos das formas se estendam além da imagem, por ex. para objetos parcialmente visíveis.</translation>
    </message>
    <message>
        <source>Polygon detail</source>
        <translation>Detalhe do polígono</translation>
    </message>
    <message>
        <source>Higher values preserve more Mask boundary detail and smaller lands.</source>
        <translation>Valores mais altos preservam mais detalhes da borda da máscara e regiões menores.</translation>
    </message>
    <message>
        <source>Predefined labels</source>
        <translation>Rótulos predefinidos</translation>
    </message>
    <message>
        <source>Label validation</source>
        <translation>Validação de rótulo</translation>
    </message>
    <message>
        <source>Sort labels</source>
        <translation>Ordenar rótulos</translation>
    </message>
    <message>
        <source>Sort the label list alphabetically instead of keeping the provided order.</source>
        <translation>Ordena a lista de rótulos alfabeticamente em vez de manter a ordem fornecida.</translation>
    </message>
    <message>
        <source>Show label text field</source>
        <translation>Mostrar campo de texto do rótulo</translation>
    </message>
    <message>
        <source>Label completion</source>
        <translation>Autocompletar rótulos</translation>
    </message>
    <message>
        <source>Starts with</source>
        <translation>Começa com</translation>
    </message>
    <message>
        <source>Contains</source>
        <translation>Contém</translation>
    </message>
    <message>
        <source>Default model</source>
        <translation>Modelo padrão</translation>
    </message>
    <message>
        <source>EfficientSam (speed)</source>
        <translation>EfficientSam (velocidade)</translation>
    </message>
    <message>
        <source>EfficientSam (accuracy)</source>
        <translation>EfficientSam (precisão)</translation>
    </message>
    <message>
        <source>Sam (speed)</source>
        <translation>Sam (velocidade)</translation>
    </message>
    <message>
        <source>Sam (balanced)</source>
        <translation>Sam (equilibrado)</translation>
    </message>
    <message>
        <source>Sam (accuracy)</source>
        <translation>Sam (precisão)</translation>
    </message>
    <message>
        <source>Sam2 (speed)</source>
        <translation>Sam2 (velocidade)</translation>
    </message>
    <message>
        <source>Sam2 (balanced)</source>
        <translation>Sam2 (equilibrado)</translation>
    </message>
    <message>
        <source>Sam2 (accuracy)</source>
        <translation>Sam2 (precisão)</translation>
    </message>
    <message>
        <source>Sam3</source>
        <translation>Sam3</translation>
    </message>
    <message>
        <source>Suppress existing Shape matches</source>
        <translation>Suprimir correspondências com formas existentes</translation>
    </message>
    <message>
        <source>When an AI Assist candidate matches an existing Shape, highlight that Shape instead of creating a new Shape.</source>
        <translation>Quando um candidato da Assistência de IA corresponde a uma forma existente, essa forma é destacada em vez de criar uma nova forma.</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Configurações</translation>
    </message>
    <message>
        <source>Open config file as text…</source>
        <translation>Abrir arquivo de configuração como texto…</translation>
    </message>
    <message>
        <source>Edits made in the text file apply after restart</source>
        <translation>Edições no arquivo de texto são aplicadas após reiniciar</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <source>BETA</source>
        <translation>BETA</translation>
    </message>
    <message>
        <source>(none)</source>
        <translation>(nenhum)</translation>
    </message>
    <message>
        <source>one item per line</source>
        <translation>um item por linha</translation>
    </message>
    <message>
        <source>Configuration Error</source>
        <translation>Erro de Configuração</translation>
    </message>
    <message>
        <source>Predefined labels cannot be empty while Label validation is set to exact. Disable exact validation first.</source>
        <translation>Os rótulos predefinidos não podem ficar vazios enquanto a validação de rótulo estiver definida como «exact». Desative primeiro a validação «exact».</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Idioma</translation>
    </message>
    <message>
        <source>Takes effect after restart.</source>
        <translation>Aplicado após reiniciar o aplicativo.</translation>
    </message>
    <message>
        <source>System default</source>
        <translation>Padrão do sistema</translation>
    </message>
    <message>
        <source>Predefined image flags</source>
        <translation>Sinalizadores de imagem predefinidos</translation>
    </message>
</context>
<context>
    <name>_ColorSwatchButton</name>
    <message>
        <source>RGB: {red}, {green}, {blue}</source>
        <translation>RGB: {red}, {green}, {blue}</translation>
    </message>
</context>
<context>
    <name>_SettingsPage</name>
    <message>
        <source>Settings sections</source>
        <translation>Seções de configurações</translation>
    </message>
</context>
</TS>
