<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="nl_NL">
<context>
    <name>AiAssistedAnnotationWidget</name>
    <message>
        <source>AI-Assisted Annotation</source>
        <translation>AI-Ondersteunde Annotatie</translation>
    </message>
    <message>
        <source>AI suggests annotation in &apos;AI-Points&apos; and &apos;AI-Box&apos; modes</source>
        <translation>AI stelt annotaties voor in de modi &apos;AI-Points&apos; en &apos;AI-Box&apos;</translation>
    </message>
    <message>
        <source>Polygon detail</source>
        <translation>Polygoondetail</translation>
    </message>
    <message>
        <source>Adjust polygon detail</source>
        <translation>Polygoondetail aanpassen</translation>
    </message>
    <message>
        <source>Smoother</source>
        <translation>Gladder</translation>
    </message>
    <message>
        <source>More detail</source>
        <translation>Meer detail</translation>
    </message>
    <message>
        <source>Select &apos;AI-Points&apos; or &apos;AI-Box&apos; mode to enable AI-Assisted Annotation</source>
        <translation>Selecteer de modus &apos;AI-Points&apos; of &apos;AI-Box&apos; om AI-ondersteunde annotatie in te schakelen</translation>
    </message>
</context>
<context>
    <name>AiTextToAnnotationWidget</name>
    <message>
        <source>AI Text-to-Annotation</source>
        <translation>AI Tekst-naar-Annotatie</translation>
    </message>
    <message>
        <source>AI creates annotations from the text prompt</source>
        <translation>AI maakt annotaties van de tekstprompt</translation>
    </message>
    <message>
        <source>e.g., dog,cat,bird</source>
        <translation>bijv. hond, kat, vogel</translation>
    </message>
    <message>
        <source>Run</source>
        <translation>Uitvoeren</translation>
    </message>
    <message>
        <source>Score</source>
        <translation>Score</translation>
    </message>
    <message>
        <source>IoU</source>
        <translation>IoU</translation>
    </message>
    <message>
        <source>Select &apos;Polygon&apos;, &apos;Rectangle&apos;, or &apos;AI-Points&apos; mode to enable</source>
        <translation>Selecteer &apos;Polygon&apos;, &apos;Rectangle&apos; of &apos;AI-Points&apos;-modus om in te schakelen</translation>
    </message>
</context>
<context>
    <name>BrightnessContrastDialog</name>
    <message>
        <source>Brightness/Contrast</source>
        <translation>Helderheid/Contrast</translation>
    </message>
    <message>
        <source>Brightness:</source>
        <translation>Helderheid:</translation>
    </message>
    <message>
        <source>Contrast:</source>
        <translation>Contrast:</translation>
    </message>
</context>
<context>
    <name>Canvas</name>
    <message>
        <source>Click &amp; drag to move point</source>
        <translation>Klik en sleep om punt te verplaatsen</translation>
    </message>
    <message>
        <source>Click &amp; drag to move shape</source>
        <translation>Klik en sleep om vorm te verplaatsen</translation>
    </message>
    <message>
        <source>Creating %r</source>
        <translation>Maken van %r</translation>
    </message>
    <message>
        <source>ESC to cancel</source>
        <translation>ESC om te annuleren</translation>
    </message>
    <message>
        <source>Enter or Space to finalize</source>
        <translation>Enter of Spatie om te voltooien</translation>
    </message>
    <message>
        <source>Editing shapes</source>
        <translation>Vormen bewerken</translation>
    </message>
    <message>
        <source>Click start point for line</source>
        <translation>Klik op startpunt voor lijn</translation>
    </message>
    <message>
        <source>Click end point for line</source>
        <translation>Klik op eindpunt voor lijn</translation>
    </message>
    <message>
        <source>Click start point for linestrip</source>
        <translation>Klik op startpunt voor lijnstrook</translation>
    </message>
    <message>
        <source>Click next point or finish by Ctrl/Cmd+Click for linestrip</source>
        <translation>Klik op volgend punt of Ctrl/Cmd+Klik om te voltooien (lijnstrook)</translation>
    </message>
    <message>
        <source>Click center point for circle</source>
        <translation>Klik op middelpunt voor cirkel</translation>
    </message>
    <message>
        <source>Click point on circumference for circle</source>
        <translation>Klik op punt op omtrek voor cirkel</translation>
    </message>
    <message>
        <source>Click first corner for rectangle</source>
        <translation>Klik op eerste hoek voor rechthoek</translation>
    </message>
    <message>
        <source>Click to add point</source>
        <translation>Klik om punt toe te voegen</translation>
    </message>
    <message>
        <source>ALT + SHIFT + Click to delete point</source>
        <translation>ALT + SHIFT + Klik om punt te verwijderen</translation>
    </message>
    <message>
        <source>ALT + Click to create point on shape</source>
        <translation>ALT + Klik om punt op vorm te maken</translation>
    </message>
    <message>
        <source>Right-click &amp; drag to copy shape</source>
        <translation>Rechtsklik en sleep om vorm te kopiëren</translation>
    </message>
    <message>
        <source>Click opposite corner for rectangle (Shift for square)</source>
        <translation>Klik op tegenoverliggende hoek voor rechthoek (Shift voor vierkant)</translation>
    </message>
    <message>
        <source>Click points to include or Shift+Click to exclude. Ctrl+LeftClick ends creation.</source>
        <translation>Klik op punten om toe te voegen of Shift+Click om uit te sluiten. Ctrl+LeftClick beëindigt het maken.</translation>
    </message>
    <message>
        <source>Click first corner of bbox for AI segmentation</source>
        <translation>Klik op de eerste hoek van de bbox voor AI-segmentatie</translation>
    </message>
    <message>
        <source>Click opposite corner to segment object</source>
        <translation>Klik op de tegenoverliggende hoek om het object te segmenteren</translation>
    </message>
    <message>
        <source>Click first corner for oriented rectangle</source>
        <translation>Klik op eerste hoek voor georiënteerde rechthoek</translation>
    </message>
    <message>
        <source>Click second corner to set orientation</source>
        <translation>Klik op tweede hoek om oriëntatie in te stellen</translation>
    </message>
    <message>
        <source>Click third corner to close oriented rectangle</source>
        <translation>Klik op derde hoek om georiënteerde rechthoek te sluiten</translation>
    </message>
    <message>
        <source>Click &amp; drag to rotate the shape</source>
        <translation>Klik en sleep om vorm te draaien</translation>
    </message>
</context>
<context>
    <name>EmptyStateWidget</name>
    <message>
        <source>Start annotating</source>
        <translation>Begin met annoteren</translation>
    </message>
    <message>
        <source>Open an image or a directory of images to begin.</source>
        <translation>Open een afbeelding of een map met afbeeldingen om te beginnen.</translation>
    </message>
    <message>
        <source>Open Image</source>
        <translation>Afbeelding openen</translation>
    </message>
    <message>
        <source>Open Directory</source>
        <translation>Map openen</translation>
    </message>
    <message>
        <source>Or drag and drop image files here</source>
        <translation>Of sleep afbeeldingsbestanden hierheen</translation>
    </message>
</context>
<context>
    <name>LabelDialog</name>
    <message>
        <source>Shape Label</source>
        <translation>Vormlabel</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Label</translation>
    </message>
    <message>
        <source>Group ID</source>
        <translation>Groeps-ID</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Beschrijving</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Flags</source>
        <translation>Vlaggen</translation>
    </message>
    <message>
        <source>Shape List</source>
        <translation>Vormenlijst</translation>
    </message>
    <message>
        <source>Select label to start annotating for it. Press &apos;Esc&apos; to deselect.</source>
        <translation>Selecteer label om te beginnen met annoteren. Druk op &apos;Esc&apos; om te deselecteren.</translation>
    </message>
    <message>
        <source>Label List</source>
        <translation>Labellijst</translation>
    </message>
    <message>
        <source>Search Filename</source>
        <translation>Zoek Bestandsnaam</translation>
    </message>
    <message>
        <source>File List</source>
        <translation>Bestandslijst</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation>&amp;Afsluiten</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>Applicatie afsluiten</translation>
    </message>
    <message>
        <source>&amp;Open
</source>
        <translation>&amp;Openen</translation>
    </message>
    <message>
        <source>Open image or label file</source>
        <translation>Afbeelding of labelbestand openen</translation>
    </message>
    <message>
        <source>Open Dir</source>
        <translation>Map Openen</translation>
    </message>
    <message>
        <source>&amp;Next Image</source>
        <translation>Volgende &amp;Afbeelding</translation>
    </message>
    <message>
        <source>Open next (hold Ctl+Shift to copy labels)</source>
        <translation>Volgende openen (houd Ctrl+Shift ingedrukt om labels te kopiëren)</translation>
    </message>
    <message>
        <source>&amp;Prev Image</source>
        <translation>Vorige &amp;Afbeelding</translation>
    </message>
    <message>
        <source>Open prev (hold Ctl+Shift to copy labels)</source>
        <translation>Vorige openen (houd Ctrl+Shift ingedrukt om labels te kopiëren)</translation>
    </message>
    <message>
        <source>&amp;Save
</source>
        <translation>&amp;Opslaan</translation>
    </message>
    <message>
        <source>Save labels to file</source>
        <translation>Labels opslaan naar bestand</translation>
    </message>
    <message>
        <source>&amp;Save As</source>
        <translation>Opslaan &amp;als</translation>
    </message>
    <message>
        <source>&amp;Delete File</source>
        <translation>Bestand &amp;verwijderen</translation>
    </message>
    <message>
        <source>Delete current label file</source>
        <translation>Huidig labelbestand verwijderen</translation>
    </message>
    <message>
        <source>&amp;Change Output Dir</source>
        <translation>Uitvoermap &amp;wijzigen</translation>
    </message>
    <message>
        <source>Change where annotations are loaded/saved</source>
        <translation>Wijzig waar annotaties worden geladen/opgeslagen</translation>
    </message>
    <message>
        <source>Save &amp;Automatically</source>
        <translation>&amp;Automatisch opslaan</translation>
    </message>
    <message>
        <source>Save automatically</source>
        <translation>Automatisch opslaan</translation>
    </message>
    <message>
        <source>Save With Image Data</source>
        <translation>Opslaan met Afbeeldingsgegevens</translation>
    </message>
    <message>
        <source>Save image data in label file</source>
        <translation>Afbeeldingsgegevens opslaan in labelbestand</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Sluiten</translation>
    </message>
    <message>
        <source>Close current file</source>
        <translation>Huidig bestand sluiten</translation>
    </message>
    <message>
        <source>Keep Previous Annotation</source>
        <translation>Vorige Annotatie Behouden</translation>
    </message>
    <message>
        <source>Start drawing polygons</source>
        <translation>Begin met tekenen van polygonen</translation>
    </message>
    <message>
        <source>Start drawing rectangles</source>
        <translation>Begin met tekenen van rechthoeken</translation>
    </message>
    <message>
        <source>Start drawing circles</source>
        <translation>Begin met tekenen van cirkels</translation>
    </message>
    <message>
        <source>Start drawing lines</source>
        <translation>Begin met tekenen van lijnen</translation>
    </message>
    <message>
        <source>Start drawing points</source>
        <translation>Begin met tekenen van punten</translation>
    </message>
    <message>
        <source>Edit Shapes</source>
        <translation>Vormen Bewerken</translation>
    </message>
    <message>
        <source>Move and edit the selected shapes</source>
        <translation>Verplaats en bewerk de geselecteerde vormen</translation>
    </message>
    <message>
        <source>Delete Shapes</source>
        <translation>Vormen Verwijderen</translation>
    </message>
    <message>
        <source>Delete the selected shapes</source>
        <translation>Geselecteerde vormen verwijderen</translation>
    </message>
    <message>
        <source>Duplicate Shapes</source>
        <translation>Vormen Dupliceren</translation>
    </message>
    <message>
        <source>Create a duplicate of the selected shapes</source>
        <translation>Maak een duplicaat van de geselecteerde vormen</translation>
    </message>
    <message>
        <source>Undo last point</source>
        <translation>Laatste punt ongedaan maken</translation>
    </message>
    <message>
        <source>Undo last drawn point</source>
        <translation>Laatste getekende punt ongedaan maken</translation>
    </message>
    <message>
        <source>Remove Selected Point</source>
        <translation>Geselecteerd Punt Verwijderen</translation>
    </message>
    <message>
        <source>Remove selected point from polygon</source>
        <translation>Geselecteerd punt uit polygoon verwijderen</translation>
    </message>
    <message>
        <source>Undo
</source>
        <translation>Ongedaan Maken</translation>
    </message>
    <message>
        <source>Undo last add and edit of shape</source>
        <translation>Laatste toevoeging en bewerking van vorm ongedaan maken</translation>
    </message>
    <message>
        <source>&amp;Hide
Shapes</source>
        <translation>Vormen &amp;verbergen</translation>
    </message>
    <message>
        <source>Hide all shapes</source>
        <translation>Alle vormen verbergen</translation>
    </message>
    <message>
        <source>&amp;Show
Shapes</source>
        <translation>Vormen &amp;tonen</translation>
    </message>
    <message>
        <source>Show all shapes</source>
        <translation>Alle vormen tonen</translation>
    </message>
    <message>
        <source>&amp;Toggle
Shapes</source>
        <translation>Vormen &amp;omschakelen</translation>
    </message>
    <message>
        <source>Toggle all shapes</source>
        <translation>Alle vormen omschakelen</translation>
    </message>
    <message>
        <source>&amp;Tutorial</source>
        <translation>&amp;Tutorial</translation>
    </message>
    <message>
        <source>Show tutorial page</source>
        <translation>Tutorialpagina tonen</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation>Zoom</translation>
    </message>
    <message>
        <source>Zoom &amp;In</source>
        <translation>&amp;Inzoomen</translation>
    </message>
    <message>
        <source>&amp;Zoom Out</source>
        <translation>&amp;Uitzoomen</translation>
    </message>
    <message>
        <source>&amp;Brightness Contrast</source>
        <translation>Helderheid en &amp;contrast</translation>
    </message>
    <message>
        <source>Adjust brightness and contrast</source>
        <translation>Helderheid en contrast aanpassen</translation>
    </message>
    <message>
        <source>&amp;Edit Label</source>
        <translation>Label &amp;bewerken</translation>
    </message>
    <message>
        <source>Save the labels under a new file name</source>
        <translation>Labels opslaan onder een nieuwe bestandsnaam</translation>
    </message>
    <message>
        <source>Modify the label of the selected shape</source>
        <translation>Label van geselecteerde vorm wijzigen</translation>
    </message>
    <message>
        <source>Copy to Clipboard</source>
        <translation>Naar Klembord Kopiëren</translation>
    </message>
    <message>
        <source>Place the selected shapes on the clipboard</source>
        <translation>Geselecteerde vormen op het klembord plaatsen</translation>
    </message>
    <message>
        <source>Paste from Clipboard</source>
        <translation>Vanaf Klembord Plakken</translation>
    </message>
    <message>
        <source>Insert the clipboard shapes into this image</source>
        <translation>Vormen van het klembord in deze afbeelding invoegen</translation>
    </message>
    <message>
        <source>Click to place linestrip points; Ctrl+click places the last one.</source>
        <translation>Klik om punten van de lijnstrook te plaatsen; Ctrl+klik plaatst het laatste.</translation>
    </message>
    <message>
        <source>Fit to &amp;Window</source>
        <translation>Aanpassen aan &amp;venster</translation>
    </message>
    <message>
        <source>Keep the whole image visible when the window is resized</source>
        <translation>De hele afbeelding zichtbaar houden wanneer het venster van grootte verandert</translation>
    </message>
    <message>
        <source>Fit to Wi&amp;dth</source>
        <translation>Aanpassen aan &amp;breedte</translation>
    </message>
    <message>
        <source>Match the image width to the window when it is resized</source>
        <translation>De breedte van de afbeelding gelijk houden aan het venster wanneer het van grootte verandert</translation>
    </message>
    <message>
        <source>Make the image appear larger</source>
        <translation>De afbeelding groter weergeven</translation>
    </message>
    <message>
        <source>Make the image appear smaller</source>
        <translation>De afbeelding kleiner weergeven</translation>
    </message>
    <message>
        <source>&amp;Actual Size</source>
        <translation>&amp;Werkelijke grootte</translation>
    </message>
    <message>
        <source>Show the image at 100%</source>
        <translation>De afbeelding op 100% weergeven</translation>
    </message>
    <message>
        <source>Fill Drawing Polygon</source>
        <translation>Polygoon Vullen bij Tekenen</translation>
    </message>
    <message>
        <source>Fill polygon while drawing</source>
        <translation>Polygoon vullen tijdens tekenen</translation>
    </message>
    <message>
        <source>Ctrl+Wheel zooms the canvas</source>
        <translation>Ctrl+Wiel zoomt op het canvas</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Bestand</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Bewerken</translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation>&amp;Beeld</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Help</translation>
    </message>
    <message>
        <source>%s started.</source>
        <translation>%s gestart.</translation>
    </message>
    <message>
        <source>Mask Output Unavailable</source>
        <translation>Maskeruitvoer niet beschikbaar</translation>
    </message>
    <message>
        <source>%s only detects bounding boxes and cannot create &apos;%s&apos; annotations.

Switch the AI Text-to-Annotation model to &apos;SAM3 (smart)&apos;, or set the output format to &apos;Rectangle&apos;.</source>
        <translation>%s detecteert alleen selectiekaders en kan geen &apos;%s&apos;-annotaties maken.

Wijzig het AI Text-to-Annotation-model naar &apos;SAM3 (smart)&apos; of stel het uitvoerformaat in op &apos;Rectangle&apos;.</translation>
    </message>
    <message>
        <source>Invalid label</source>
        <translation>Ongeldig label</translation>
    </message>
    <message>
        <source>Invalid label &apos;{}&apos; with validation type &apos;{}&apos;</source>
        <translation>Ongeldig label &apos;{}&apos; met validatietype &apos;{}&apos;</translation>
    </message>
    <message>
        <source>Error saving label data</source>
        <translation>Fout bij opslaan van labelgegevens</translation>
    </message>
    <message>
        <source>&lt;b&gt;%s&lt;/b&gt;</source>
        <translation>&lt;b&gt;%s&lt;/b&gt;</translation>
    </message>
    <message>
        <source>AI inference failed: %s</source>
        <translation>AI-inferentie mislukt: %s</translation>
    </message>
    <message>
        <source>Error opening file</source>
        <translation>Fout bij openen van bestand</translation>
    </message>
    <message>
        <source>No such file: &lt;b&gt;%s&lt;/b&gt;</source>
        <translation>Bestand niet gevonden: &lt;b&gt;%s&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Loading %s...</source>
        <translation>Laden van %s...</translation>
    </message>
    <message>
        <source>Loaded %s</source>
        <translation>Geladen %s</translation>
    </message>
    <message>
        <source>Image &amp; Label files (%s)</source>
        <translation>Afbeelding- en labelbestanden (%s)</translation>
    </message>
    <message>
        <source>%s - Choose Image or Label file</source>
        <translation>%s - Kies Afbeelding- of labelbestand</translation>
    </message>
    <message>
        <source>%s - Save/Load Annotations in Directory</source>
        <translation>%s - Annotaties Opslaan/Laden in Map</translation>
    </message>
    <message>
        <source>%s . Annotations will be saved/loaded in %s</source>
        <translation>%s . Annotaties worden opgeslagen/geladen in %s</translation>
    </message>
    <message>
        <source>%s - Choose File</source>
        <translation>%s - Kies Bestand</translation>
    </message>
    <message>
        <source>Label files (*%s)</source>
        <translation>Labelbestanden (*%s)</translation>
    </message>
    <message>
        <source>Choose File</source>
        <translation>Kies Bestand</translation>
    </message>
    <message>
        <source>Attention</source>
        <translation>Let op</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Verwijderen</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annuleren</translation>
    </message>
    <message>
        <source>Unavailable in AI-Points mode because this model does not support point prompts.</source>
        <translation>Niet beschikbaar in de modus AI-Points, omdat dit model geen puntprompts ondersteunt.</translation>
    </message>
    <message>
        <source>Save annotations to &quot;{}&quot; before closing?</source>
        <translation>Annotaties opslaan naar &quot;{}&quot; voordat u sluit?</translation>
    </message>
    <message>
        <source>Save annotations?</source>
        <translation>Annotaties opslaan?</translation>
    </message>
    <message>
        <source>Delete {} shapes? You can restore them with Undo.</source>
        <translation>{} vormen verwijderen? U kunt ze herstellen met Ongedaan Maken.</translation>
    </message>
    <message>
        <source>%s - Open Directory</source>
        <translation>%s - Map Openen</translation>
    </message>
    <message>
        <source>The image is too large to open: {width}x{height} pixels exceeds the {max_side} pixel per-side limit of the raster engine. Raising the decode limit will not help. Split the image into tiles (for example with gdal_retile.py) or open a smaller copy.</source>
        <translation>De afbeelding is te groot om te openen: {width}x{height} pixels overschrijdt de limiet van {max_side} pixels per zijde van de raster-engine. Het verhogen van de decodeerlimiet helpt niet. Splits de afbeelding in tegels (bijvoorbeeld met gdal_retile.py) of open een kleinere kopie.</translation>
    </message>
    <message>
        <source>The image is too large to open: {width}x{height} pixels needs about {required} MB, but the decode limit is {limit} MB. Split the image into tiles (for example with gdal_retile.py) or open a smaller copy.</source>
        <translation>De afbeelding is te groot om te openen: {width}x{height} pixels heeft ongeveer {required} MB nodig, maar de decodeerlimiet is {limit} MB. Splits de afbeelding in tegels (bijvoorbeeld met gdal_retile.py) of open een kleinere kopie.</translation>
    </message>
    <message>
        <source>Toggle &quot;keep previous annotation&quot; mode</source>
        <translation>Modus &quot;vorige annotatie behouden&quot; omschakelen</translation>
    </message>
    <message>
        <source>Keep Previous Brightness/Contrast</source>
        <translation>Vorige Helderheid/Contrast Behouden</translation>
    </message>
    <message>
        <source>Configuration Errors</source>
        <translation>Configuratiefouten</translation>
    </message>
    <message>
        <source>Errors were found while loading the configuration. Please review the errors below and reload your configuration or ignore the erroneous lines.</source>
        <translation>Er zijn fouten gevonden bij het laden van de configuratie. Bekijk de onderstaande fouten en herlaad uw configuratie of negeer de foutieve regels.</translation>
    </message>
    <message>
        <source>Reset Layout</source>
        <translation>Layout herstellen</translation>
    </message>
    <message>
        <source>Polygon</source>
        <translation>Polygoon</translation>
    </message>
    <message>
        <source>Rectangle</source>
        <translation>Rechthoek</translation>
    </message>
    <message>
        <source>Circle</source>
        <translation>Cirkel</translation>
    </message>
    <message>
        <source>Line</source>
        <translation>Lijn</translation>
    </message>
    <message>
        <source>Point</source>
        <translation>Punt</translation>
    </message>
    <message>
        <source>LineStrip</source>
        <translation>Lijnstrip</translation>
    </message>
    <message>
        <source>AI-Points</source>
        <translation>AI-Points</translation>
    </message>
    <message>
        <source>Click points to segment object. Ctrl+LeftClick ends creation.</source>
        <translation>Klik op punten om object te segmenteren. Ctrl+LeftClick beëindigt het maken.</translation>
    </message>
    <message>
        <source>AI-Box</source>
        <translation>AI-Box</translation>
    </message>
    <message>
        <source>Draw a bounding box to segment object.</source>
        <translation>Teken een begrenzingskader om een object te segmenteren.</translation>
    </message>
    <message>
        <source>AI-Points Unavailable</source>
        <translation>AI-Points niet beschikbaar</translation>
    </message>
    <message>
        <source>%s does not support point prompts.
Please select a different model or use AI-Box mode.</source>
        <translation>%s ondersteunt geen puntinvoer.
Selecteer een ander model of gebruik de AI-Box-modus.</translation>
    </message>
    <message>
        <source>File list is disabled when a label file is opened</source>
        <translation>De bestandslijst is uitgeschakeld wanneer een labelbestand is geopend</translation>
    </message>
    <message>
        <source>Add Point to Edge</source>
        <translation>Punt aan rand toevoegen</translation>
    </message>
    <message>
        <source>Insert a new point at the hovered polygon edge</source>
        <translation>Nieuw punt invoegen op de aangewezen polygoonrand</translation>
    </message>
    <message>
        <source>&amp;Keep Previous Zoom</source>
        <translation>Vorige Zoom &amp;behouden</translation>
    </message>
    <message>
        <source>Permanently delete this label file? This action cannot be undone.</source>
        <translation>Dit labelbestand permanent verwijderen? Deze actie kan niet ongedaan worden gemaakt.</translation>
    </message>
    <message>
        <source>Allowed formats: {formats}</source>
        <translation>Toegestane formaten: {formats}</translation>
    </message>
    <message>
        <source>The selected label file could not be opened: {path}</source>
        <translation>Het geselecteerde labelbestand kon niet worden geopend: {path}</translation>
    </message>
    <message>
        <source>The selected image file could not be opened: {path}</source>
        <translation>Het geselecteerde afbeeldingsbestand kon niet worden geopend: {path}</translation>
    </message>
    <message>
        <source>Failed to load: {path}</source>
        <translation>Laden mislukt: {path}</translation>
    </message>
    <message>
        <source>Oriented Rectangle</source>
        <translation>Georiënteerde Rechthoek</translation>
    </message>
    <message>
        <source>Start drawing oriented rectangles</source>
        <translation>Begin met tekenen van georiënteerde rechthoeken</translation>
    </message>
    <message>
        <source>AI inference produced no new annotation.</source>
        <translation>AI-inferentie heeft geen nieuwe annotatie geproduceerd.</translation>
    </message>
    <message>
        <source>Shape had no area; nothing created.</source>
        <translation>Vorm heeft geen oppervlak; niets aangemaakt.</translation>
    </message>
    <message>
        <source>Settings…</source>
        <translation>Instellingen…</translation>
    </message>
    <message>
        <source>Edit settings</source>
        <translation>Instellingen bewerken</translation>
    </message>
    <message>
        <source>Settings are managed via --config for this session</source>
        <translation>Instellingen worden voor deze sessie beheerd via --config</translation>
    </message>
    <message>
        <source>Configuration Error</source>
        <translation>Configuratiefout</translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <source>Color theme</source>
        <translation>Kleurthema</translation>
    </message>
    <message>
        <source>System</source>
        <translation>Systeem</translation>
    </message>
    <message>
        <source>Light</source>
        <translation>Licht</translation>
    </message>
    <message>
        <source>Dark</source>
        <translation>Donker</translation>
    </message>
    <message>
        <source>Show label popup on new shape</source>
        <translation>Labeldialoog tonen bij nieuwe vorm</translation>
    </message>
    <message>
        <source>Show shape labels on canvas</source>
        <translation>Vormlabels op canvas tonen</translation>
    </message>
    <message>
        <source>Allow points outside the image boundary</source>
        <translation>Punten buiten de afbeeldingsgrens toestaan</translation>
    </message>
    <message>
        <source>Appearance and language</source>
        <translation>Uiterlijk en taal</translation>
    </message>
    <message>
        <source>Files and saving</source>
        <translation>Bestanden en opslaan</translation>
    </message>
    <message>
        <source>Drawing and canvas</source>
        <translation>Tekenen en canvas</translation>
    </message>
    <message>
        <source>Continue between images</source>
        <translation>Doorgaan tussen afbeeldingen</translation>
    </message>
    <message>
        <source>Label sources</source>
        <translation>Labelbronnen</translation>
    </message>
    <message>
        <source>Label behavior</source>
        <translation>Labelgedrag</translation>
    </message>
    <message>
        <source>AI assist</source>
        <translation>AI-assistent</translation>
    </message>
    <message>
        <source>Save automatically</source>
        <translation>Automatisch opslaan</translation>
    </message>
    <message>
        <source>Save image data in label file</source>
        <translation>Afbeeldingsgegevens opslaan in labelbestand</translation>
    </message>
    <message>
        <source>Embeds the image in the label JSON file.</source>
        <translation>Sluit de afbeelding in het JSON-labelbestand in.</translation>
    </message>
    <message>
        <source>Shape Color Mode</source>
        <translation>Vormkleurmodus</translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation>Automatisch</translation>
    </message>
    <message>
        <source>Uniform</source>
        <translation>Uniform</translation>
    </message>
    <message>
        <source>By Label</source>
        <translation>Per label</translation>
    </message>
    <message>
        <source>Automatic palette shift</source>
        <translation>Automatische paletverschuiving</translation>
    </message>
    <message>
        <source>Uniform mode color</source>
        <translation>Kleur voor modus Uniform</translation>
    </message>
    <message>
        <source>By Label fallback color</source>
        <translation>Terugvalkleur voor modus Per label</translation>
    </message>
    <message>
        <source>Individual Label colors remain editable in the Config File.</source>
        <translation>Afzonderlijke labelkleuren blijven bewerkbaar in het configuratiebestand.</translation>
    </message>
    <message>
        <source>Keep previous annotation</source>
        <translation>Vorige annotatie behouden</translation>
    </message>
    <message>
        <source>Keep previous zoom</source>
        <translation>Vorige zoom behouden</translation>
    </message>
    <message>
        <source>Keep previous brightness/contrast</source>
        <translation>Vorige helderheid/contrast behouden</translation>
    </message>
    <message>
        <source>Fill polygon while drawing</source>
        <translation>Polygoon vullen tijdens tekenen</translation>
    </message>
    <message>
        <source>Let shape points extend beyond the image, e.g. for partially visible objects.</source>
        <translation>Laat vormpunten buiten de afbeelding vallen, bijv. voor gedeeltelijk zichtbare objecten.</translation>
    </message>
    <message>
        <source>Polygon detail</source>
        <translation>Polygoondetail</translation>
    </message>
    <message>
        <source>Higher values preserve more Mask boundary detail and smaller lands.</source>
        <translation>Hogere waarden behouden meer details van de maskerrand en kleinere gebieden.</translation>
    </message>
    <message>
        <source>Predefined labels</source>
        <translation>Voorgedefinieerde labels</translation>
    </message>
    <message>
        <source>Label validation</source>
        <translation>Labelvalidatie</translation>
    </message>
    <message>
        <source>Sort labels</source>
        <translation>Labels sorteren</translation>
    </message>
    <message>
        <source>Sort the label list alphabetically instead of keeping the provided order.</source>
        <translation>Sorteert de labellijst alfabetisch in plaats van de opgegeven volgorde te behouden.</translation>
    </message>
    <message>
        <source>Show label text field</source>
        <translation>Labeltekstveld tonen</translation>
    </message>
    <message>
        <source>Label completion</source>
        <translation>Labelaanvulling</translation>
    </message>
    <message>
        <source>Starts with</source>
        <translation>Begint met</translation>
    </message>
    <message>
        <source>Contains</source>
        <translation>Bevat</translation>
    </message>
    <message>
        <source>Default model</source>
        <translation>Standaardmodel</translation>
    </message>
    <message>
        <source>EfficientSam (speed)</source>
        <translation>EfficientSam (snelheid)</translation>
    </message>
    <message>
        <source>EfficientSam (accuracy)</source>
        <translation>EfficientSam (nauwkeurigheid)</translation>
    </message>
    <message>
        <source>Sam (speed)</source>
        <translation>Sam (snelheid)</translation>
    </message>
    <message>
        <source>Sam (balanced)</source>
        <translation>Sam (gebalanceerd)</translation>
    </message>
    <message>
        <source>Sam (accuracy)</source>
        <translation>Sam (nauwkeurigheid)</translation>
    </message>
    <message>
        <source>Sam2 (speed)</source>
        <translation>Sam2 (snelheid)</translation>
    </message>
    <message>
        <source>Sam2 (balanced)</source>
        <translation>Sam2 (gebalanceerd)</translation>
    </message>
    <message>
        <source>Sam2 (accuracy)</source>
        <translation>Sam2 (nauwkeurigheid)</translation>
    </message>
    <message>
        <source>Sam3</source>
        <translation>Sam3</translation>
    </message>
    <message>
        <source>Suppress existing Shape matches</source>
        <translation>Overeenkomsten met bestaande vormen onderdrukken</translation>
    </message>
    <message>
        <source>When an AI Assist candidate matches an existing Shape, highlight that Shape instead of creating a new Shape.</source>
        <translation>Wanneer een kandidaat van de AI-assistent overeenkomt met een bestaande vorm, wordt die vorm gemarkeerd in plaats van een nieuwe vorm te maken.</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Instellingen</translation>
    </message>
    <message>
        <source>Open config file as text…</source>
        <translation>Configuratiebestand openen als tekst…</translation>
    </message>
    <message>
        <source>Edits made in the text file apply after restart</source>
        <translation>Wijzigingen in het tekstbestand worden na herstart toegepast</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Sluiten</translation>
    </message>
    <message>
        <source>BETA</source>
        <translation>BETA</translation>
    </message>
    <message>
        <source>(none)</source>
        <translation>(geen)</translation>
    </message>
    <message>
        <source>one item per line</source>
        <translation>één item per regel</translation>
    </message>
    <message>
        <source>Configuration Error</source>
        <translation>Configuratiefout</translation>
    </message>
    <message>
        <source>Predefined labels cannot be empty while Label validation is set to exact. Disable exact validation first.</source>
        <translation>Voorgedefinieerde labels mogen niet leeg zijn wanneer labelvalidatie is ingesteld op &apos;exact&apos;. Schakel eerst de &apos;exact&apos;-validatie uit.</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Taal</translation>
    </message>
    <message>
        <source>Takes effect after restart.</source>
        <translation>Van kracht na opnieuw opstarten.</translation>
    </message>
    <message>
        <source>System default</source>
        <translation>Systeemstandaard</translation>
    </message>
    <message>
        <source>Predefined image flags</source>
        <translation>Voorgedefinieerde afbeeldingsvlaggen</translation>
    </message>
</context>
<context>
    <name>_ColorSwatchButton</name>
    <message>
        <source>RGB: {red}, {green}, {blue}</source>
        <translation>RGB: {red}, {green}, {blue}</translation>
    </message>
</context>
<context>
    <name>_SettingsPage</name>
    <message>
        <source>Settings sections</source>
        <translation>Instellingssecties</translation>
    </message>
</context>
</TS>
