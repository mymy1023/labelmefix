<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ko_KR">
<context>
    <name>AiAssistedAnnotationWidget</name>
    <message>
        <source>AI-Assisted Annotation</source>
        <translation>AI 지원 주석</translation>
    </message>
    <message>
        <source>AI suggests annotation in &apos;AI-Points&apos; and &apos;AI-Box&apos; modes</source>
        <translation>AI가 &apos;AI-Points&apos; 및 &apos;AI-Box&apos; 모드에서 주석을 제안합니다</translation>
    </message>
    <message>
        <source>Polygon detail</source>
        <translation>폴리곤 세부 수준</translation>
    </message>
    <message>
        <source>Adjust polygon detail</source>
        <translation>폴리곤 세부 수준 조정</translation>
    </message>
    <message>
        <source>Smoother</source>
        <translation>더 부드럽게</translation>
    </message>
    <message>
        <source>More detail</source>
        <translation>더 자세하게</translation>
    </message>
    <message>
        <source>Select &apos;AI-Points&apos; or &apos;AI-Box&apos; mode to enable AI-Assisted Annotation</source>
        <translation>&apos;AI-Points&apos; 또는 &apos;AI-Box&apos; 모드를 선택하여 AI 지원 주석을 활성화</translation>
    </message>
</context>
<context>
    <name>AiTextToAnnotationWidget</name>
    <message>
        <source>AI Text-to-Annotation</source>
        <translation>AI 프롬프트</translation>
    </message>
    <message>
        <source>e.g., dog,cat,bird</source>
        <translation>예: 개, 고양이, 새</translation>
    </message>
    <message>
        <source>Run</source>
        <translation>실행</translation>
    </message>
    <message>
        <source>Score</source>
        <translation>점수</translation>
    </message>
    <message>
        <source>IoU</source>
        <translation>IoU</translation>
    </message>
    <message>
        <source>AI creates annotations from the text prompt</source>
        <translation>AI가 텍스트 프롬프트에서 주석을 생성합니다</translation>
    </message>
    <message>
        <source>Select &apos;Polygon&apos;, &apos;Rectangle&apos;, or &apos;AI-Points&apos; mode to enable</source>
        <translation>&apos;Polygon&apos;, &apos;Rectangle&apos; 또는 &apos;AI-Points&apos; 모드를 선택하여 활성화</translation>
    </message>
</context>
<context>
    <name>BrightnessContrastDialog</name>
    <message>
        <source>Brightness/Contrast</source>
        <translation>밝기/대비</translation>
    </message>
    <message>
        <source>Brightness:</source>
        <translation>밝기:</translation>
    </message>
    <message>
        <source>Contrast:</source>
        <translation>대비:</translation>
    </message>
</context>
<context>
    <name>Canvas</name>
    <message>
        <source>Click &amp; drag to move point</source>
        <translation>클릭하고 드래그하여 점 이동</translation>
    </message>
    <message>
        <source>Click &amp; drag to move shape</source>
        <translation>클릭하고 드래그하여 도형 이동</translation>
    </message>
    <message>
        <source>Creating %r</source>
        <translation>%r 생성 중</translation>
    </message>
    <message>
        <source>ESC to cancel</source>
        <translation>ESC 키를 눌러 취소</translation>
    </message>
    <message>
        <source>Enter or Space to finalize</source>
        <translation>Enter 또는 Space로 완료</translation>
    </message>
    <message>
        <source>Editing shapes</source>
        <translation>도형 편집 중</translation>
    </message>
    <message>
        <source>Click start point for line</source>
        <translation>선의 시작점 클릭</translation>
    </message>
    <message>
        <source>Click end point for line</source>
        <translation>선의 끝점 클릭</translation>
    </message>
    <message>
        <source>Click start point for linestrip</source>
        <translation>연속선의 시작점 클릭</translation>
    </message>
    <message>
        <source>Click next point or finish by Ctrl/Cmd+Click for linestrip</source>
        <translation>다음 점을 클릭하거나 Ctrl/Cmd+클릭으로 완료 (연속선)</translation>
    </message>
    <message>
        <source>Click center point for circle</source>
        <translation>원의 중심점 클릭</translation>
    </message>
    <message>
        <source>Click point on circumference for circle</source>
        <translation>원의 둘레 위 점 클릭</translation>
    </message>
    <message>
        <source>Click first corner for rectangle</source>
        <translation>사각형의 첫 번째 모서리 클릭</translation>
    </message>
    <message>
        <source>Click to add point</source>
        <translation>점 추가를 위해 클릭</translation>
    </message>
    <message>
        <source>ALT + SHIFT + Click to delete point</source>
        <translation>ALT + SHIFT + 클릭으로 점 삭제</translation>
    </message>
    <message>
        <source>ALT + Click to create point on shape</source>
        <translation>ALT + 클릭으로 도형 위에 점 생성</translation>
    </message>
    <message>
        <source>Right-click &amp; drag to copy shape</source>
        <translation>우클릭하고 드래그하여 도형 복사</translation>
    </message>
    <message>
        <source>Click opposite corner for rectangle (Shift for square)</source>
        <translation>사각형의 대각 모서리 클릭 (Shift로 정사각형)</translation>
    </message>
    <message>
        <source>Click points to include or Shift+Click to exclude. Ctrl+LeftClick ends creation.</source>
        <translation>클릭으로 포함할 점을, Shift+Click으로 제외할 점을 지정. Ctrl+LeftClick으로 생성 완료.</translation>
    </message>
    <message>
        <source>Click first corner of bbox for AI segmentation</source>
        <translation>AI 세그멘테이션을 위해 bbox의 첫 번째 모서리 클릭</translation>
    </message>
    <message>
        <source>Click opposite corner to segment object</source>
        <translation>대각 모서리를 클릭하여 객체를 세그먼트</translation>
    </message>
    <message>
        <source>Click first corner for oriented rectangle</source>
        <translation>방향 있는 사각형의 첫 번째 모서리 클릭</translation>
    </message>
    <message>
        <source>Click second corner to set orientation</source>
        <translation>두 번째 모서리를 클릭하여 방향 설정</translation>
    </message>
    <message>
        <source>Click third corner to close oriented rectangle</source>
        <translation>세 번째 모서리를 클릭하여 방향 있는 사각형 닫기</translation>
    </message>
    <message>
        <source>Click &amp; drag to rotate the shape</source>
        <translation>클릭하고 드래그하여 도형 회전</translation>
    </message>
</context>
<context>
    <name>EmptyStateWidget</name>
    <message>
        <source>Start annotating</source>
        <translation>주석 작업 시작</translation>
    </message>
    <message>
        <source>Open an image or a directory of images to begin.</source>
        <translation>시작하려면 이미지 또는 이미지 폴더를 여세요.</translation>
    </message>
    <message>
        <source>Open Image</source>
        <translation>이미지 열기</translation>
    </message>
    <message>
        <source>Open Directory</source>
        <translation>폴더 열기</translation>
    </message>
    <message>
        <source>Or drag and drop image files here</source>
        <translation>또는 이미지 파일을 여기로 끌어다 놓으세요</translation>
    </message>
</context>
<context>
    <name>LabelDialog</name>
    <message>
        <source>Shape Label</source>
        <translation>도형 레이블</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>레이블</translation>
    </message>
    <message>
        <source>Group ID</source>
        <translation>그룹 ID</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>설명</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Flags</source>
        <translation>플래그</translation>
    </message>
    <message>
        <source>Shape List</source>
        <translation>도형 목록</translation>
    </message>
    <message>
        <source>Select label to start annotating for it. Press &apos;Esc&apos; to deselect.</source>
        <translation>주석을 시작할 레이블을 선택하세요. &apos;Esc&apos;를 눌러 선택 해제합니다.</translation>
    </message>
    <message>
        <source>Label List</source>
        <translation>레이블 목록</translation>
    </message>
    <message>
        <source>Search Filename</source>
        <translation>파일명 검색</translation>
    </message>
    <message>
        <source>File List</source>
        <translation>파일 목록</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation>종료(&amp;Q)</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>애플리케이션 종료</translation>
    </message>
    <message>
        <source>&amp;Open
</source>
        <translation>열기(&amp;O)</translation>
    </message>
    <message>
        <source>Open image or label file</source>
        <translation>이미지 또는 레이블 파일 열기</translation>
    </message>
    <message>
        <source>Open Dir</source>
        <translation>폴더 열기</translation>
    </message>
    <message>
        <source>&amp;Next Image</source>
        <translation>다음 이미지(&amp;N)</translation>
    </message>
    <message>
        <source>Open next (hold Ctl+Shift to copy labels)</source>
        <translation>다음 열기 (Ctrl+Shift를 누르면 레이블 복사)</translation>
    </message>
    <message>
        <source>&amp;Prev Image</source>
        <translation>이전 이미지(&amp;P)</translation>
    </message>
    <message>
        <source>Open prev (hold Ctl+Shift to copy labels)</source>
        <translation>이전 열기 (Ctrl+Shift를 누르면 레이블 복사)</translation>
    </message>
    <message>
        <source>&amp;Save
</source>
        <translation>저장(&amp;S)</translation>
    </message>
    <message>
        <source>Save labels to file</source>
        <translation>레이블을 파일로 저장</translation>
    </message>
    <message>
        <source>&amp;Save As</source>
        <translation>다른 이름으로 저장(&amp;S)</translation>
    </message>
    <message>
        <source>&amp;Delete File</source>
        <translation>삭제(&amp;D)</translation>
    </message>
    <message>
        <source>Delete current label file</source>
        <translation>현재 레이블 파일 삭제</translation>
    </message>
    <message>
        <source>&amp;Change Output Dir</source>
        <translation>출력 폴더 변경(&amp;C)</translation>
    </message>
    <message>
        <source>Change where annotations are loaded/saved</source>
        <translation>주석을 로드/저장할 위치 변경</translation>
    </message>
    <message>
        <source>Save &amp;Automatically</source>
        <translation>자동 저장(&amp;A)</translation>
    </message>
    <message>
        <source>Save automatically</source>
        <translation>자동 저장</translation>
    </message>
    <message>
        <source>Save With Image Data</source>
        <translation>이미지 데이터와 함께 저장</translation>
    </message>
    <message>
        <source>Save image data in label file</source>
        <translation>레이블 파일에 이미지 데이터 저장</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>닫기(&amp;C)</translation>
    </message>
    <message>
        <source>Close current file</source>
        <translation>현재 파일 닫기</translation>
    </message>
    <message>
        <source>Keep Previous Annotation</source>
        <translation>이전 주석 유지</translation>
    </message>
    <message>
        <source>Start drawing polygons</source>
        <translation>다각형 그리기 시작</translation>
    </message>
    <message>
        <source>Start drawing rectangles</source>
        <translation>사각형 그리기 시작</translation>
    </message>
    <message>
        <source>Start drawing circles</source>
        <translation>원 그리기 시작</translation>
    </message>
    <message>
        <source>Start drawing lines</source>
        <translation>선 그리기 시작</translation>
    </message>
    <message>
        <source>Start drawing points</source>
        <translation>점 그리기 시작</translation>
    </message>
    <message>
        <source>Edit Shapes</source>
        <translation>도형 편집</translation>
    </message>
    <message>
        <source>Move and edit the selected shapes</source>
        <translation>선택한 도형 이동 및 편집</translation>
    </message>
    <message>
        <source>Delete Shapes</source>
        <translation>도형 삭제</translation>
    </message>
    <message>
        <source>Delete the selected shapes</source>
        <translation>선택한 도형 삭제</translation>
    </message>
    <message>
        <source>Duplicate Shapes</source>
        <translation>도형 복제</translation>
    </message>
    <message>
        <source>Create a duplicate of the selected shapes</source>
        <translation>선택한 도형의 복사본 생성</translation>
    </message>
    <message>
        <source>Undo last point</source>
        <translation>마지막 점 실행 취소</translation>
    </message>
    <message>
        <source>Undo last drawn point</source>
        <translation>마지막으로 그린 점 실행 취소</translation>
    </message>
    <message>
        <source>Remove Selected Point</source>
        <translation>선택한 점 제거</translation>
    </message>
    <message>
        <source>Remove selected point from polygon</source>
        <translation>다각형에서 선택한 점 제거</translation>
    </message>
    <message>
        <source>Undo
</source>
        <translation>실행 취소</translation>
    </message>
    <message>
        <source>Undo last add and edit of shape</source>
        <translation>도형의 마지막 추가 및 편집 실행 취소</translation>
    </message>
    <message>
        <source>&amp;Hide
Shapes</source>
        <translation>도형 숨기기(&amp;H)</translation>
    </message>
    <message>
        <source>Hide all shapes</source>
        <translation>모든 도형 숨기기</translation>
    </message>
    <message>
        <source>&amp;Show
Shapes</source>
        <translation>도형 표시(&amp;S)</translation>
    </message>
    <message>
        <source>Show all shapes</source>
        <translation>모든 도형 표시</translation>
    </message>
    <message>
        <source>&amp;Toggle
Shapes</source>
        <translation>도형 토글(&amp;S)</translation>
    </message>
    <message>
        <source>Toggle all shapes</source>
        <translation>모든 도형 토글</translation>
    </message>
    <message>
        <source>&amp;Tutorial</source>
        <translation>튜토리얼(&amp;T)</translation>
    </message>
    <message>
        <source>Show tutorial page</source>
        <translation>튜토리얼 페이지 표시</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation>확대/축소</translation>
    </message>
    <message>
        <source>Zoom &amp;In</source>
        <translation>확대(&amp;I)</translation>
    </message>
    <message>
        <source>&amp;Zoom Out</source>
        <translation>축소(&amp;Z)</translation>
    </message>
    <message>
        <source>&amp;Brightness Contrast</source>
        <translation>밝기 대비(&amp;B)</translation>
    </message>
    <message>
        <source>Adjust brightness and contrast</source>
        <translation>밝기 및 대비 조정</translation>
    </message>
    <message>
        <source>&amp;Edit Label</source>
        <translation>레이블 편집(&amp;E)</translation>
    </message>
    <message>
        <source>Save the labels under a new file name</source>
        <translation>레이블을 새 파일 이름으로 저장</translation>
    </message>
    <message>
        <source>Modify the label of the selected shape</source>
        <translation>선택한 도형의 레이블 수정</translation>
    </message>
    <message>
        <source>Copy to Clipboard</source>
        <translation>클립보드에 복사</translation>
    </message>
    <message>
        <source>Place the selected shapes on the clipboard</source>
        <translation>선택한 도형을 클립보드에 담기</translation>
    </message>
    <message>
        <source>Paste from Clipboard</source>
        <translation>클립보드에서 붙여넣기</translation>
    </message>
    <message>
        <source>Insert the clipboard shapes into this image</source>
        <translation>클립보드의 도형을 이 이미지에 삽입</translation>
    </message>
    <message>
        <source>Click to place linestrip points; Ctrl+click places the last one.</source>
        <translation>클릭하여 연속선의 점을 놓고, Ctrl+클릭으로 마지막 점을 놓습니다.</translation>
    </message>
    <message>
        <source>Fit to &amp;Window</source>
        <translation>창에 맞추기(&amp;W)</translation>
    </message>
    <message>
        <source>Keep the whole image visible when the window is resized</source>
        <translation>창 크기가 바뀌어도 이미지 전체가 보이도록 유지</translation>
    </message>
    <message>
        <source>Fit to Wi&amp;dth</source>
        <translation>너비에 맞추기(&amp;D)</translation>
    </message>
    <message>
        <source>Match the image width to the window when it is resized</source>
        <translation>창 크기가 바뀔 때 이미지 너비를 창에 맞춤</translation>
    </message>
    <message>
        <source>Make the image appear larger</source>
        <translation>이미지를 더 크게 표시</translation>
    </message>
    <message>
        <source>Make the image appear smaller</source>
        <translation>이미지를 더 작게 표시</translation>
    </message>
    <message>
        <source>&amp;Actual Size</source>
        <translation>실제 크기(&amp;A)</translation>
    </message>
    <message>
        <source>Show the image at 100%</source>
        <translation>이미지를 100%로 표시</translation>
    </message>
    <message>
        <source>Fill Drawing Polygon</source>
        <translation>그리기 다각형 채우기</translation>
    </message>
    <message>
        <source>Fill polygon while drawing</source>
        <translation>그리는 동안 다각형 채우기</translation>
    </message>
    <message>
        <source>Ctrl+Wheel zooms the canvas</source>
        <translation>Ctrl+휠로 캔버스를 확대/축소합니다</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>파일(&amp;F)</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>편집(&amp;E)</translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation>보기(&amp;V)</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>도움말(&amp;H)</translation>
    </message>
    <message>
        <source>%s started.</source>
        <translation>%s가 시작되었습니다.</translation>
    </message>
    <message>
        <source>Mask Output Unavailable</source>
        <translation>마스크 출력을 사용할 수 없음</translation>
    </message>
    <message>
        <source>%s only detects bounding boxes and cannot create &apos;%s&apos; annotations.

Switch the AI Text-to-Annotation model to &apos;SAM3 (smart)&apos;, or set the output format to &apos;Rectangle&apos;.</source>
        <translation>%s은(는) 경계 상자만 감지하므로 &apos;%s&apos; 주석을 생성할 수 없습니다.

AI Text-to-Annotation 모델을 &apos;SAM3 (smart)&apos;(으)로 변경하거나 출력 형식을 &apos;Rectangle&apos;(으)로 설정하세요.</translation>
    </message>
    <message>
        <source>Invalid label</source>
        <translation>잘못된 레이블</translation>
    </message>
    <message>
        <source>Invalid label &apos;{}&apos; with validation type &apos;{}&apos;</source>
        <translation>검증 유형 &apos;{}&apos;에 대한 잘못된 레이블 &apos;{}&apos;</translation>
    </message>
    <message>
        <source>Error saving label data</source>
        <translation>레이블 데이터 저장 오류</translation>
    </message>
    <message>
        <source>&lt;b&gt;%s&lt;/b&gt;</source>
        <translation>&lt;b&gt;%s&lt;/b&gt;</translation>
    </message>
    <message>
        <source>AI inference failed: %s</source>
        <translation>AI 추론 실패: %s</translation>
    </message>
    <message>
        <source>Error opening file</source>
        <translation>파일 열기 오류</translation>
    </message>
    <message>
        <source>No such file: &lt;b&gt;%s&lt;/b&gt;</source>
        <translation>파일이 없습니다: &lt;b&gt;%s&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Loading %s...</source>
        <translation>%s 로드 중...</translation>
    </message>
    <message>
        <source>Loaded %s</source>
        <translation>%s 로드됨</translation>
    </message>
    <message>
        <source>Image &amp; Label files (%s)</source>
        <translation>이미지 및 레이블 파일 (%s)</translation>
    </message>
    <message>
        <source>%s - Choose Image or Label file</source>
        <translation>%s - 이미지 또는 레이블 파일 선택</translation>
    </message>
    <message>
        <source>%s - Save/Load Annotations in Directory</source>
        <translation>%s - 폴더에 주석 저장/로드</translation>
    </message>
    <message>
        <source>%s . Annotations will be saved/loaded in %s</source>
        <translation>%s . 주석이 %s에 저장/로드됩니다</translation>
    </message>
    <message>
        <source>%s - Choose File</source>
        <translation>%s - 파일 선택</translation>
    </message>
    <message>
        <source>Label files (*%s)</source>
        <translation>레이블 파일 (*%s)</translation>
    </message>
    <message>
        <source>Choose File</source>
        <translation>파일 선택</translation>
    </message>
    <message>
        <source>Attention</source>
        <translation>주의</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>삭제</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>취소</translation>
    </message>
    <message>
        <source>Unavailable in AI-Points mode because this model does not support point prompts.</source>
        <translation>이 모델은 포인트 프롬프트를 지원하지 않으므로 AI-Points 모드에서는 사용할 수 없습니다.</translation>
    </message>
    <message>
        <source>Save annotations to &quot;{}&quot; before closing?</source>
        <translation>닫기 전에 주석을 &quot;{}&quot;에 저장하시겠습니까?</translation>
    </message>
    <message>
        <source>Save annotations?</source>
        <translation>주석을 저장하시겠습니까?</translation>
    </message>
    <message>
        <source>Delete {} shapes? You can restore them with Undo.</source>
        <translation>{}개의 도형을 삭제하시겠습니까? 실행 취소로 복원할 수 있습니다.</translation>
    </message>
    <message>
        <source>%s - Open Directory</source>
        <translation>%s - 폴더 열기</translation>
    </message>
    <message>
        <source>The image is too large to open: {width}x{height} pixels exceeds the {max_side} pixel per-side limit of the raster engine. Raising the decode limit will not help. Split the image into tiles (for example with gdal_retile.py) or open a smaller copy.</source>
        <translation>이미지가 너무 커서 열 수 없습니다: {width}x{height} 픽셀은 래스터 엔진의 한 변당 {max_side} 픽셀 제한을 초과합니다. 디코드 제한을 늘려도 해결되지 않습니다. 이미지를 타일로 분할하거나(예: gdal_retile.py) 더 작은 사본을 여세요.</translation>
    </message>
    <message>
        <source>The image is too large to open: {width}x{height} pixels needs about {required} MB, but the decode limit is {limit} MB. Split the image into tiles (for example with gdal_retile.py) or open a smaller copy.</source>
        <translation>이미지가 너무 커서 열 수 없습니다: {width}x{height} 픽셀에는 약 {required} MB가 필요하지만 디코드 제한은 {limit} MB입니다. 이미지를 타일로 분할하거나(예: gdal_retile.py) 더 작은 사본을 여세요.</translation>
    </message>
    <message>
        <source>Toggle &quot;keep previous annotation&quot; mode</source>
        <translation>&quot;이전 주석 유지&quot; 모드 토글</translation>
    </message>
    <message>
        <source>Keep Previous Brightness/Contrast</source>
        <translation>이전 밝기/대비 유지</translation>
    </message>
    <message>
        <source>Configuration Errors</source>
        <translation>구성 오류</translation>
    </message>
    <message>
        <source>Errors were found while loading the configuration. Please review the errors below and reload your configuration or ignore the erroneous lines.</source>
        <translation>구성을 불러오는 중 오류가 발견되었습니다. 아래 오류를 검토하고 구성을 다시 불러오거나 잘못된 줄을 무시하세요.</translation>
    </message>
    <message>
        <source>Reset Layout</source>
        <translation>레이아웃 초기화</translation>
    </message>
    <message>
        <source>Polygon</source>
        <translation>다각형</translation>
    </message>
    <message>
        <source>Rectangle</source>
        <translation>사각형</translation>
    </message>
    <message>
        <source>Circle</source>
        <translation>원</translation>
    </message>
    <message>
        <source>Line</source>
        <translation>선</translation>
    </message>
    <message>
        <source>Point</source>
        <translation>점</translation>
    </message>
    <message>
        <source>LineStrip</source>
        <translation>연결선</translation>
    </message>
    <message>
        <source>AI-Points</source>
        <translation>AI-Points</translation>
    </message>
    <message>
        <source>Click points to segment object. Ctrl+LeftClick ends creation.</source>
        <translation>클릭으로 객체를 세그먼트. Ctrl+LeftClick으로 생성 완료.</translation>
    </message>
    <message>
        <source>AI-Box</source>
        <translation>AI-Box</translation>
    </message>
    <message>
        <source>Draw a bounding box to segment object.</source>
        <translation>바운딩 박스를 그려서 객체를 세그먼트.</translation>
    </message>
    <message>
        <source>AI-Points Unavailable</source>
        <translation>AI-Points 사용 불가</translation>
    </message>
    <message>
        <source>%s does not support point prompts.
Please select a different model or use AI-Box mode.</source>
        <translation>%s은(는) 포인트 프롬프트를 지원하지 않습니다.
다른 모델을 선택하거나 AI-Box 모드를 사용하세요.</translation>
    </message>
    <message>
        <source>File list is disabled when a label file is opened</source>
        <translation>라벨 파일이 열려 있을 때 파일 목록이 비활성화됩니다</translation>
    </message>
    <message>
        <source>Add Point to Edge</source>
        <translation>모서리에 점 추가</translation>
    </message>
    <message>
        <source>Insert a new point at the hovered polygon edge</source>
        <translation>마우스가 가리키는 다각형 모서리에 새 점 삽입</translation>
    </message>
    <message>
        <source>&amp;Keep Previous Zoom</source>
        <translation>이전 줌 유지(&amp;K)</translation>
    </message>
    <message>
        <source>Permanently delete this label file? This action cannot be undone.</source>
        <translation>이 레이블 파일을 영구적으로 삭제하시겠습니까? 이 작업은 되돌릴 수 없습니다.</translation>
    </message>
    <message>
        <source>Allowed formats: {formats}</source>
        <translation>지원 형식: {formats}</translation>
    </message>
    <message>
        <source>The selected label file could not be opened: {path}</source>
        <translation>선택한 레이블 파일을 열 수 없습니다: {path}</translation>
    </message>
    <message>
        <source>The selected image file could not be opened: {path}</source>
        <translation>선택한 이미지 파일을 열 수 없습니다: {path}</translation>
    </message>
    <message>
        <source>Failed to load: {path}</source>
        <translation>불러오기 실패: {path}</translation>
    </message>
    <message>
        <source>Oriented Rectangle</source>
        <translation>방향 있는 사각형</translation>
    </message>
    <message>
        <source>Start drawing oriented rectangles</source>
        <translation>방향 있는 사각형 그리기 시작</translation>
    </message>
    <message>
        <source>AI inference produced no new annotation.</source>
        <translation>AI 추론에서 새 주석이 생성되지 않았습니다.</translation>
    </message>
    <message>
        <source>Shape had no area; nothing created.</source>
        <translation>도형에 면적이 없어 생성되지 않았습니다.</translation>
    </message>
    <message>
        <source>Settings…</source>
        <translation>설정…</translation>
    </message>
    <message>
        <source>Edit settings</source>
        <translation>설정 편집</translation>
    </message>
    <message>
        <source>Settings are managed via --config for this session</source>
        <translation>이 세션의 설정은 --config로 관리됩니다</translation>
    </message>
    <message>
        <source>Configuration Error</source>
        <translation>구성 오류</translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <source>Color theme</source>
        <translation>색상 테마</translation>
    </message>
    <message>
        <source>System</source>
        <translation>시스템</translation>
    </message>
    <message>
        <source>Light</source>
        <translation>라이트</translation>
    </message>
    <message>
        <source>Dark</source>
        <translation>다크</translation>
    </message>
    <message>
        <source>Show label popup on new shape</source>
        <translation>새 도형에서 레이블 팝업 표시</translation>
    </message>
    <message>
        <source>Show shape labels on canvas</source>
        <translation>캔버스에 도형 레이블 표시</translation>
    </message>
    <message>
        <source>Allow points outside the image boundary</source>
        <translation>이미지 경계 밖의 점 허용</translation>
    </message>
    <message>
        <source>Appearance and language</source>
        <translation>모양 및 언어</translation>
    </message>
    <message>
        <source>Files and saving</source>
        <translation>파일 및 저장</translation>
    </message>
    <message>
        <source>Drawing and canvas</source>
        <translation>그리기 및 캔버스</translation>
    </message>
    <message>
        <source>Continue between images</source>
        <translation>이미지 간 이어서 작업</translation>
    </message>
    <message>
        <source>Label sources</source>
        <translation>레이블 소스</translation>
    </message>
    <message>
        <source>Label behavior</source>
        <translation>레이블 동작</translation>
    </message>
    <message>
        <source>AI assist</source>
        <translation>AI 지원</translation>
    </message>
    <message>
        <source>Save automatically</source>
        <translation>자동 저장</translation>
    </message>
    <message>
        <source>Save image data in label file</source>
        <translation>레이블 파일에 이미지 데이터 저장</translation>
    </message>
    <message>
        <source>Embeds the image in the label JSON file.</source>
        <translation>이미지를 레이블 JSON 파일에 포함합니다.</translation>
    </message>
    <message>
        <source>Shape Color Mode</source>
        <translation>도형 색상 모드</translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation>자동</translation>
    </message>
    <message>
        <source>Uniform</source>
        <translation>균일</translation>
    </message>
    <message>
        <source>By Label</source>
        <translation>레이블별</translation>
    </message>
    <message>
        <source>Automatic palette shift</source>
        <translation>자동 팔레트 이동</translation>
    </message>
    <message>
        <source>Uniform mode color</source>
        <translation>균일 모드 색상</translation>
    </message>
    <message>
        <source>By Label fallback color</source>
        <translation>레이블별 모드 대체 색상</translation>
    </message>
    <message>
        <source>Individual Label colors remain editable in the Config File.</source>
        <translation>개별 레이블 색상은 구성 파일에서 계속 편집할 수 있습니다.</translation>
    </message>
    <message>
        <source>Keep previous annotation</source>
        <translation>이전 주석 유지</translation>
    </message>
    <message>
        <source>Keep previous zoom</source>
        <translation>이전 확대/축소 유지</translation>
    </message>
    <message>
        <source>Keep previous brightness/contrast</source>
        <translation>이전 밝기/대비 유지</translation>
    </message>
    <message>
        <source>Fill polygon while drawing</source>
        <translation>그리는 동안 다각형 채우기</translation>
    </message>
    <message>
        <source>Let shape points extend beyond the image, e.g. for partially visible objects.</source>
        <translation>도형의 점이 이미지 밖으로 확장되도록 허용합니다. 예: 부분적으로 보이는 객체.</translation>
    </message>
    <message>
        <source>Polygon detail</source>
        <translation>폴리곤 세부 수준</translation>
    </message>
    <message>
        <source>Higher values preserve more Mask boundary detail and smaller lands.</source>
        <translation>값이 높을수록 마스크 경계의 세부 정보와 작은 영역이 더 많이 유지됩니다.</translation>
    </message>
    <message>
        <source>Predefined labels</source>
        <translation>사전 정의된 레이블</translation>
    </message>
    <message>
        <source>Label validation</source>
        <translation>레이블 검증</translation>
    </message>
    <message>
        <source>Sort labels</source>
        <translation>레이블 정렬</translation>
    </message>
    <message>
        <source>Sort the label list alphabetically instead of keeping the provided order.</source>
        <translation>제공된 순서를 유지하는 대신 레이블 목록을 알파벳순으로 정렬합니다.</translation>
    </message>
    <message>
        <source>Show label text field</source>
        <translation>레이블 텍스트 필드 표시</translation>
    </message>
    <message>
        <source>Label completion</source>
        <translation>레이블 자동 완성</translation>
    </message>
    <message>
        <source>Starts with</source>
        <translation>다음으로 시작</translation>
    </message>
    <message>
        <source>Contains</source>
        <translation>포함</translation>
    </message>
    <message>
        <source>Default model</source>
        <translation>기본 모델</translation>
    </message>
    <message>
        <source>EfficientSam (speed)</source>
        <translation>EfficientSam (속도)</translation>
    </message>
    <message>
        <source>EfficientSam (accuracy)</source>
        <translation>EfficientSam (정확도)</translation>
    </message>
    <message>
        <source>Sam (speed)</source>
        <translation>Sam (속도)</translation>
    </message>
    <message>
        <source>Sam (balanced)</source>
        <translation>Sam (균형)</translation>
    </message>
    <message>
        <source>Sam (accuracy)</source>
        <translation>Sam (정확도)</translation>
    </message>
    <message>
        <source>Sam2 (speed)</source>
        <translation>Sam2 (속도)</translation>
    </message>
    <message>
        <source>Sam2 (balanced)</source>
        <translation>Sam2 (균형)</translation>
    </message>
    <message>
        <source>Sam2 (accuracy)</source>
        <translation>Sam2 (정확도)</translation>
    </message>
    <message>
        <source>Sam3</source>
        <translation>Sam3</translation>
    </message>
    <message>
        <source>Suppress existing Shape matches</source>
        <translation>기존 도형과 일치하는 항목 억제</translation>
    </message>
    <message>
        <source>When an AI Assist candidate matches an existing Shape, highlight that Shape instead of creating a new Shape.</source>
        <translation>AI 지원 후보가 기존 도형과 일치하면 새 도형을 만드는 대신 해당 도형을 강조 표시합니다.</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>설정</translation>
    </message>
    <message>
        <source>Open config file as text…</source>
        <translation>텍스트로 구성 파일 열기…</translation>
    </message>
    <message>
        <source>Edits made in the text file apply after restart</source>
        <translation>텍스트 파일에서 편집한 내용은 재시작 후 적용됩니다</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>닫기</translation>
    </message>
    <message>
        <source>BETA</source>
        <translation>BETA</translation>
    </message>
    <message>
        <source>(none)</source>
        <translation>(없음)</translation>
    </message>
    <message>
        <source>one item per line</source>
        <translation>한 줄에 하나씩 입력</translation>
    </message>
    <message>
        <source>Configuration Error</source>
        <translation>구성 오류</translation>
    </message>
    <message>
        <source>Predefined labels cannot be empty while Label validation is set to exact. Disable exact validation first.</source>
        <translation>레이블 검증이 &apos;exact&apos;로 설정된 동안에는 사전 정의된 레이블을 비울 수 없습니다. 먼저 &apos;exact&apos; 검증을 비활성화하세요.</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>언어</translation>
    </message>
    <message>
        <source>Takes effect after restart.</source>
        <translation>재시작 후 적용됩니다.</translation>
    </message>
    <message>
        <source>System default</source>
        <translation>시스템 기본값</translation>
    </message>
    <message>
        <source>Predefined image flags</source>
        <translation>사전 정의된 이미지 플래그</translation>
    </message>
</context>
<context>
    <name>_ColorSwatchButton</name>
    <message>
        <source>RGB: {red}, {green}, {blue}</source>
        <translation>RGB: {red}, {green}, {blue}</translation>
    </message>
</context>
<context>
    <name>_SettingsPage</name>
    <message>
        <source>Settings sections</source>
        <translation>설정 섹션</translation>
    </message>
</context>
</TS>
