<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="el_GR">
<context>
    <name>AiAssistedAnnotationWidget</name>
    <message>
        <source>AI-Assisted Annotation</source>
        <translation>Σχολιασμός υποβοηθούμενος από τεχνητή νοημοσύνη</translation>
    </message>
    <message>
        <source>AI suggests annotation in &apos;AI-Points&apos; and &apos;AI-Box&apos; modes</source>
        <translation>Το AI προτείνει σχολιασμό στις λειτουργίες &apos;AI-Points&apos; και &apos;AI-Box&apos;</translation>
    </message>
    <message>
        <source>Polygon detail</source>
        <translation>Λεπτομέρεια πολυγώνου</translation>
    </message>
    <message>
        <source>Adjust polygon detail</source>
        <translation>Προσαρμογή λεπτομέρειας πολυγώνου</translation>
    </message>
    <message>
        <source>Smoother</source>
        <translation>Πιο ομαλό</translation>
    </message>
    <message>
        <source>More detail</source>
        <translation>Περισσότερη λεπτομέρεια</translation>
    </message>
    <message>
        <source>Select &apos;AI-Points&apos; or &apos;AI-Box&apos; mode to enable AI-Assisted Annotation</source>
        <translation>Επιλέξτε τη λειτουργία &apos;AI-Points&apos; ή &apos;AI-Box&apos; για να ενεργοποιήσετε τον σχολιασμό υποβοηθούμενο από AI</translation>
    </message>
</context>
<context>
    <name>AiTextToAnnotationWidget</name>
    <message>
        <source>AI Text-to-Annotation</source>
        <translation>AI Text-to-Annotation</translation>
    </message>
    <message>
        <source>AI creates annotations from the text prompt</source>
        <translation>Η τεχνητή νοημοσύνη δημιουργεί σχολιασμούς από την προτροπή κειμένου</translation>
    </message>
    <message>
        <source>e.g., dog,cat,bird</source>
        <translation>π.χ. σκύλος,γάτα,πουλί</translation>
    </message>
    <message>
        <source>Run</source>
        <translation>Εκτέλεση</translation>
    </message>
    <message>
        <source>Score</source>
        <translation>Βαθμολογία</translation>
    </message>
    <message>
        <source>IoU</source>
        <translation>IoU</translation>
    </message>
    <message>
        <source>Select &apos;Polygon&apos;, &apos;Rectangle&apos;, or &apos;AI-Points&apos; mode to enable</source>
        <translation>Επιλέξτε τη λειτουργία &apos;Polygon&apos;, &apos;Rectangle&apos; ή &apos;AI-Points&apos; για ενεργοποίηση</translation>
    </message>
</context>
<context>
    <name>BrightnessContrastDialog</name>
    <message>
        <source>Brightness/Contrast</source>
        <translation>Φωτεινότητα/Αντίθεση</translation>
    </message>
    <message>
        <source>Brightness:</source>
        <translation>Φωτεινότητα:</translation>
    </message>
    <message>
        <source>Contrast:</source>
        <translation>Αντίθεση:</translation>
    </message>
</context>
<context>
    <name>Canvas</name>
    <message>
        <source>Creating %r</source>
        <translation>Δημιουργία %r</translation>
    </message>
    <message>
        <source>ESC to cancel</source>
        <translation>(Esc για ακύρωση)</translation>
    </message>
    <message>
        <source>Enter or Space to finalize</source>
        <translation>Είσοδος ή χώρος για οριστικοποίηση</translation>
    </message>
    <message>
        <source>Editing shapes</source>
        <translation>Επεξεργασία σχημάτων</translation>
    </message>
    <message>
        <source>Click start point for line</source>
        <translation>Κάντε κλικ στο σημείο έναρξης για τη γραμμή</translation>
    </message>
    <message>
        <source>Click end point for line</source>
        <translation>Κάντε κλικ στο τελικό σημείο για τη γραμμή</translation>
    </message>
    <message>
        <source>Click start point for linestrip</source>
        <translation>Κάντε κλικ στο σημείο έναρξης για το linestrip</translation>
    </message>
    <message>
        <source>Click next point or finish by Ctrl/Cmd+Click for linestrip</source>
        <translation>Κάντε κλικ στο επόμενο σημείο ή ολοκληρώστε μέχρι τις Ctrl/Cmd+Click για το linestrip</translation>
    </message>
    <message>
        <source>Click center point for circle</source>
        <translation>Κάντε κλικ στο κεντρικό σημείο για τον κύκλο</translation>
    </message>
    <message>
        <source>Click point on circumference for circle</source>
        <translation>Κάντε κλικ στο σημείο στην περιφέρεια για τον κύκλο</translation>
    </message>
    <message>
        <source>Click first corner for rectangle</source>
        <translation>Κάντε κλικ στην πρώτη γωνία για ορθογώνιο</translation>
    </message>
    <message>
        <source>Click opposite corner for rectangle (Shift for square)</source>
        <translation>Κάντε κλικ στην αντίθετη γωνία για ορθογώνιο (Shift για τετράγωνο)</translation>
    </message>
    <message>
        <source>Click to add point</source>
        <translation>Κάντε κλικ για να προσθέσετε πόντο</translation>
    </message>
    <message>
        <source>Click &amp; drag to move point</source>
        <translation>Πάτημα και μεταφορά για μετακίνηση αυτού του σημείου</translation>
    </message>
    <message>
        <source>ALT + SHIFT + Click to delete point</source>
        <translation>ALT + SHIFT + Κάντε κλικ για διαγραφή σημείου</translation>
    </message>
    <message>
        <source>ALT + Click to create point on shape</source>
        <translation>ALT + Κάντε κλικ για να δημιουργήσετε σημείο στο σχήμα</translation>
    </message>
    <message>
        <source>Click &amp; drag to move shape</source>
        <translation>Κάντε κλικ και σύρετε για να μετακινήσετε το σχήμα</translation>
    </message>
    <message>
        <source>Right-click &amp; drag to copy shape</source>
        <translation>Δεξί κλικ &amp; σύρσιμο για αντιγραφή σχήματος</translation>
    </message>
    <message>
        <source>Click points to include or Shift+Click to exclude. Ctrl+LeftClick ends creation.</source>
        <translation>Κάντε κλικ σε σημεία για συμπερίληψη ή Shift+Click για εξαίρεση. Ctrl+LeftClick ολοκληρώνει τη δημιουργία.</translation>
    </message>
    <message>
        <source>Click first corner of bbox for AI segmentation</source>
        <translation>Κάντε κλικ στην πρώτη γωνία του bbox για τμηματοποίηση AI</translation>
    </message>
    <message>
        <source>Click opposite corner to segment object</source>
        <translation>Κάντε κλικ στην απέναντι γωνία για τμηματοποίηση αντικειμένου</translation>
    </message>
    <message>
        <source>Click first corner for oriented rectangle</source>
        <translation>Κάντε κλικ στην πρώτη γωνία για προσανατολισμένο ορθογώνιο</translation>
    </message>
    <message>
        <source>Click second corner to set orientation</source>
        <translation>Κάντε κλικ στη δεύτερη γωνία για να ορίσετε τον προσανατολισμό</translation>
    </message>
    <message>
        <source>Click third corner to close oriented rectangle</source>
        <translation>Κάντε κλικ στην τρίτη γωνία για να κλείσετε το προσανατολισμένο ορθογώνιο</translation>
    </message>
    <message>
        <source>Click &amp; drag to rotate the shape</source>
        <translation>Κάντε κλικ και σύρετε για να περιστρέψετε το σχήμα</translation>
    </message>
</context>
<context>
    <name>EmptyStateWidget</name>
    <message>
        <source>Start annotating</source>
        <translation>Ξεκινήστε την επισήμανση</translation>
    </message>
    <message>
        <source>Open an image or a directory of images to begin.</source>
        <translation>Ανοίξτε μια εικόνα ή έναν φάκελο εικόνων για να ξεκινήσετε.</translation>
    </message>
    <message>
        <source>Open Image</source>
        <translation>Άνοιγμα εικόνας</translation>
    </message>
    <message>
        <source>Open Directory</source>
        <translation>Άνοιγμα φακέλου</translation>
    </message>
    <message>
        <source>Or drag and drop image files here</source>
        <translation>Ή σύρετε και αποθέστε αρχεία εικόνας εδώ</translation>
    </message>
</context>
<context>
    <name>LabelDialog</name>
    <message>
        <source>Shape Label</source>
        <translation>Ετικέτα σχήματος</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Ετικέτα</translation>
    </message>
    <message>
        <source>Group ID</source>
        <translation>Αναγνωριστικό ομάδας</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Περιγραφή</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>&amp;Save
</source>
        <translation>Αποθήκευση</translation>
    </message>
    <message>
        <source>Save labels to file</source>
        <translation>Αποθήκευση ετικετών σε αρχείο</translation>
    </message>
    <message>
        <source>&amp;Save As</source>
        <translation>Αποθήκευση &amp;Ως</translation>
    </message>
    <message>
        <source>Save &amp;Automatically</source>
        <translation>Αποθήκευση &amp;αυτόματα</translation>
    </message>
    <message>
        <source>Save automatically</source>
        <translation>Αυτόματη αποθήκευση</translation>
    </message>
    <message>
        <source>Save With Image Data</source>
        <translation>Αποθήκευση με δεδομένα εικόνας</translation>
    </message>
    <message>
        <source>Save image data in label file</source>
        <translation>Αποθήκευση δεδομένων εικόνας σε αρχείο ετικέτας</translation>
    </message>
    <message>
        <source>&amp;Change Output Dir</source>
        <translation>&amp;Αλλαγή Οδηγίας Εξόδου</translation>
    </message>
    <message>
        <source>Change where annotations are loaded/saved</source>
        <translation>Αλλαγή του πού φορτώνονται/αποθηκεύονται οι σχολιασμοί</translation>
    </message>
    <message>
        <source>&amp;Open
</source>
        <translation>Ανοιγμα</translation>
    </message>
    <message>
        <source>Open image or label file</source>
        <translation>Άνοιγμα αρχείου εικόνας ή ετικέτας</translation>
    </message>
    <message>
        <source>Open Dir</source>
        <translation>Άνοιγμα Dir</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>Κλείσιμο</translation>
    </message>
    <message>
        <source>Close current file</source>
        <translation>Κλείσιμο τρέχοντος αρχείου</translation>
    </message>
    <message>
        <source>&amp;Delete File</source>
        <translation>&amp; Διαγραφή αρχείου</translation>
    </message>
    <message>
        <source>Delete current label file</source>
        <translation>Διαγραφή τρέχοντος αρχείου ετικέτας</translation>
    </message>
    <message>
        <source>Keep Previous Annotation</source>
        <translation>Διατήρηση προηγούμενου σχολιασμού</translation>
    </message>
    <message>
        <source>Toggle &quot;keep previous annotation&quot; mode</source>
        <translation>Εναλλαγή λειτουργίας &quot;Διατήρηση προηγούμενου σχολιασμού&quot;</translation>
    </message>
    <message>
        <source>Keep Previous Brightness/Contrast</source>
        <translation>Διατήρηση προηγούμενης φωτεινότητας/αντίθεσης</translation>
    </message>
    <message>
        <source>Delete Shapes</source>
        <translation>Διαγραφή σχημάτων</translation>
    </message>
    <message>
        <source>Delete the selected shapes</source>
        <translation>Διαγραφή των επιλεγμένων σχημάτων</translation>
    </message>
    <message>
        <source>&amp;Edit Label</source>
        <translation>Επεξεργασία ετικέτας</translation>
    </message>
    <message>
        <source>Modify the label of the selected shape</source>
        <translation>Τροποποιήστε την ετικέτα του επιλεγμένου σχήματος</translation>
    </message>
    <message>
        <source>Copy to Clipboard</source>
        <translation>Αντιγραφή στο πρόχειρο</translation>
    </message>
    <message>
        <source>Place the selected shapes on the clipboard</source>
        <translation>Τοποθέτηση των επιλεγμένων σχημάτων στο πρόχειρο</translation>
    </message>
    <message>
        <source>Paste from Clipboard</source>
        <translation>Επικόλληση από το πρόχειρο</translation>
    </message>
    <message>
        <source>Duplicate Shapes</source>
        <translation>Διπλότυπα σχήματα</translation>
    </message>
    <message>
        <source>Create a duplicate of the selected shapes</source>
        <translation>Δημιουργήστε ένα αντίγραφο των επιλεγμένων σχημάτων</translation>
    </message>
    <message>
        <source>Undo last point</source>
        <translation>Τελευταίο σημείο</translation>
    </message>
    <message>
        <source>Undo last drawn point</source>
        <translation>Αναίρεση τελευταίου σημείου έλξης</translation>
    </message>
    <message>
        <source>Undo
</source>
        <translation>Αναίρεση</translation>
    </message>
    <message>
        <source>Undo last add and edit of shape</source>
        <translation>Αναίρεση τελευταίας προσθήκης και επεξεργασίας σχήματος</translation>
    </message>
    <message>
        <source>Remove Selected Point</source>
        <translation>Κατάργηση επιλεγμένου σημείου</translation>
    </message>
    <message>
        <source>Remove selected point from polygon</source>
        <translation>Αφαίρεση επιλεγμένου σημείου από πολύγωνο</translation>
    </message>
    <message>
        <source>Start drawing polygons</source>
        <translation>Ξεκινήστε να σχεδιάζετε πολύγωνα</translation>
    </message>
    <message>
        <source>Edit Shapes</source>
        <translation>Επεξεργασία σχημάτων</translation>
    </message>
    <message>
        <source>Move and edit the selected shapes</source>
        <translation>Μετακίνηση και επεξεργασία των επιλεγμένων σχημάτων</translation>
    </message>
    <message>
        <source>Start drawing rectangles</source>
        <translation>Ξεκινήστε να σχεδιάζετε ορθογώνια</translation>
    </message>
    <message>
        <source>Start drawing circles</source>
        <translation>Έναρξη σχεδίασης κύκλων</translation>
    </message>
    <message>
        <source>Start drawing lines</source>
        <translation>Έναρξη σχεδίασης γραμμών</translation>
    </message>
    <message>
        <source>Start drawing points</source>
        <translation>Έναρξη σχεδίασης σημείων</translation>
    </message>
    <message>
        <source>&amp;Next Image</source>
        <translation>Επόμενη εικόνα</translation>
    </message>
    <message>
        <source>Open next (hold Ctl+Shift to copy labels)</source>
        <translation>Ανοίξτε το επόμενο (κρατήστε πατημένο το πλήκτρο Ctl+Shift για να αντιγράψετε τις ετικέτες)</translation>
    </message>
    <message>
        <source>&amp;Prev Image</source>
        <translation>&amp;Προηγούμενη εικόνα</translation>
    </message>
    <message>
        <source>Open prev (hold Ctl+Shift to copy labels)</source>
        <translation>Άνοιγμα προηγούμενου (κρατήστε πατημένο το πλήκτρο Ctl+Shift για να αντιγράψετε τις ετικέτες)</translation>
    </message>
    <message>
        <source>&amp;Brightness Contrast</source>
        <translation>αντίθεση φωτεινότητας</translation>
    </message>
    <message>
        <source>Adjust brightness and contrast</source>
        <translation>Ρύθμιση της φωτεινότητας και της αντίθεσης</translation>
    </message>
    <message>
        <source>Zoom &amp;In</source>
        <translation>&amp; Μεγέθυνση</translation>
    </message>
    <message>
        <source>&amp;Zoom Out</source>
        <translation>&amp;Σμίκρυνση</translation>
    </message>
    <message>
        <source>Reset Layout</source>
        <translation>Επαναφορά Διάταξης</translation>
    </message>
    <message>
        <source>Fill Drawing Polygon</source>
        <translation>Γεμίστε το πολύγωνο σχεδίασης</translation>
    </message>
    <message>
        <source>Fill polygon while drawing</source>
        <translation>Γεμίστε πολύγωνο ενώ σχεδιάζετε</translation>
    </message>
    <message>
        <source>&amp;Hide
Shapes</source>
        <translation>&amp;Απόκρυψη
Σχήματα</translation>
    </message>
    <message>
        <source>Hide all shapes</source>
        <translation>Όλα τα σχήματα</translation>
    </message>
    <message>
        <source>&amp;Show
Shapes</source>
        <translation>Προβολή σχημάτων</translation>
    </message>
    <message>
        <source>Show all shapes</source>
        <translation>Όλα τα σχήματα</translation>
    </message>
    <message>
        <source>&amp;Toggle
Shapes</source>
        <translation>&amp;Εναλλαγή
Σχήματα</translation>
    </message>
    <message>
        <source>Toggle all shapes</source>
        <translation>Εναλλαγή όλων των σχημάτων</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation>Εστίαση</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation>Τερματισμός</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>Έξοδος από την εφαρμογή</translation>
    </message>
    <message>
        <source>&amp;Tutorial</source>
        <translation>&amp; Εκμάθηση</translation>
    </message>
    <message>
        <source>Show tutorial page</source>
        <translation>Εμφάνιση σελίδας εκμάθησης</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>Αρχείο</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>Επεξεργασία</translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation>Προβολή</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>Βοήθεια</translation>
    </message>
    <message>
        <source>%s started.</source>
        <translation>%s ξεκίνησε.</translation>
    </message>
    <message>
        <source>Flags</source>
        <translation>Σημάνσεις</translation>
    </message>
    <message>
        <source>Shape List</source>
        <translation>Λίστα σχημάτων</translation>
    </message>
    <message>
        <source>Select label to start annotating for it. Press &apos;Esc&apos; to deselect.</source>
        <translation>Επιλέξτε την ετικέτα για να ξεκινήσετε να την σχολιάζετε. Πατήστε &apos;Esc&apos; για αποεπιλογή.</translation>
    </message>
    <message>
        <source>Label List</source>
        <translation>Λίστα ετικετών</translation>
    </message>
    <message>
        <source>Search Filename</source>
        <translation>Αναζήτηση ονόματος αρχείου</translation>
    </message>
    <message>
        <source>File List</source>
        <translation>Λίστα αρχείων</translation>
    </message>
    <message>
        <source>Configuration Errors</source>
        <translation>Σφάλματα διαμόρφωσης</translation>
    </message>
    <message>
        <source>Errors were found while loading the configuration. Please review the errors below and reload your configuration or ignore the erroneous lines.</source>
        <translation>Βρέθηκαν σφάλματα κατά τη φόρτωση της διαμόρφωσης. Ελέγξτε τα παρακάτω σφάλματα και φορτώστε ξανά τη διαμόρφωσή σας ή αγνοήστε τις λανθασμένες γραμμές.</translation>
    </message>
    <message>
        <source>Mask Output Unavailable</source>
        <translation>Η έξοδος μάσκας δεν είναι διαθέσιμη</translation>
    </message>
    <message>
        <source>%s only detects bounding boxes and cannot create &apos;%s&apos; annotations.

Switch the AI Text-to-Annotation model to &apos;SAM3 (smart)&apos;, or set the output format to &apos;Rectangle&apos;.</source>
        <translation>Το %s εντοπίζει μόνο πλαίσια οριοθέτησης και δεν μπορεί να δημιουργήσει σχολιασμούς &apos;%s&apos;.

Αλλάξτε το μοντέλο AI Text-to-Annotation σε &apos;SAM3 (smart)&apos; ή ορίστε τη μορφή εξόδου σε &apos;Rectangle&apos;.</translation>
    </message>
    <message>
        <source>Invalid label</source>
        <translation>Μη έγκυρη ετικέτα</translation>
    </message>
    <message>
        <source>Invalid label &apos;{}&apos; with validation type &apos;{}&apos;</source>
        <translation>Μη έγκυρη ετικέτα &apos;{}&apos; με τύπο επικύρωσης &apos;{}&apos;</translation>
    </message>
    <message>
        <source>Error saving label data</source>
        <translation>Σφάλμα κατά την αποθήκευση δεδομένων ετικέτας</translation>
    </message>
    <message>
        <source>&lt;b&gt;%s&lt;/b&gt;</source>
        <translation>&lt;b&gt;%s&lt;/b&gt;</translation>
    </message>
    <message>
        <source>AI inference failed: %s</source>
        <translation>Η συμπερασματική επεξεργασία ΤΝ απέτυχε: %s</translation>
    </message>
    <message>
        <source>Error opening file</source>
        <translation>Σφάλμα κατά το άνοιγμα του αρχείου</translation>
    </message>
    <message>
        <source>No such file: &lt;b&gt;%s&lt;/b&gt;</source>
        <translation>Δεν υπάρχει τέτοιο αρχείο: &lt;b&gt;%s&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Loading %s...</source>
        <translation>Φόρτωση %s...</translation>
    </message>
    <message>
        <source>Loaded %s</source>
        <translation>Φορτώθηκε %s</translation>
    </message>
    <message>
        <source>Image &amp; Label files (%s)</source>
        <translation>Αρχεία εικόνας και ετικέτας (%s)</translation>
    </message>
    <message>
        <source>%s - Choose Image or Label file</source>
        <translation>%s - Επιλέξτε αρχείο εικόνας ή ετικέτας</translation>
    </message>
    <message>
        <source>%s - Save/Load Annotations in Directory</source>
        <translation>%s - Αποθήκευση/Φόρτωση σχολιασμών στον κατάλογο</translation>
    </message>
    <message>
        <source>%s . Annotations will be saved/loaded in %s</source>
        <translation>%s . Οι σχολιασμοί θα αποθηκεύονται/φορτώνονται στο %s</translation>
    </message>
    <message>
        <source>%s - Choose File</source>
        <translation>%s - Επιλογή αρχείου</translation>
    </message>
    <message>
        <source>Label files (*%s)</source>
        <translation>Αρχεία ετικετών (*%s)</translation>
    </message>
    <message>
        <source>Choose File</source>
        <translation>Επιλογή αρχείου</translation>
    </message>
    <message>
        <source>Attention</source>
        <translation>Προσοχή</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Διαγραφή</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Άκυρο</translation>
    </message>
    <message>
        <source>Unavailable in AI-Points mode because this model does not support point prompts.</source>
        <translation>Μη διαθέσιμο στη λειτουργία AI-Points, επειδή αυτό το μοντέλο δεν υποστηρίζει εντολές σημείων.</translation>
    </message>
    <message>
        <source>Save annotations to &quot;{}&quot; before closing?</source>
        <translation>Να αποθηκευτούν οι σχολιασμοί στο &quot;{}&quot; πριν το κλείσιμο;</translation>
    </message>
    <message>
        <source>Save annotations?</source>
        <translation>Αποθήκευση σχολιασμών;</translation>
    </message>
    <message>
        <source>Delete {} shapes? You can restore them with Undo.</source>
        <translation>Διαγραφή {} σχημάτων; Μπορείτε να τα επαναφέρετε με την Αναίρεση.</translation>
    </message>
    <message>
        <source>%s - Open Directory</source>
        <translation>%s - Άνοιγμα καταλόγου</translation>
    </message>
    <message>
        <source>The image is too large to open: {width}x{height} pixels exceeds the {max_side} pixel per-side limit of the raster engine. Raising the decode limit will not help. Split the image into tiles (for example with gdal_retile.py) or open a smaller copy.</source>
        <translation>Η εικόνα είναι πολύ μεγάλη για να ανοίξει: {width}x{height} pixel υπερβαίνουν το όριο των {max_side} pixel ανά πλευρά της μηχανής raster. Η αύξηση του ορίου αποκωδικοποίησης δεν θα βοηθήσει. Χωρίστε την εικόνα σε πλακίδια (για παράδειγμα με το gdal_retile.py) ή ανοίξτε ένα μικρότερο αντίγραφο.</translation>
    </message>
    <message>
        <source>The image is too large to open: {width}x{height} pixels needs about {required} MB, but the decode limit is {limit} MB. Split the image into tiles (for example with gdal_retile.py) or open a smaller copy.</source>
        <translation>Η εικόνα είναι πολύ μεγάλη για να ανοίξει: {width}x{height} pixel χρειάζονται περίπου {required} MB, αλλά το όριο αποκωδικοποίησης είναι {limit} MB. Χωρίστε την εικόνα σε πλακίδια (για παράδειγμα με το gdal_retile.py) ή ανοίξτε ένα μικρότερο αντίγραφο.</translation>
    </message>
    <message>
        <source>Polygon</source>
        <translation>Πολύγωνο</translation>
    </message>
    <message>
        <source>Save the labels under a new file name</source>
        <translation>Αποθήκευση των ετικετών με νέο όνομα αρχείου</translation>
    </message>
    <message>
        <source>Insert the clipboard shapes into this image</source>
        <translation>Εισαγωγή των σχημάτων του προχείρου σε αυτήν την εικόνα</translation>
    </message>
    <message>
        <source>Rectangle</source>
        <translation>Ορθογώνιο</translation>
    </message>
    <message>
        <source>Circle</source>
        <translation>Κύκλος</translation>
    </message>
    <message>
        <source>Line</source>
        <translation>Γραμμή</translation>
    </message>
    <message>
        <source>Point</source>
        <translation>Σημείο</translation>
    </message>
    <message>
        <source>LineStrip</source>
        <translation>LineStrip</translation>
    </message>
    <message>
        <source>Click to place linestrip points; Ctrl+click places the last one.</source>
        <translation>Κάντε κλικ για να τοποθετήσετε σημεία του linestrip· Ctrl+κλικ τοποθετεί το τελευταίο.</translation>
    </message>
    <message>
        <source>AI-Points</source>
        <translation>AI-Points</translation>
    </message>
    <message>
        <source>Click points to segment object. Ctrl+LeftClick ends creation.</source>
        <translation>Κάντε κλικ σε σημεία για κατάτμηση αντικειμένου. Ctrl+LeftClick ολοκληρώνει τη δημιουργία.</translation>
    </message>
    <message>
        <source>AI-Box</source>
        <translation>AI-Box</translation>
    </message>
    <message>
        <source>Draw a bounding box to segment object.</source>
        <translation>Σχεδιάστε ένα πλαίσιο οριοθέτησης για τμηματοποίηση αντικειμένου.</translation>
    </message>
    <message>
        <source>Fit to &amp;Window</source>
        <translation>&amp;Προσαρμογή παραθύρου</translation>
    </message>
    <message>
        <source>Keep the whole image visible when the window is resized</source>
        <translation>Διατήρηση ολόκληρης της εικόνας ορατής όταν αλλάζει το μέγεθος του παραθύρου</translation>
    </message>
    <message>
        <source>Fit to Wi&amp;dth</source>
        <translation>Προσαρμογή στο &amp; πλάτος</translation>
    </message>
    <message>
        <source>Match the image width to the window when it is resized</source>
        <translation>Ταίριασμα του πλάτους της εικόνας με το παράθυρο όταν αλλάζει το μέγεθός του</translation>
    </message>
    <message>
        <source>Make the image appear larger</source>
        <translation>Εμφάνιση της εικόνας μεγαλύτερης</translation>
    </message>
    <message>
        <source>Make the image appear smaller</source>
        <translation>Εμφάνιση της εικόνας μικρότερης</translation>
    </message>
    <message>
        <source>&amp;Actual Size</source>
        <translation>&amp;Πραγματικό μέγεθος</translation>
    </message>
    <message>
        <source>Show the image at 100%</source>
        <translation>Εμφάνιση της εικόνας στο 100%</translation>
    </message>
    <message>
        <source>Ctrl+Wheel zooms the canvas</source>
        <translation>Ctrl+Ροδέλα κάνει ζουμ στον καμβά</translation>
    </message>
    <message>
        <source>AI-Points Unavailable</source>
        <translation>AI-Points μη διαθέσιμο</translation>
    </message>
    <message>
        <source>%s does not support point prompts.
Please select a different model or use AI-Box mode.</source>
        <translation>%s δεν υποστηρίζει εντολές σημείων.
Επιλέξτε διαφορετικό μοντέλο ή χρησιμοποιήστε τη λειτουργία AI-Box.</translation>
    </message>
    <message>
        <source>File list is disabled when a label file is opened</source>
        <translation>Η λίστα αρχείων είναι απενεργοποιημένη όταν ανοίγεται ένα αρχείο ετικετών</translation>
    </message>
    <message>
        <source>Add Point to Edge</source>
        <translation>Προσθήκη σημείου στην ακμή</translation>
    </message>
    <message>
        <source>Insert a new point at the hovered polygon edge</source>
        <translation>Εισαγωγή νέου σημείου στην επιλεγμένη ακμή πολυγώνου</translation>
    </message>
    <message>
        <source>&amp;Keep Previous Zoom</source>
        <translation>&amp;Διατήρηση προηγούμενου ζουμ</translation>
    </message>
    <message>
        <source>Permanently delete this label file? This action cannot be undone.</source>
        <translation>Οριστική διαγραφή αυτού του αρχείου ετικετών; Αυτή η ενέργεια δεν μπορεί να αναιρεθεί.</translation>
    </message>
    <message>
        <source>Allowed formats: {formats}</source>
        <translation>Επιτρεπόμενες μορφές: {formats}</translation>
    </message>
    <message>
        <source>The selected label file could not be opened: {path}</source>
        <translation>Δεν ήταν δυνατό το άνοιγμα του επιλεγμένου αρχείου ετικετών: {path}</translation>
    </message>
    <message>
        <source>The selected image file could not be opened: {path}</source>
        <translation>Δεν ήταν δυνατό το άνοιγμα του επιλεγμένου αρχείου εικόνας: {path}</translation>
    </message>
    <message>
        <source>Failed to load: {path}</source>
        <translation>Αποτυχία φόρτωσης: {path}</translation>
    </message>
    <message>
        <source>Oriented Rectangle</source>
        <translation>Προσανατολισμένο Ορθογώνιο</translation>
    </message>
    <message>
        <source>Start drawing oriented rectangles</source>
        <translation>Ξεκινήστε να σχεδιάζετε προσανατολισμένα ορθογώνια</translation>
    </message>
    <message>
        <source>AI inference produced no new annotation.</source>
        <translation>Η συμπερασματική επεξεργασία ΤΝ δεν δημιούργησε νέο σχολιασμό.</translation>
    </message>
    <message>
        <source>Shape had no area; nothing created.</source>
        <translation>Το σχήμα δεν είχε εμβαδό· δεν δημιουργήθηκε τίποτα.</translation>
    </message>
    <message>
        <source>Settings…</source>
        <translation>Ρυθμίσεις…</translation>
    </message>
    <message>
        <source>Edit settings</source>
        <translation>Επεξεργασία ρυθμίσεων</translation>
    </message>
    <message>
        <source>Settings are managed via --config for this session</source>
        <translation>Οι ρυθμίσεις διαχειρίζονται μέσω --config για αυτή την περίοδο λειτουργίας</translation>
    </message>
    <message>
        <source>Configuration Error</source>
        <translation>Σφάλμα διαμόρφωσης</translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <source>Color theme</source>
        <translation>Θέμα χρώματος</translation>
    </message>
    <message>
        <source>System</source>
        <translation>Σύστημα</translation>
    </message>
    <message>
        <source>Light</source>
        <translation>Φωτεινό</translation>
    </message>
    <message>
        <source>Dark</source>
        <translation>Σκοτεινό</translation>
    </message>
    <message>
        <source>Show label popup on new shape</source>
        <translation>Εμφάνιση αναδυόμενου παραθύρου ετικέτας σε νέο σχήμα</translation>
    </message>
    <message>
        <source>Show shape labels on canvas</source>
        <translation>Εμφάνιση ετικετών σχήματος στον καμβά</translation>
    </message>
    <message>
        <source>Allow points outside the image boundary</source>
        <translation>Να επιτρέπονται σημεία εκτός των ορίων της εικόνας</translation>
    </message>
    <message>
        <source>Appearance and language</source>
        <translation>Εμφάνιση και γλώσσα</translation>
    </message>
    <message>
        <source>Files and saving</source>
        <translation>Αρχεία και αποθήκευση</translation>
    </message>
    <message>
        <source>Drawing and canvas</source>
        <translation>Σχεδίαση και καμβάς</translation>
    </message>
    <message>
        <source>Continue between images</source>
        <translation>Συνέχεια μεταξύ εικόνων</translation>
    </message>
    <message>
        <source>Label sources</source>
        <translation>Πηγές ετικετών</translation>
    </message>
    <message>
        <source>Label behavior</source>
        <translation>Συμπεριφορά ετικετών</translation>
    </message>
    <message>
        <source>AI assist</source>
        <translation>Βοήθεια AI</translation>
    </message>
    <message>
        <source>Save automatically</source>
        <translation>Αυτόματη αποθήκευση</translation>
    </message>
    <message>
        <source>Save image data in label file</source>
        <translation>Αποθήκευση δεδομένων εικόνας σε αρχείο ετικέτας</translation>
    </message>
    <message>
        <source>Embeds the image in the label JSON file.</source>
        <translation>Ενσωματώνει την εικόνα στο αρχείο JSON της ετικέτας.</translation>
    </message>
    <message>
        <source>Shape Color Mode</source>
        <translation>Λειτουργία χρώματος σχήματος</translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation>Αυτόματο</translation>
    </message>
    <message>
        <source>Uniform</source>
        <translation>Ομοιόμορφο</translation>
    </message>
    <message>
        <source>By Label</source>
        <translation>Ανά ετικέτα</translation>
    </message>
    <message>
        <source>Automatic palette shift</source>
        <translation>Αυτόματη μετατόπιση παλέτας</translation>
    </message>
    <message>
        <source>Uniform mode color</source>
        <translation>Χρώμα λειτουργίας «Ομοιόμορφο»</translation>
    </message>
    <message>
        <source>By Label fallback color</source>
        <translation>Εφεδρικό χρώμα λειτουργίας «Ανά ετικέτα»</translation>
    </message>
    <message>
        <source>Individual Label colors remain editable in the Config File.</source>
        <translation>Τα μεμονωμένα χρώματα ετικετών παραμένουν επεξεργάσιμα στο αρχείο ρυθμίσεων.</translation>
    </message>
    <message>
        <source>Keep previous annotation</source>
        <translation>Διατήρηση προηγούμενου σχολιασμού</translation>
    </message>
    <message>
        <source>Keep previous zoom</source>
        <translation>Διατήρηση προηγούμενου ζουμ</translation>
    </message>
    <message>
        <source>Keep previous brightness/contrast</source>
        <translation>Διατήρηση προηγούμενης φωτεινότητας/αντίθεσης</translation>
    </message>
    <message>
        <source>Fill polygon while drawing</source>
        <translation>Γεμίστε πολύγωνο ενώ σχεδιάζετε</translation>
    </message>
    <message>
        <source>Let shape points extend beyond the image, e.g. for partially visible objects.</source>
        <translation>Επιτρέπει στα σημεία των σχημάτων να εκτείνονται πέρα από την εικόνα, π.χ. για μερικώς ορατά αντικείμενα.</translation>
    </message>
    <message>
        <source>Polygon detail</source>
        <translation>Λεπτομέρεια πολυγώνου</translation>
    </message>
    <message>
        <source>Higher values preserve more Mask boundary detail and smaller lands.</source>
        <translation>Οι υψηλότερες τιμές διατηρούν περισσότερες λεπτομέρειες του ορίου της μάσκας και μικρότερες περιοχές.</translation>
    </message>
    <message>
        <source>Predefined labels</source>
        <translation>Προκαθορισμένες ετικέτες</translation>
    </message>
    <message>
        <source>Label validation</source>
        <translation>Επικύρωση ετικέτας</translation>
    </message>
    <message>
        <source>Sort labels</source>
        <translation>Ταξινόμηση ετικετών</translation>
    </message>
    <message>
        <source>Sort the label list alphabetically instead of keeping the provided order.</source>
        <translation>Ταξινομεί τη λίστα ετικετών αλφαβητικά αντί να διατηρεί την παρεχόμενη σειρά.</translation>
    </message>
    <message>
        <source>Show label text field</source>
        <translation>Εμφάνιση πεδίου κειμένου ετικέτας</translation>
    </message>
    <message>
        <source>Label completion</source>
        <translation>Αυτόματη συμπλήρωση ετικετών</translation>
    </message>
    <message>
        <source>Starts with</source>
        <translation>Αρχίζει με</translation>
    </message>
    <message>
        <source>Contains</source>
        <translation>Περιέχει</translation>
    </message>
    <message>
        <source>Default model</source>
        <translation>Προεπιλεγμένο μοντέλο</translation>
    </message>
    <message>
        <source>EfficientSam (speed)</source>
        <translation>EfficientSam (ταχύτητα)</translation>
    </message>
    <message>
        <source>EfficientSam (accuracy)</source>
        <translation>EfficientSam (ακρίβεια)</translation>
    </message>
    <message>
        <source>Sam (speed)</source>
        <translation>Sam (ταχύτητα)</translation>
    </message>
    <message>
        <source>Sam (balanced)</source>
        <translation>Sam (ισορροπημένο)</translation>
    </message>
    <message>
        <source>Sam (accuracy)</source>
        <translation>Sam (ακρίβεια)</translation>
    </message>
    <message>
        <source>Sam2 (speed)</source>
        <translation>Sam2 (ταχύτητα)</translation>
    </message>
    <message>
        <source>Sam2 (balanced)</source>
        <translation>Sam2 (ισορροπημένο)</translation>
    </message>
    <message>
        <source>Sam2 (accuracy)</source>
        <translation>Sam2 (ακρίβεια)</translation>
    </message>
    <message>
        <source>Sam3</source>
        <translation>Sam3</translation>
    </message>
    <message>
        <source>Suppress existing Shape matches</source>
        <translation>Καταστολή αντιστοιχιών με υπάρχοντα σχήματα</translation>
    </message>
    <message>
        <source>When an AI Assist candidate matches an existing Shape, highlight that Shape instead of creating a new Shape.</source>
        <translation>Όταν ένα υποψήφιο αποτέλεσμα της Βοήθειας AI αντιστοιχεί σε υπάρχον σχήμα, επισημαίνεται εκείνο το σχήμα αντί να δημιουργηθεί νέο σχήμα.</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Ρυθμίσεις</translation>
    </message>
    <message>
        <source>Open config file as text…</source>
        <translation>Άνοιγμα αρχείου ρυθμίσεων ως κείμενο…</translation>
    </message>
    <message>
        <source>Edits made in the text file apply after restart</source>
        <translation>Οι αλλαγές στο αρχείο κειμένου εφαρμόζονται μετά την επανεκκίνηση</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Κλείσιμο</translation>
    </message>
    <message>
        <source>BETA</source>
        <translation>BETA</translation>
    </message>
    <message>
        <source>(none)</source>
        <translation>(καμία)</translation>
    </message>
    <message>
        <source>one item per line</source>
        <translation>ένα στοιχείο ανά γραμμή</translation>
    </message>
    <message>
        <source>Configuration Error</source>
        <translation>Σφάλμα διαμόρφωσης</translation>
    </message>
    <message>
        <source>Predefined labels cannot be empty while Label validation is set to exact. Disable exact validation first.</source>
        <translation>Οι προκαθορισμένες ετικέτες δεν μπορούν να είναι κενές όταν η επικύρωση ετικέτας έχει οριστεί σε «exact». Απενεργοποιήστε πρώτα την επικύρωση «exact».</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Γλώσσα</translation>
    </message>
    <message>
        <source>Takes effect after restart.</source>
        <translation>Εφαρμόζεται μετά την επανεκκίνηση.</translation>
    </message>
    <message>
        <source>System default</source>
        <translation>Προεπιλογή συστήματος</translation>
    </message>
    <message>
        <source>Predefined image flags</source>
        <translation>Προκαθορισμένες σημαίες εικόνας</translation>
    </message>
</context>
<context>
    <name>_ColorSwatchButton</name>
    <message>
        <source>RGB: {red}, {green}, {blue}</source>
        <translation>RGB: {red}, {green}, {blue}</translation>
    </message>
</context>
<context>
    <name>_SettingsPage</name>
    <message>
        <source>Settings sections</source>
        <translation>Ενότητες ρυθμίσεων</translation>
    </message>
</context>
</TS>
