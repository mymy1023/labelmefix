<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="id_ID">
<context>
    <name>AiAssistedAnnotationWidget</name>
    <message>
        <source>AI-Assisted Annotation</source>
        <translation>Anotasi berbasis AI</translation>
    </message>
    <message>
        <source>AI suggests annotation in &apos;AI-Points&apos; and &apos;AI-Box&apos; modes</source>
        <translation>AI menyarankan anotasi dalam mode &apos;AI-Points&apos; dan &apos;AI-Box&apos;</translation>
    </message>
    <message>
        <source>Polygon detail</source>
        <translation>Detail poligon</translation>
    </message>
    <message>
        <source>Adjust polygon detail</source>
        <translation>Sesuaikan detail poligon</translation>
    </message>
    <message>
        <source>Smoother</source>
        <translation>Lebih halus</translation>
    </message>
    <message>
        <source>More detail</source>
        <translation>Lebih detail</translation>
    </message>
    <message>
        <source>Select &apos;AI-Points&apos; or &apos;AI-Box&apos; mode to enable AI-Assisted Annotation</source>
        <translation>Pilih mode &apos;AI-Points&apos; atau &apos;AI-Box&apos; untuk mengaktifkan Anotasi yang berbasis AI</translation>
    </message>
</context>
<context>
    <name>AiTextToAnnotationWidget</name>
    <message>
        <source>AI Text-to-Annotation</source>
        <translation>Anotasi dari teks (AI)</translation>
    </message>
    <message>
        <source>e.g., dog,cat,bird</source>
        <translation>contoh: anjing, kucing, burung</translation>
    </message>
    <message>
        <source>Run</source>
        <translation>Jalankan</translation>
    </message>
    <message>
        <source>Score</source>
        <translation>Skor</translation>
    </message>
    <message>
        <source>IoU</source>
        <translation>IoU</translation>
    </message>
    <message>
        <source>AI creates annotations from the text prompt</source>
        <translation>AI membuat anotasi dari prompt teks</translation>
    </message>
    <message>
        <source>Select &apos;Polygon&apos;, &apos;Rectangle&apos;, or &apos;AI-Points&apos; mode to enable</source>
        <translation>Pilih mode &apos;Polygon&apos;, &apos;Rectangle&apos;, atau &apos;AI-Points&apos; untuk mengaktifkan</translation>
    </message>
</context>
<context>
    <name>BrightnessContrastDialog</name>
    <message>
        <source>Brightness/Contrast</source>
        <translation>Kecerahan/Kontras</translation>
    </message>
    <message>
        <source>Brightness:</source>
        <translation>Kecerahan:</translation>
    </message>
    <message>
        <source>Contrast:</source>
        <translation>Kontras:</translation>
    </message>
</context>
<context>
    <name>Canvas</name>
    <message>
        <source>Click &amp; drag to move point</source>
        <translation>Klik &amp; seret untuk memindahkan titik</translation>
    </message>
    <message>
        <source>Click &amp; drag to move shape</source>
        <translation>Klik &amp; seret untuk memindahkan bentuk</translation>
    </message>
    <message>
        <source>Creating %r</source>
        <translation>Membuat %r</translation>
    </message>
    <message>
        <source>ESC to cancel</source>
        <translation>ESC untuk membatalkan</translation>
    </message>
    <message>
        <source>Enter or Space to finalize</source>
        <translation>Enter atau Spasi untuk finalisasi</translation>
    </message>
    <message>
        <source>Editing shapes</source>
        <translation>Mengedit bentuk</translation>
    </message>
    <message>
        <source>Click start point for line</source>
        <translation>Klik titik awal untuk garis</translation>
    </message>
    <message>
        <source>Click end point for line</source>
        <translation>Klik titik akhir untuk garis</translation>
    </message>
    <message>
        <source>Click start point for linestrip</source>
        <translation>Klik titik awal untuk garis patah</translation>
    </message>
    <message>
        <source>Click next point or finish by Ctrl/Cmd+Click for linestrip</source>
        <translation>Klik titik berikutnya atau selesaikan dengan Ctrl/Cmd+Klik untuk garis patah</translation>
    </message>
    <message>
        <source>Click center point for circle</source>
        <translation>Klik titik pusat untuk lingkaran</translation>
    </message>
    <message>
        <source>Click point on circumference for circle</source>
        <translation>Klik titik pada keliling untuk membuat lingkaran</translation>
    </message>
    <message>
        <source>Click first corner for rectangle</source>
        <translation>Klik sudut pertama untuk membuat persegi panjang</translation>
    </message>
    <message>
        <source>Click to add point</source>
        <translation>Klik untuk menambahkan titik</translation>
    </message>
    <message>
        <source>ALT + SHIFT + Click to delete point</source>
        <translation>ALT + SHIFT + Klik untuk menghapus titik</translation>
    </message>
    <message>
        <source>ALT + Click to create point on shape</source>
        <translation>ALT + Klik untuk membuat titik pada bentuk</translation>
    </message>
    <message>
        <source>Right-click &amp; drag to copy shape</source>
        <translation>Klik kanan &amp; seret untuk menyalin bentuk</translation>
    </message>
    <message>
        <source>Click opposite corner for rectangle (Shift for square)</source>
        <translation>Klik sudut berlawanan untuk persegi panjang (Shift untuk persegi)</translation>
    </message>
    <message>
        <source>Click points to include or Shift+Click to exclude. Ctrl+LeftClick ends creation.</source>
        <translation>Klik titik-titik untuk menyertakan, atau Shift+Klik untuk mengecualikan. Ctrl+Klik Kiri untuk mengakhiri pembuatan.</translation>
    </message>
    <message>
        <source>Click first corner of bbox for AI segmentation</source>
        <translation>Klik sudut pertama bbox untuk segmentasi AI</translation>
    </message>
    <message>
        <source>Click opposite corner to segment object</source>
        <translation>Klik sudut berlawanan untuk segmentasi objek</translation>
    </message>
    <message>
        <source>Click first corner for oriented rectangle</source>
        <translation>Klik sudut pertama untuk persegi panjang berorientasi</translation>
    </message>
    <message>
        <source>Click second corner to set orientation</source>
        <translation>Klik sudut kedua untuk mengatur orientasi</translation>
    </message>
    <message>
        <source>Click third corner to close oriented rectangle</source>
        <translation>Klik sudut ketiga untuk menutup persegi panjang berorientasi</translation>
    </message>
    <message>
        <source>Click &amp; drag to rotate the shape</source>
        <translation>Klik &amp; seret untuk merotasi bentuk</translation>
    </message>
</context>
<context>
    <name>EmptyStateWidget</name>
    <message>
        <source>Start annotating</source>
        <translation>Mulai anotasi</translation>
    </message>
    <message>
        <source>Open an image or a directory of images to begin.</source>
        <translation>Buka gambar atau direktori gambar untuk memulai.</translation>
    </message>
    <message>
        <source>Open Image</source>
        <translation>Buka Gambar</translation>
    </message>
    <message>
        <source>Open Directory</source>
        <translation>Buka Direktori</translation>
    </message>
    <message>
        <source>Or drag and drop image files here</source>
        <translation>Atau seret dan lepaskan file gambar di sini</translation>
    </message>
</context>
<context>
    <name>LabelDialog</name>
    <message>
        <source>Shape Label</source>
        <translation>Label Bentuk</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Label</translation>
    </message>
    <message>
        <source>Group ID</source>
        <translation>ID Grup</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Deskripsi</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Flags</source>
        <translation>Penanda</translation>
    </message>
    <message>
        <source>Shape List</source>
        <translation>Daftar Bentuk</translation>
    </message>
    <message>
        <source>Select label to start annotating for it. Press &apos;Esc&apos; to deselect.</source>
        <translation>Pilih label untuk memulai anotasi. Tekan &apos;Esc&apos; untuk membatalkan pilihan.</translation>
    </message>
    <message>
        <source>Label List</source>
        <translation>Daftar Label</translation>
    </message>
    <message>
        <source>Search Filename</source>
        <translation>Cari Nama File</translation>
    </message>
    <message>
        <source>File List</source>
        <translation>Daftar File</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation>Keluar (&amp;Q)</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>Keluar Aplikasi</translation>
    </message>
    <message>
        <source>Open image or label file</source>
        <translation>Buka file gambar atau label</translation>
    </message>
    <message>
        <source>Open Dir</source>
        <translation>Buka Direktori</translation>
    </message>
    <message>
        <source>&amp;Next Image</source>
        <translation>Gambar Berikutnya (&amp;N)</translation>
    </message>
    <message>
        <source>Open next (hold Ctl+Shift to copy labels)</source>
        <translation>Buka Berikutnya (Tahan Ctrl+Shift untuk menyalin label)</translation>
    </message>
    <message>
        <source>&amp;Prev Image</source>
        <translation>Gambar Sebelumnya (&amp;P)</translation>
    </message>
    <message>
        <source>Open prev (hold Ctl+Shift to copy labels)</source>
        <translation>Buka Sebelumnya (Tahan Ctrl+Shift untuk menyalin label)</translation>
    </message>
    <message>
        <source>&amp;Save
</source>
        <translation>&amp;Simpan</translation>
    </message>
    <message>
        <source>Save labels to file</source>
        <translation>Simpan label ke file</translation>
    </message>
    <message>
        <source>&amp;Save As</source>
        <translation>&amp;Simpan Sebagai</translation>
    </message>
    <message>
        <source>&amp;Delete File</source>
        <translation>Hapus File (&amp;D)</translation>
    </message>
    <message>
        <source>Delete current label file</source>
        <translation>Hapus file label ini</translation>
    </message>
    <message>
        <source>&amp;Change Output Dir</source>
        <translation>Ubah Direktori Output (&amp;C)</translation>
    </message>
    <message>
        <source>Change where annotations are loaded/saved</source>
        <translation>Ubah tempat pengambilan/penyimpanan anotasi</translation>
    </message>
    <message>
        <source>Save &amp;Automatically</source>
        <translation>Simpan Otomatis (&amp;A)</translation>
    </message>
    <message>
        <source>Save automatically</source>
        <translation>Simpan otomatis</translation>
    </message>
    <message>
        <source>Save With Image Data</source>
        <translation>Simpan Dengan Data Gambar</translation>
    </message>
    <message>
        <source>Save image data in label file</source>
        <translation>Simpan data gambar dalam file label</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>Tutup (&amp;C)</translation>
    </message>
    <message>
        <source>Close current file</source>
        <translation>Tutup file ini</translation>
    </message>
    <message>
        <source>Keep Previous Annotation</source>
        <translation>Pertahankan Anotasi Sebelumnya</translation>
    </message>
    <message>
        <source>Start drawing polygons</source>
        <translation>Mulai menggambar poligon</translation>
    </message>
    <message>
        <source>Start drawing rectangles</source>
        <translation>Mulai menggambar persegi panjang</translation>
    </message>
    <message>
        <source>Start drawing circles</source>
        <translation>Mulai menggambar lingkaran</translation>
    </message>
    <message>
        <source>Start drawing lines</source>
        <translation>Mulai menggambar garis</translation>
    </message>
    <message>
        <source>Start drawing points</source>
        <translation>Mulai menggambar titik</translation>
    </message>
    <message>
        <source>Edit Shapes</source>
        <translation>Edit Bentuk</translation>
    </message>
    <message>
        <source>Move and edit the selected shapes</source>
        <translation>Pindah dan edit bentuk terpilih</translation>
    </message>
    <message>
        <source>Delete Shapes</source>
        <translation>Hapus Bentuk</translation>
    </message>
    <message>
        <source>Delete the selected shapes</source>
        <translation>Hapus bentuk terpilih</translation>
    </message>
    <message>
        <source>Duplicate Shapes</source>
        <translation>Duplikat Bentuk</translation>
    </message>
    <message>
        <source>Create a duplicate of the selected shapes</source>
        <translation>Buat duplikat dari bentuk terpilih</translation>
    </message>
    <message>
        <source>Undo last point</source>
        <translation>Urungkan titik terakhir</translation>
    </message>
    <message>
        <source>Undo last drawn point</source>
        <translation>Urungkan titik terakhir yang digambar</translation>
    </message>
    <message>
        <source>Remove Selected Point</source>
        <translation>Hapus Titik Terpilih</translation>
    </message>
    <message>
        <source>Remove selected point from polygon</source>
        <translation>Hapus titik terpilih dari poligon</translation>
    </message>
    <message>
        <source>Undo last add and edit of shape</source>
        <translation>Urungkan penambahan dan pengeditan bentuk terakhir</translation>
    </message>
    <message>
        <source>Hide all shapes</source>
        <translation>Sembunyikan semua bentuk</translation>
    </message>
    <message>
        <source>Show all shapes</source>
        <translation>Tampilkan semua bentuk</translation>
    </message>
    <message>
        <source>Toggle all shapes</source>
        <translation>Tampilkan/sembunyikan semua bentuk</translation>
    </message>
    <message>
        <source>&amp;Tutorial</source>
        <translation>&amp;Tutorial</translation>
    </message>
    <message>
        <source>Show tutorial page</source>
        <translation>Tampilkan halaman tutorial</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation>Zoom</translation>
    </message>
    <message>
        <source>Zoom &amp;In</source>
        <translation>Perbesar (&amp;I)</translation>
    </message>
    <message>
        <source>&amp;Zoom Out</source>
        <translation>Perkecil (&amp;Z)</translation>
    </message>
    <message>
        <source>&amp;Brightness Contrast</source>
        <translation>Kecerahan Kontras (&amp;B)</translation>
    </message>
    <message>
        <source>Adjust brightness and contrast</source>
        <translation>Atur kecerahan dan kontras</translation>
    </message>
    <message>
        <source>&amp;Edit Label</source>
        <translation>&amp;Edit Label</translation>
    </message>
    <message>
        <source>Save the labels under a new file name</source>
        <translation>Simpan label dengan nama file baru</translation>
    </message>
    <message>
        <source>Modify the label of the selected shape</source>
        <translation>Ubah label bentuk yang dipilih</translation>
    </message>
    <message>
        <source>Copy to Clipboard</source>
        <translation>Salin ke Clipboard</translation>
    </message>
    <message>
        <source>Place the selected shapes on the clipboard</source>
        <translation>Letakkan bentuk terpilih di clipboard</translation>
    </message>
    <message>
        <source>Paste from Clipboard</source>
        <translation>Tempel dari Clipboard</translation>
    </message>
    <message>
        <source>Insert the clipboard shapes into this image</source>
        <translation>Sisipkan bentuk dari clipboard ke gambar ini</translation>
    </message>
    <message>
        <source>Click to place linestrip points; Ctrl+click places the last one.</source>
        <translation>Klik untuk menempatkan titik garis patah; Ctrl+klik menempatkan titik terakhir.</translation>
    </message>
    <message>
        <source>Fit to &amp;Window</source>
        <translation>Sesuaikan Jendela (&amp;W)</translation>
    </message>
    <message>
        <source>Keep the whole image visible when the window is resized</source>
        <translation>Menjaga seluruh gambar tetap terlihat saat ukuran jendela berubah</translation>
    </message>
    <message>
        <source>Fit to Wi&amp;dth</source>
        <translation>Sesuaikan Lebar (&amp;D)</translation>
    </message>
    <message>
        <source>Match the image width to the window when it is resized</source>
        <translation>Menyamakan lebar gambar dengan jendela saat ukurannya berubah</translation>
    </message>
    <message>
        <source>Make the image appear larger</source>
        <translation>Menampilkan gambar lebih besar</translation>
    </message>
    <message>
        <source>Make the image appear smaller</source>
        <translation>Menampilkan gambar lebih kecil</translation>
    </message>
    <message>
        <source>&amp;Actual Size</source>
        <translation>Ukuran &amp;Asli</translation>
    </message>
    <message>
        <source>Show the image at 100%</source>
        <translation>Menampilkan gambar pada 100%</translation>
    </message>
    <message>
        <source>Fill Drawing Polygon</source>
        <translation>Isi Poligon yang Digambar</translation>
    </message>
    <message>
        <source>Fill polygon while drawing</source>
        <translation>Isi poligon saat menggambar</translation>
    </message>
    <message>
        <source>Ctrl+Wheel zooms the canvas</source>
        <translation>Ctrl+Scroll melakukan zoom pada kanvas</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>Berkas (&amp;F)</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>Edit (&amp;E)</translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation>Tampilan (&amp;V)</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>Bantuan (&amp;H)</translation>
    </message>
    <message>
        <source>%s started.</source>
        <translation>%s dimulai.</translation>
    </message>
    <message>
        <source>Mask Output Unavailable</source>
        <translation>Keluaran mask tidak tersedia</translation>
    </message>
    <message>
        <source>%s only detects bounding boxes and cannot create &apos;%s&apos; annotations.

Switch the AI Text-to-Annotation model to &apos;SAM3 (smart)&apos;, or set the output format to &apos;Rectangle&apos;.</source>
        <translation>%s hanya mendeteksi kotak pembatas dan tidak dapat membuat anotasi &apos;%s&apos;.

Ganti model AI Text-to-Annotation ke &apos;SAM3 (smart)&apos;, atau atur format keluaran ke &apos;Rectangle&apos;.</translation>
    </message>
    <message>
        <source>Invalid label</source>
        <translation>Label tidak valid</translation>
    </message>
    <message>
        <source>Invalid label &apos;{}&apos; with validation type &apos;{}&apos;</source>
        <translation>Label &apos;{}&apos; tidak valid dengan tipe validasi &apos;{}&apos;</translation>
    </message>
    <message>
        <source>Error saving label data</source>
        <translation>Error menyimpan data label</translation>
    </message>
    <message>
        <source>&lt;b&gt;%s&lt;/b&gt;</source>
        <translation>&lt;b&gt;%s&lt;/b&gt;</translation>
    </message>
    <message>
        <source>AI inference failed: %s</source>
        <translation>Inferensi AI gagal: %s</translation>
    </message>
    <message>
        <source>Error opening file</source>
        <translation>Error membuka file</translation>
    </message>
    <message>
        <source>No such file: &lt;b&gt;%s&lt;/b&gt;</source>
        <translation>File tidak ditemukan: &lt;b&gt;%s&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Loading %s...</source>
        <translation>Memuat %s...</translation>
    </message>
    <message>
        <source>Loaded %s</source>
        <translation>%s dimuat</translation>
    </message>
    <message>
        <source>Image &amp; Label files (%s)</source>
        <translation>Gambar &amp; File Label (%s)</translation>
    </message>
    <message>
        <source>%s - Choose Image or Label file</source>
        <translation>%s - Pilih File Gambar atau Label</translation>
    </message>
    <message>
        <source>%s - Save/Load Annotations in Directory</source>
        <translation>%s - Simpan/Muat Anotasi di Direktori</translation>
    </message>
    <message>
        <source>%s . Annotations will be saved/loaded in %s</source>
        <translation>%s - Anotasi akan disimpan/dimuat di %s</translation>
    </message>
    <message>
        <source>%s - Choose File</source>
        <translation>%s - Pilih File</translation>
    </message>
    <message>
        <source>Label files (*%s)</source>
        <translation>File label (*%s)</translation>
    </message>
    <message>
        <source>Choose File</source>
        <translation>Pilih File</translation>
    </message>
    <message>
        <source>Attention</source>
        <translation>Perhatian</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Hapus</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Batal</translation>
    </message>
    <message>
        <source>Unavailable in AI-Points mode because this model does not support point prompts.</source>
        <translation>Tidak tersedia dalam mode AI-Points karena model ini tidak mendukung prompt titik.</translation>
    </message>
    <message>
        <source>Save annotations to &quot;{}&quot; before closing?</source>
        <translation>Simpan anotasi ke &quot;{}&quot; sebelum menutup?</translation>
    </message>
    <message>
        <source>Save annotations?</source>
        <translation>Simpan anotasi?</translation>
    </message>
    <message>
        <source>Delete {} shapes? You can restore them with Undo.</source>
        <translation>Hapus {} bentuk? Anda dapat memulihkannya dengan Urungkan.</translation>
    </message>
    <message>
        <source>%s - Open Directory</source>
        <translation>%s - Buka Direktori</translation>
    </message>
    <message>
        <source>The image is too large to open: {width}x{height} pixels exceeds the {max_side} pixel per-side limit of the raster engine. Raising the decode limit will not help. Split the image into tiles (for example with gdal_retile.py) or open a smaller copy.</source>
        <translation>Gambar terlalu besar untuk dibuka: {width}x{height} piksel melebihi batas {max_side} piksel per sisi dari mesin raster. Menaikkan batas dekode tidak akan membantu. Pecah gambar menjadi ubin (misalnya dengan gdal_retile.py) atau buka salinan yang lebih kecil.</translation>
    </message>
    <message>
        <source>The image is too large to open: {width}x{height} pixels needs about {required} MB, but the decode limit is {limit} MB. Split the image into tiles (for example with gdal_retile.py) or open a smaller copy.</source>
        <translation>Gambar terlalu besar untuk dibuka: {width}x{height} piksel membutuhkan sekitar {required} MB, tetapi batas dekode adalah {limit} MB. Pecah gambar menjadi ubin (misalnya dengan gdal_retile.py) atau buka salinan yang lebih kecil.</translation>
    </message>
    <message>
        <source>Toggle &quot;keep previous annotation&quot; mode</source>
        <translation>Aktifkan/nonaktifkan mode &quot;simpan anotasi sebelumnya&quot;</translation>
    </message>
    <message>
        <source>Keep Previous Brightness/Contrast</source>
        <translation>Pertahankan kecerahan/kontras sebelumnya</translation>
    </message>
    <message>
        <source>Configuration Errors</source>
        <translation>Error Konfigurasi</translation>
    </message>
    <message>
        <source>Errors were found while loading the configuration. Please review the errors below and reload your configuration or ignore the erroneous lines.</source>
        <translation>Terjadi error saat memuat konfigurasi. Silakan periksa error di bawah ini dan muat ulang konfigurasi Anda atau abaikan baris yang bermasalah.</translation>
    </message>
    <message>
        <source>Reset Layout</source>
        <translation>Reset Tata Letak</translation>
    </message>
    <message>
        <source>Polygon</source>
        <translation>Poligon</translation>
    </message>
    <message>
        <source>Rectangle</source>
        <translation>Persegi Panjang</translation>
    </message>
    <message>
        <source>Circle</source>
        <translation>Lingkaran</translation>
    </message>
    <message>
        <source>Line</source>
        <translation>Garis</translation>
    </message>
    <message>
        <source>Point</source>
        <translation>Titik</translation>
    </message>
    <message>
        <source>LineStrip</source>
        <translation>Garis Patah</translation>
    </message>
    <message>
        <source>AI-Points</source>
        <translation>AI-Points</translation>
    </message>
    <message>
        <source>Click points to segment object. Ctrl+LeftClick ends creation.</source>
        <translation>Klik titik untuk mensegmentasi objek. Ctrl+Klik Kiri untuk mengakhiri pembuatan.</translation>
    </message>
    <message>
        <source>AI-Box</source>
        <translation>AI-Box</translation>
    </message>
    <message>
        <source>Draw a bounding box to segment object.</source>
        <translation>Gambar bounding box untuk mensegmentasi objek.</translation>
    </message>
    <message>
        <source>AI-Points Unavailable</source>
        <translation>AI-Points tidak tersedia</translation>
    </message>
    <message>
        <source>%s does not support point prompts.
Please select a different model or use AI-Box mode.</source>
        <translation>%s tidak mendukung point prompt.
Silakan pilih model lain atau gunakan mode AI-Box.</translation>
    </message>
    <message>
        <source>File list is disabled when a label file is opened</source>
        <translation>Daftar file dinonaktifkan saat file label dibuka</translation>
    </message>
    <message>
        <source>Add Point to Edge</source>
        <translation>Tambah Titik ke Sisi</translation>
    </message>
    <message>
        <source>Insert a new point at the hovered polygon edge</source>
        <translation>Tambahkan titik baru pada sisi poligon yang ditunjuk</translation>
    </message>
    <message>
        <source>&amp;Keep Previous Zoom</source>
        <translation>Pertahankan Zoom Sebelumnya (&amp;K)</translation>
    </message>
    <message>
        <source>Permanently delete this label file? This action cannot be undone.</source>
        <translation>Hapus permanen file label ini? Tindakan ini tidak dapat dibatalkan.</translation>
    </message>
    <message>
        <source>Allowed formats: {formats}</source>
        <translation>Format yang didukung: {formats}</translation>
    </message>
    <message>
        <source>The selected label file could not be opened: {path}</source>
        <translation>File label yang dipilih tidak dapat dibuka: {path}</translation>
    </message>
    <message>
        <source>The selected image file could not be opened: {path}</source>
        <translation>File gambar yang dipilih tidak dapat dibuka: {path}</translation>
    </message>
    <message>
        <source>Failed to load: {path}</source>
        <translation>Gagal memuat: {path}</translation>
    </message>
    <message>
        <source>Oriented Rectangle</source>
        <translation>Persegi Panjang Berorientasi</translation>
    </message>
    <message>
        <source>Start drawing oriented rectangles</source>
        <translation>Mulai menggambar persegi panjang berorientasi</translation>
    </message>
    <message>
        <source>AI inference produced no new annotation.</source>
        <translation>Inferensi AI tidak menghasilkan anotasi baru.</translation>
    </message>
    <message>
        <source>Shape had no area; nothing created.</source>
        <translation>Bentuk tidak memiliki area; tidak ada yang dibuat.</translation>
    </message>
    <message>
        <source>&amp;Open
</source>
        <translation>Buka (&amp;O)</translation>
    </message>
    <message>
        <source>Undo
</source>
        <translation>Urungkan</translation>
    </message>
    <message>
        <source>&amp;Hide
Shapes</source>
        <translation>Sembunyikan Bentuk (&amp;H)</translation>
    </message>
    <message>
        <source>&amp;Show
Shapes</source>
        <translation>Tampilkan Bentuk (&amp;S)</translation>
    </message>
    <message>
        <source>&amp;Toggle
Shapes</source>
        <translation>Tampilkan/Sembunyikan Bentuk (&amp;T)</translation>
    </message>
    <message>
        <source>Settings…</source>
        <translation>Pengaturan…</translation>
    </message>
    <message>
        <source>Edit settings</source>
        <translation>Edit pengaturan</translation>
    </message>
    <message>
        <source>Settings are managed via --config for this session</source>
        <translation>Pengaturan dikelola melalui --config untuk sesi ini</translation>
    </message>
    <message>
        <source>Configuration Error</source>
        <translation>Error Konfigurasi</translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <source>Settings</source>
        <translation>Pengaturan</translation>
    </message>
    <message>
        <source>Open config file as text…</source>
        <translation>Buka file config sebagai teks…</translation>
    </message>
    <message>
        <source>Edits made in the text file apply after restart</source>
        <translation>Perubahan yang dibuat di file teks akan diterapkan setelah restart</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Tutup</translation>
    </message>
    <message>
        <source>BETA</source>
        <translation>BETA</translation>
    </message>
    <message>
        <source>(none)</source>
        <translation>(tidak ada)</translation>
    </message>
    <message>
        <source>System default</source>
        <translation>Default sistem</translation>
    </message>
    <message>
        <source>one item per line</source>
        <translation>satu item per baris</translation>
    </message>
    <message>
        <source>Configuration Error</source>
        <translation>Error Konfigurasi</translation>
    </message>
    <message>
        <source>Predefined labels cannot be empty while Label validation is set to exact. Disable exact validation first.</source>
        <translation>Label yang telah ditentukan tidak boleh kosong saat validasi label diatur ke &apos;eksak&apos;. Nonaktifkan validasi eksak terlebih dahulu.</translation>
    </message>
    <message>
        <source>Color theme</source>
        <translation>Tema warna</translation>
    </message>
    <message>
        <source>System</source>
        <translation>Sistem</translation>
    </message>
    <message>
        <source>Light</source>
        <translation>Terang</translation>
    </message>
    <message>
        <source>Dark</source>
        <translation>Gelap</translation>
    </message>
    <message>
        <source>Show label popup on new shape</source>
        <translation>Tampilkan popup label pada bentuk baru</translation>
    </message>
    <message>
        <source>Show shape labels on canvas</source>
        <translation>Tampilkan label bentuk pada kanvas</translation>
    </message>
    <message>
        <source>Allow points outside the image boundary</source>
        <translation>Izinkan titik di luar batas gambar</translation>
    </message>
    <message>
        <source>Let shape points extend beyond the image, e.g. for partially visible objects.</source>
        <translation>Memungkinkan titik bentuk melampaui gambar, mis. untuk objek yang terlihat sebagian.</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Bahasa</translation>
    </message>
    <message>
        <source>Appearance and language</source>
        <translation>Tampilan dan bahasa</translation>
    </message>
    <message>
        <source>Files and saving</source>
        <translation>File dan penyimpanan</translation>
    </message>
    <message>
        <source>Drawing and canvas</source>
        <translation>Menggambar dan kanvas</translation>
    </message>
    <message>
        <source>Continue between images</source>
        <translation>Melanjutkan antar gambar</translation>
    </message>
    <message>
        <source>Label sources</source>
        <translation>Sumber label</translation>
    </message>
    <message>
        <source>Label behavior</source>
        <translation>Perilaku label</translation>
    </message>
    <message>
        <source>AI assist</source>
        <translation>Bantuan AI</translation>
    </message>
    <message>
        <source>Takes effect after restart.</source>
        <translation>Berlaku setelah restart.</translation>
    </message>
    <message>
        <source>Save automatically</source>
        <translation>Simpan otomatis</translation>
    </message>
    <message>
        <source>Save image data in label file</source>
        <translation>Simpan data gambar dalam file label</translation>
    </message>
    <message>
        <source>Embeds the image in the label JSON file.</source>
        <translation>Menyematkan gambar dalam file JSON label.</translation>
    </message>
    <message>
        <source>Shape Color Mode</source>
        <translation>Mode Warna Bentuk</translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation>Otomatis</translation>
    </message>
    <message>
        <source>Uniform</source>
        <translation>Seragam</translation>
    </message>
    <message>
        <source>By Label</source>
        <translation>Menurut Label</translation>
    </message>
    <message>
        <source>Automatic palette shift</source>
        <translation>Pergeseran palet otomatis</translation>
    </message>
    <message>
        <source>Uniform mode color</source>
        <translation>Warna mode Seragam</translation>
    </message>
    <message>
        <source>By Label fallback color</source>
        <translation>Warna cadangan mode Menurut Label</translation>
    </message>
    <message>
        <source>Individual Label colors remain editable in the Config File.</source>
        <translation>Warna masing-masing Label tetap dapat diedit di File Konfigurasi.</translation>
    </message>
    <message>
        <source>Keep previous annotation</source>
        <translation>Pertahankan anotasi sebelumnya</translation>
    </message>
    <message>
        <source>Keep previous zoom</source>
        <translation>Pertahankan zoom sebelumnya</translation>
    </message>
    <message>
        <source>Keep previous brightness/contrast</source>
        <translation>Pertahankan kecerahan/kontras sebelumnya</translation>
    </message>
    <message>
        <source>Fill polygon while drawing</source>
        <translation>Isi poligon saat menggambar</translation>
    </message>
    <message>
        <source>Polygon detail</source>
        <translation>Detail poligon</translation>
    </message>
    <message>
        <source>Higher values preserve more Mask boundary detail and smaller lands.</source>
        <translation>Nilai yang lebih tinggi mempertahankan lebih banyak detail batas masker dan area yang lebih kecil.</translation>
    </message>
    <message>
        <source>Predefined labels</source>
        <translation>Label yang telah ditentukan</translation>
    </message>
    <message>
        <source>Label validation</source>
        <translation>Validasi label</translation>
    </message>
    <message>
        <source>Sort labels</source>
        <translation>Urutkan label</translation>
    </message>
    <message>
        <source>Sort the label list alphabetically instead of keeping the provided order.</source>
        <translation>Urutkan daftar label secara alfabetis alih-alih mempertahankan urutan yang diberikan.</translation>
    </message>
    <message>
        <source>Show label text field</source>
        <translation>Tampilkan kolom teks label</translation>
    </message>
    <message>
        <source>Label completion</source>
        <translation>Pelengkapan label</translation>
    </message>
    <message>
        <source>Starts with</source>
        <translation>Dimulai dengan</translation>
    </message>
    <message>
        <source>Contains</source>
        <translation>Berisi</translation>
    </message>
    <message>
        <source>Default model</source>
        <translation>Model default</translation>
    </message>
    <message>
        <source>EfficientSam (speed)</source>
        <translation>EfficientSam (kecepatan)</translation>
    </message>
    <message>
        <source>EfficientSam (accuracy)</source>
        <translation>EfficientSam (akurasi)</translation>
    </message>
    <message>
        <source>Sam (speed)</source>
        <translation>Sam (kecepatan)</translation>
    </message>
    <message>
        <source>Sam (balanced)</source>
        <translation>Sam (seimbang)</translation>
    </message>
    <message>
        <source>Sam (accuracy)</source>
        <translation>Sam (akurasi)</translation>
    </message>
    <message>
        <source>Sam2 (speed)</source>
        <translation>Sam2 (kecepatan)</translation>
    </message>
    <message>
        <source>Sam2 (balanced)</source>
        <translation>Sam2 (seimbang)</translation>
    </message>
    <message>
        <source>Sam2 (accuracy)</source>
        <translation>Sam2 (akurasi)</translation>
    </message>
    <message>
        <source>Sam3</source>
        <translation>Sam3</translation>
    </message>
    <message>
        <source>Suppress existing Shape matches</source>
        <translation>Abaikan kecocokan dengan bentuk yang ada</translation>
    </message>
    <message>
        <source>When an AI Assist candidate matches an existing Shape, highlight that Shape instead of creating a new Shape.</source>
        <translation>Ketika kandidat Bantuan AI cocok dengan bentuk yang ada, bentuk tersebut disorot alih-alih membuat bentuk baru.</translation>
    </message>
    <message>
        <source>Predefined image flags</source>
        <translation>Bendera gambar yang telah ditentukan</translation>
    </message>
</context>
<context>
    <name>_ColorSwatchButton</name>
    <message>
        <source>RGB: {red}, {green}, {blue}</source>
        <translation>RGB: {red}, {green}, {blue}</translation>
    </message>
</context>
<context>
    <name>_SettingsPage</name>
    <message>
        <source>Settings sections</source>
        <translation>Bagian pengaturan</translation>
    </message>
</context>
</TS>
