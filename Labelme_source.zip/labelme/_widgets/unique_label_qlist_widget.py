from __future__ import annotations

from PySide6 import QtGui
from PySide6 import QtWidgets
from PySide6.QtCore import Qt

from .label_list_widget import LABEL_COLOR_ROLE
from .label_list_widget import TrailingColorDotDelegate


class _EscapableQListWidget(QtWidgets.QListWidget):
    def keyPressEvent(self, keyEvent: QtGui.QKeyEvent, /) -> None:
        super().keyPressEvent(keyEvent)
        if keyEvent.key() == Qt.Key.Key_Escape:
            self.clearSelection()


class UniqueLabelQListWidget(_EscapableQListWidget):
    def __init__(self, *, parent: QtWidgets.QWidget | None = None) -> None:
        super().__init__(parent=parent)
        self.setItemDelegate(TrailingColorDotDelegate(parent=self))

    def mousePressEvent(self, mouseEvent: QtGui.QMouseEvent, /) -> None:
        super().mousePressEvent(mouseEvent)
        if not self.indexAt(mouseEvent.position().toPoint()).isValid():
            self.clearSelection()

    def find_label_item(self, *, label: str) -> QtWidgets.QListWidgetItem | None:
        for row in range(self.count()):
            item = self.item(row)
            if item and item.data(Qt.ItemDataRole.UserRole) == label:
                return item
        return None

    def add_label_item(self, *, label: str, color: tuple[int, int, int]) -> None:
        if self.find_label_item(label=label):
            raise ValueError(f"Item for label '{label}' already exists")

        item = QtWidgets.QListWidgetItem()
        item.setData(Qt.ItemDataRole.UserRole, label)  # for find_label_item
        item.setData(LABEL_COLOR_ROLE, QtGui.QColor(*color))
        item.setText(label)
        self.addItem(item)
