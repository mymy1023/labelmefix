# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## Unreleased

<!-- towncrier release notes start -->

## 7.4.1 - 2026-09-03

### Fixed

- Synchronized the status bar with shape creation and editing modes immediately. ([#2521](https://github.com/wkentaro/labelme/pull/2521))
- Fixed the label dialog appearing unnamed to assistive technology; it and its Label, Group ID, and Description editors now expose localized names ([#2522](https://github.com/wkentaro/labelme/pull/2522))
- Fixed the shape-deletion confirmation claiming the deletion could not be undone when Undo restores the shape, its Shape List row, and the saved shape count ([#2535](https://github.com/wkentaro/labelme/pull/2535))
- Clear the label dialog's stale list highlight when the current label is not in the list. ([#2606](https://github.com/wkentaro/labelme/pull/2606))

## 7.4.0 - 2026-09-03

### Changed

- Improved the Label dialog so blank labels cannot be submitted and shared fields can be edited across Shapes with different Labels when validate_label is exact ([#2587](https://github.com/wkentaro/labelme/pull/2587))
- Reworded the LineStrip tooltip to "Click to place linestrip points; Ctrl+click places the last one"; label, shortcut, icon, and behavior are unchanged ([#2595](https://github.com/wkentaro/labelme/pull/2595))
- Polygon, linestrip, and AI-Points clicks share one canvas handler; Ctrl+Shift+click now also places the last linestrip point, matching AI-Points ([#2596](https://github.com/wkentaro/labelme/pull/2596))

### Fixed

- Prevent a crash when resizing the window after closing an image in Fit to Window or Fit to Width mode. ([#2603](https://github.com/wkentaro/labelme/pull/2603))
- Fixed **Keep Previous Scale** restoring stale per-Image viewports during navigation. ([#2604](https://github.com/wkentaro/labelme/pull/2604))

## 7.3.0 - 2026-09-02

### Changed

- Renamed the View-menu actions Original Size, Fit Window, and Fit Width to Actual Size, Fit to Window, and Fit to Width, and reworded the zoom tooltips to describe the effect on the displayed image; shortcuts and behavior are unchanged ([#2580](https://github.com/wkentaro/labelme/pull/2580))
- Renamed the "Copy Shapes" and "Paste Shapes" actions to "Copy to Clipboard" and "Paste from Clipboard", and regrouped the Edit menu and canvas context menu so Undo, clipboard, and shape-editing actions sit in separate sections ([#2582](https://github.com/wkentaro/labelme/pull/2582))
- Reworded the Save As tooltip to "Save the labels under a new file name" so it no longer reads like the Save tooltip; label, shortcut, icon, and behavior are unchanged ([#2584](https://github.com/wkentaro/labelme/pull/2584))
- The Brightness/Contrast dialog applies adjustments with lookup tables while preserving prior rendering and transparency, and shows each slider value as a percentage ([#2585](https://github.com/wkentaro/labelme/pull/2585))
- Shape labels shown on the canvas now include their group ID, matching the Shape List ([#2589](https://github.com/wkentaro/labelme/pull/2589))
- The dock listing the current Image's Shapes is now titled Shape List. ([#2593](https://github.com/wkentaro/labelme/pull/2593))

## 7.2.0 - 2026-08-27

### Added

- Added Shape Color controls to Settings for automatic, uniform, and per-Label fallback coloring. ([#2552](https://github.com/wkentaro/labelme/pull/2552))

### Changed

- Improved AI Assist polygon output with cleaner boundaries, grouped disconnected lands, and adjustable detail. ([#2555](https://github.com/wkentaro/labelme/pull/2555))

### Fixed

- Fixed Undo appearing enabled immediately after opening an image whose Shapes were carried forward via Keep Previous Annotation / Ctrl+Shift, which could silently discard the carried-forward Shapes if clicked before any edit on the new image ([#2523](https://github.com/wkentaro/labelme/pull/2523))
- Fixed Undo remaining disabled after committing the first Shape on a raw Image. Undo now removes that Shape from the canvas, Annotation List, and both manually saved and auto-saved Annotation Files ([#2523](https://github.com/wkentaro/labelme/pull/2523))
- Kept the image point beneath the cursor stationary during Ctrl/Cmd-wheel zoom without canvas flicker. ([#2553](https://github.com/wkentaro/labelme/pull/2553))
- Fixed `labelme --help` showing a Python executable and temporary launcher path instead of the stable `labelme` command on Windows with Python 3.14. ([#2559](https://github.com/wkentaro/labelme/pull/2559))

## 7.1.0 - 2026-08-21

### Added

- Expanded the Settings dialog with a scrollable page of workflow-oriented groups, an icon-labeled section index for quick navigation, and explanatory descriptions, so that auto-save, saving image data, keep-previous annotation/zoom/brightness-contrast, fill-drawing, label sorting/completion/text-field behavior, and the default AI model can all be changed in-app with immediate apply, instead of requiring hand-editing the config file ([#2403](https://github.com/wkentaro/labelme/pull/2403))

### Changed

- Changed the Settings dialog to keep a stable, resizable window size, with scrolling when the available height cannot fit its content ([#2403](https://github.com/wkentaro/labelme/pull/2403))
- Grouped Shape coloring under one `shape_color` setting with explicit `auto`, `uniform`, and `by_label` modes, replacing the loosely coupled `default_shape_color`, `shift_auto_shape_color`, and `label_colors` keys. Existing Config Files and inline `--config` values are migrated in memory, preserving their behavior and override precedence ([#2426](https://github.com/wkentaro/labelme/pull/2426))
- Replaced the zoom control's "What's This" help with a plain hover tooltip naming the `Ctrl+Wheel` canvas zoom shortcut. The old text was reachable only by giving the toolbar zoom box keyboard focus and pressing Shift+F1 (no menu entry, no `?` button), and the zoom key bindings it listed are already shown next to Zoom In/Zoom Out in the View menu ([#2443](https://github.com/wkentaro/labelme/pull/2443))
- Changed the release workflow to publish PEP 440 prerelease tags to PyPI with the current Unreleased notes and mark their GitHub releases as prereleases, while stable tags continue to use their exact version sections ([#2469](https://github.com/wkentaro/labelme/pull/2469))

### Removed

- Removed the `logger_level` config key, which had no effect: log verbosity has always been controlled solely by the `--logger-level` CLI flag. A `logger_level` entry remaining in an existing `~/.labelmerc` is dropped on load, so old config files keep working unchanged ([#2402](https://github.com/wkentaro/labelme/pull/2402))

### Fixed

- Fixed clicking or hovering near a linestrip's unrendered "closing" line (the straight path from its last point back to its first) being treated as a hit on the shape; edge hover, add-point-to-edge, and body selection now ignore that phantom segment, since a linestrip is an open polyline and never draws it ([#2307](https://github.com/wkentaro/labelme/pull/2307))
- Fixed the `--output` guard rejecting only lowercase `.json` paths; an upper- or mixed-case file path such as `--output notes.JSON` slipped past the "expects a directory" check and was treated as an output directory. The guard now reuses the canonical case-insensitive `is_label_file_path` helper ([#2317](https://github.com/wkentaro/labelme/pull/2317))
- Fixed `read_label_file` accepting boolean values where a shape's `group_id` or point coordinates were expected in an annotation file; because `bool` is a subclass of `int`, a hand-edited or third-party `"group_id": true` (or a `true`/`false` inside `points`) slipped past the int/number checks and loaded as a group identifier or coordinate, so booleans are now rejected with the same clear read error as any other bad value ([#2323](https://github.com/wkentaro/labelme/pull/2323))
- Fixed the AI-model download progress dialog formatting sizes incorrectly: multi-GB models (e.g. SAM ~1.7 GB) showed as thousands of MB, and byte counts just under a unit boundary rolled up to `1024 KB`/`1024.0 MB` instead of `1.0 MB`/`1.0 GB`; sizes now use a GB tier and rounding-safe unit boundaries ([#2324](https://github.com/wkentaro/labelme/pull/2324))
- Fixed `shapes_to_label` mishandling a `mask` shape whose bounding box extends past the image edge; a negative corner silently wrapped the patch onto the opposite edge and a right/bottom overflow raised a `ValueError` broadcast error, so the destination rectangle (and matching sub-slice of the mask) is now clipped to the image canvas, as ADR 0004 requires for out-of-bounds points ([#2327](https://github.com/wkentaro/labelme/pull/2327))
- Fixed the application window/taskbar icon silently falling back to a blank icon; the startup call still requested `icons/icon.png`, which was removed when its PyInstaller-hostile symlink was deleted, so it now loads the real `icons/icon-256.png` (matching the documented PyInstaller build), and the `new_icon` tests now assert the icon is non-null so a missing icon file fails loudly ([#2338](https://github.com/wkentaro/labelme/pull/2338))
- Fixed a crash when opening a palette-mode (`P`/`PA`) image, such as a GIF, palette BMP/PNG, or palette TIFF whose bytes need re-encoding (any non-jpg/png extension, or an EXIF-oriented file); the re-encode path picked a format Pillow cannot write the palette mode in (`OSError: cannot write mode P as JPEG` / `cannot write mode PA as PNG`), so every such image crashed. A non-transparent palette image is now converted to `RGB` before the JPEG save, a `P` image carrying index-based transparency is routed to PNG so its transparency is preserved, and a `PA` image (palette + alpha) is converted to `RGBA` before the PNG save ([#2340](https://github.com/wkentaro/labelme/pull/2340))
- Fixed the outline of a Mask shape being drawn one pixel down-and-right of its filled pixels; the contour is traced on a 1-pixel-padded copy of the mask (so a region touching the border still closes), but that padding offset was never subtracted before positioning the stroke, unlike the polygon path that shares the same trick, so the outline now aligns with the fill it encloses ([#2341](https://github.com/wkentaro/labelme/pull/2341))
- Fixed a startup crash (`OSError: [Errno 36] File name too long`) when a `--labels`, `--flags`, `--label-flags`, or `--config` value is longer than the filesystem's filename limit (reachable with a few dozen inline comma-separated labels); these options probe whether the value names an existing file via `Path(value).is_file()`, which raised instead of returning `False` on an over-length value, so the value is now treated as inline data as intended ([#2345](https://github.com/wkentaro/labelme/pull/2345))
- Fixed the config `labels` key silently accepting a scalar string such as `labels: cat` instead of a list; the value was truthy and passed the duplicate check, so `config["labels"]` became the string `"cat"` and was later iterated character by character (`c`, `a`, `t`). A non-list `labels` value now surfaces as a clear configuration error instead ([#2348](https://github.com/wkentaro/labelme/pull/2348))
- Fixed a crash when a `label_flags` config entry contains a pattern that is not a usable regular expression, either an invalid one (e.g. `person-(`) or a non-string one (e.g. the unquoted numeric key in `2024: [occluded]`, which YAML parses as an int); such a pattern raised an uncaught `re.error` or `TypeError` when loading a labeled shape or typing in the label dialog, and is now skipped instead, with a warning logged naming the offending pattern ([#2350](https://github.com/wkentaro/labelme/pull/2350))
- Fixed a non-string `ai.default` (e.g. `ai:\n  default: true`) making the whole config unloadable: the old-model-name migration passed the value straight to `re.match`, raising `TypeError: expected string or bytes-like object`, so the config-error backstop discarded every other setting in the file and fell back to defaults. The migration now only runs on a string value, matching the `shortcuts` guard beside it, so the rest of the config is honored and an unusable `ai.default` degrades to the AI model widget's existing logged warning ([#2358](https://github.com/wkentaro/labelme/pull/2358))
- Fixed Delete File and the Delete-File action state ignoring where the annotation actually lives; `current_label_file_path` always recomputed an image-adjacent `.json` path, so with an output directory set (`--output` / Change Output Dir) the action could stay wrongly disabled or delete a stale image-adjacent file while leaving the saved annotation untouched. It now returns the loaded/saved label file, falling back to the output-dir-aware `_resolve_label_path` when none exists yet ([#2360](https://github.com/wkentaro/labelme/pull/2360))
- Fixed unsaved annotations being discarded when the user chose "Save" in the close/switch prompt but the save did not complete (a cancelled Save-As dialog, or a failed write); the app now only proceeds when the file is actually clean, so it keeps the window open instead of silently losing the annotations ([#2361](https://github.com/wkentaro/labelme/pull/2361))
- Fixed a shape vertex dragged out past an image corner staying frozen at the corner's x when the cursor kept moving sideways above or below the image; with out-of-bounds points disabled (the default) it now slides along the top or bottom edge under the cursor, because the out-of-bounds clip picks the edge from the axis the drag actually exits through rather than from the vertex's corner position ([#2364](https://github.com/wkentaro/labelme/pull/2364))
- Fixed the configured `ai.default` model not being applied at startup when it resolves to the first list entry, i.e. when it is set to `EfficientSam (speed)` or to an unrecognized value (which falls back to that entry): the AI-Assisted Annotation panel only pushed its selection to the canvas on `currentIndexChanged`, which never fires for the already-selected index 0, so the panel showed the chosen model while the canvas silently kept the hardcoded `sam2:latest` until the model was toggled by hand. The canvas is now initialized from the panel's resolved selection (model and output format) instead of waiting for a change signal ([#2403](https://github.com/wkentaro/labelme/pull/2403)) ([#2370](https://github.com/wkentaro/labelme/pull/2370))
- Fixed `read_label_file` accepting a non-integer top-level `imageHeight` or `imageWidth` in an annotation file; the dimension check compared with `!=`, so a boolean `true`/`false` (which subclasses `int`) or a float slipped through whenever it happened to equal the real dimension, and now these fields are validated as `int` and rejected with a clear read error ([#2374](https://github.com/wkentaro/labelme/pull/2374))
- Fixed a naturally-spaced `--labels`/`--flags` comma list such as `--labels "cat, dog, person"` registering labels with leading spaces (`" dog"`, `" person"`); the inline comma-split branch now strips whitespace around each entry and drops blank entries, matching the file-reading branch's existing convention, so a later `--validate-label exact` no longer rejects `"dog"` because the registered label was actually `" dog"` ([#2383](https://github.com/wkentaro/labelme/pull/2383))
- Fixed a startup crash when loading the config raised anything other than `ValueError`, such as a malformed `~/.labelmerc` or `--config` file with ungrammatical YAML (a `yaml` parser error); `MainWindow._load_config` caught only `ValueError`, so every other error crashed before the window opened. It now catches any such error, surfaces it in the configuration-error dialog (with an Ignore-and-use-defaults option), and falls back to defaults ([#2384](https://github.com/wkentaro/labelme/pull/2384))
- Fixed a pre-6.1.0 config file triggering the "Unexpected key in config" configuration-error dialog on startup because of the `canvas.crosshair.ai_polygon` / `canvas.crosshair.ai_mask` keys, which were consolidated into `canvas.crosshair.ai_points_to_shape` in v6.1.0; the legacy keys are now migrated during config loading (folded into `ai_points_to_shape` as the logical OR of the two old values, with an explicit `ai_points_to_shape` taking precedence) like the other renamed keys ([#2391](https://github.com/wkentaro/labelme/pull/2391))
- Fixed the app crashing when saving a label file failed on a raw filesystem error rather than a wrapped `LabelFileError`; `save_labels` created the output directory (`Path.mkdir`) and computed the image's relative path inside its `try` but caught only `LabelFileError`, so a read-only or full `--output` directory (`PermissionError`/`OSError`) or another raw `ValueError` escaped uncaught and took the whole app down through the global exception hook, including during auto-save. These are now caught like the existing write failures, surfacing the save-error dialog and returning `False` ([#2393](https://github.com/wkentaro/labelme/pull/2393))
- Fixed `labelme --logger-level fatal` crashing on startup with an unhandled `ValueError: Level 'FATAL' does not exist`; `fatal` was an advertised `--logger-level` choice but loguru has no such level, so the value was replaced with loguru's real `critical` level (matching the `QtFatalMsg -> "CRITICAL"` mapping already used for Qt logging) ([#2399](https://github.com/wkentaro/labelme/pull/2399))
- Fixed the Zoom In and Zoom Out toolbar/menu icons being swapped: Zoom In (which increases the zoom level) showed a magnifier with a minus glyph and Zoom Out (which decreases it) showed a magnifier with a plus glyph, backwards from convention and from what the actions do; the two icons are now assigned to match their actions ([#2401](https://github.com/wkentaro/labelme/pull/2401))
- Fixed the Brightness/Contrast dialog's `Brightness:` and `Contrast:` slider labels rendering in English under every one of the 20 bundled locales, even though the dialog's own title was translated; the two labels reached `self.tr()` through a loop variable instead of as string literals, and `pyside6-lupdate` only extracts literals, so neither string was ever written into a translation catalog. They are now literal `self.tr(...)` calls and are translated for all 20 locales, and the two slider rows moved to a grid layout so a longer translated label sizes the column instead of being clipped by the previous hardcoded 75px label width ([#2405](https://github.com/wkentaro/labelme/pull/2405))
- Fixed opening an image too large for Qt to decode reporting the misleading "Allowed formats" unsupported-format message; the dialog now states that the image is too large, shows its pixel dimensions and the ceiling that was actually hit (the decode allocation limit, or the raster engine's ~32767 pixel per-side limit, which no amount of raising the allocation limit can lift), and suggests tiling with `gdal_retile.py` or opening a smaller copy ([#2417](https://github.com/wkentaro/labelme/pull/2417))
- Fixed labelme refusing to start (exiting with status 1 and `Config file does not exist`) when `~/.labelmerc` does not exist and could not be created, such as on a read-only or otherwise unwritable home directory; the auto-discovered config path was the default value of `--config`, so a missing one was treated like an explicitly requested file that is missing. A missing file is now fatal only when it was explicitly passed via `--config`, while a missing default path logs a warning and starts on the built-in default settings ([#2421](https://github.com/wkentaro/labelme/pull/2421))
- Fixed a config file that carries both an old polygon-named shortcut and its renamed replacement (such as `edit_polygon` alongside `edit_shape`) triggering the "Unexpected key in config" configuration-error dialog on startup; the polygon -> shape shortcut migration renamed an old key only when the new key was absent, so in the both-present case the stale key survived the migration and the whole config was then rejected in favor of the defaults, discarding every other setting in the file. The stale key is now always dropped, an existing new key still wins, and the discarded binding is logged so it is visible ([#2423](https://github.com/wkentaro/labelme/pull/2423))
- Fixed the label dialog silently discarding a shape flag's checked state when two `label_flags` patterns matching the same label both name that flag (for example a catch-all `".*": [occluded]` alongside `"^cat$": [occluded, urgent]`); the dialog built one checkbox per pattern match rather than per flag, so the duplicate boxes overwrote each other on OK and the user's tick was lost. Each flag now gets exactly one checkbox, following the same keyed-by-flag-name dedup the annotation-loading path already applies to these patterns ([#2424](https://github.com/wkentaro/labelme/pull/2424))
- Fixed a startup crash (`PermissionError`) when the log file could not be set up, such as a read-only home directory in a container where `~/.cache` cannot be created, or an existing but unwritable `~/.cache/labelme`; the log file is now best-effort, so a failure to resolve the cache directory (including an unset `LOCALAPPDATA` on Windows, or a home directory that cannot be determined at all), create it, or register the file sink logs a warning and labelme keeps starting with the stderr logging that is already in place ([#2425](https://github.com/wkentaro/labelme/pull/2425))
- Fixed the label dialog's whole flag area disappearing whenever the checkboxes were rebuilt while the dialog was open, such as picking another label in the dialog's label list or editing the label text; the flags stayed set but could neither be seen nor edited for the rest of the popup. The flag area was sized from its container's layout, which reports an empty size for the checkboxes added while the dialog is visible (they stay hidden until the event loop next activates the layout), so the area was pinned to zero height. The checkboxes are now shown as they are added, so the size is measured from the real content ([#2428](https://github.com/wkentaro/labelme/pull/2428))
- Fixed the label dialog silently clearing the ticked label flags whenever the label text is edited. The checked state lived only in the checkbox widgets, which are destroyed and rebuilt on every keystroke, so any intermediate text matching no `label_flags` pattern lost it for good. Because the dialog selects the existing label on open, the first keystroke replaces the whole text and drops it through such an intermediate: retyping the same label, or changing it to another label the same pattern covers, came back with every flag unticked. The checked state is now remembered per flag key for the lifetime of one popup and restored whenever that key reappears, while still resetting between popups ([#2428](https://github.com/wkentaro/labelme/pull/2428))
- Fixed the label popup opening over a stale canvas after an AI-Box annotation, so the shape being labeled was invisible: the canvas still showed the drag bbox rubber band instead of the segmentation result, because the newly committed shape was only scheduled for repaint after the modal dialog had already taken over. The canvas now paints the committed shape before notifying, so the dialog opens on top of the annotation it is asking about ([#2429](https://github.com/wkentaro/labelme/pull/2429))
- Fixed the arrow keys navigating only a single file in the File List: loading an image always moved keyboard focus to the canvas, so the keypress after the first was delivered to the canvas and the selection stopped moving. A load now leaves the keyboard in the File List whenever the File List is what has it, so the arrow keys walk the list as expected; loading from anywhere else (opening a file or directory, or the `A`/`D` shortcuts while the canvas has focus) still hands the canvas the keyboard as before ([#2434](https://github.com/wkentaro/labelme/pull/2434))
- Fixed a selected label in the Annotation List rendering white-on-pale-gray, and so being unreadable, whenever the list did not hold keyboard focus (most commonly right after selecting a shape on the canvas, which leaves focus on the canvas). The custom HTML delegate bypassed Qt's text renderer and hardcoded the palette's `Active` group. Labels are now stored as plain text and painted through Qt's stock item-view style, and the delegate itself draws only the trailing label-color dot. This preserves the dot's position after the label and lets Qt handle focused, unfocused, disabled, light-theme, and dark-theme text colors ([#2436](https://github.com/wkentaro/labelme/pull/2436))
- Fixed AI-Points mode allowing SAM3 to start unsupported point-prompt inference, which wasted time extracting image features before failing and displayed the prompt draft as a prediction ([#2437](https://github.com/wkentaro/labelme/pull/2437))
- Fixed AI Assist interactions appearing to return nothing when every predicted Shape matched an existing Shape. Predictions now become new Shapes by default. The new disabled-by-default Existing Shape Suppression Setting can instead highlight matching existing Shapes while adding unmatched predictions normally. Point prompts choose the candidate that best satisfies their positive and negative points ([#2444](https://github.com/wkentaro/labelme/pull/2444))
- Fixed AI-Points Prompt Compatibility checks depending on mode navigation, which missed incompatible runtime states caused by startup, restored state, or Settings changes. AI-Points now keeps the selected model Setting and rejects an unsupported SAM3 point prompt before model download or inference ([#2448](https://github.com/wkentaro/labelme/pull/2448))
- Fixed Mask Shape construction for Model Session detections with fractional bounding boxes by using the same rounding for Shape points and Mask extents, preventing placement drift and Existing Shape Suppression errors ([#2464](https://github.com/wkentaro/labelme/pull/2464))
- Fixed AI Assist and AI Text Prompt passing images to vision models in BGR channel order, which swapped red and blue. Qt images are now converted to RGB before inference ([#2466](https://github.com/wkentaro/labelme/pull/2466))
- Fixed a failed Image load blanking the current session; the last good Image, Annotation, canvas, and File List selection now stay active, and an invalid adjacent Annotation File still blocks its Image from opening ([#2454](https://github.com/wkentaro/labelme/issues/2454)) ([#2468](https://github.com/wkentaro/labelme/pull/2468))
- Fixed failed auto-saves leaving an edited Annotation marked clean. The dirty title, Save action, and unsaved-changes prompt now remain active, while repeated failures for the same target show only one error until a save succeeds or the target changes ([#2472](https://github.com/wkentaro/labelme/pull/2472))
- Fixed malformed Annotation Files with unsupported Shape types, invalid geometry, or inconsistent Mask data reaching GUI Shape construction and causing an application failure. The reader now rejects the full Annotation before installing any Shapes and reports the file plus the indexed field that failed validation ([#2473](https://github.com/wkentaro/labelme/pull/2473))
- Fixed File List search rescanning the directory and changing the active Image when the search text changed. Search now filters the loaded Images in memory, so a dirty Annotation stays active without a save or discard prompt, and clearing the search restores the full File List and its active-Image selection ([#2474](https://github.com/wkentaro/labelme/pull/2474))
- Fixed enabling auto-save on an already modified Annotation leaving the window dirty after the next successful auto-save, which kept the Save action and modified title marker active and prompted to save again when closing ([#2475](https://github.com/wkentaro/labelme/pull/2475))
- Fixed whole-Shape dragging and keyboard nudging that used stale mouse and drag-anchor state. Clickless selections now move in every direction and stop at the Image bounds, oversized Shapes use symmetric bounds instead of reversing direction, and degenerate oriented-rectangle corner drags stay inside the Image when out-of-bounds points are disabled ([#2398](https://github.com/wkentaro/labelme/issues/2398), [#2375](https://github.com/wkentaro/labelme/issues/2375), [#2365](https://github.com/wkentaro/labelme/issues/2365)) ([#2476](https://github.com/wkentaro/labelme/pull/2476))
- Fixed failed Annotation File saves truncating the last good file. Saves now write and close a temporary file in the target directory before replacing the destination, and failed saves remove the temporary file ([#2477](https://github.com/wkentaro/labelme/pull/2477))
- Fixed a cancelled close still overwriting the Window State (window size, position, and dock layout); `closeEvent` ignored the close event but kept going, so cancelling the unsaved-changes prompt saved the current geometry anyway and the next session started from a layout the user never closed on. The Window State is now written only when the close goes through ([#2478](https://github.com/wkentaro/labelme/pull/2478))
- Fixed Keep Previous Zoom preserving the scale while resetting the viewport position on each newly opened image. It now carries the previous horizontal and vertical scroll positions forward, while still restoring an image's own saved viewport when revisiting it ([#2484](https://github.com/wkentaro/labelme/pull/2484))
- Fixed saving an annotation failing with an error dialog on Windows when the image and the label file live on different drives, because no relative `imagePath` exists between two drives. Such a save now stores an absolute `imagePath`, which reopens on the machine that wrote it but does not survive moving the files elsewhere; every other save keeps the relative `imagePath` ([#1350](https://github.com/wkentaro/labelme/issues/1350)) ([#2496](https://github.com/wkentaro/labelme/pull/2496))
- Fixed dropped image files entering the File List with forward slashes on Windows; `QUrl` reports a dropped path with forward slashes while every other path in the File List carries the separator of the platform, so the same image could be listed twice once its directory was also opened ([#2497](https://github.com/wkentaro/labelme/pull/2497))
- Fixed images opened through the file dialog on Windows neither selecting their File List row nor receiving the saved checkmark; Qt file dialogs report a chosen path with forward slashes while the File List carries the separator of the platform, and both lookups compare exact strings ([#2499](https://github.com/wkentaro/labelme/pull/2499))
- Fixed exported Mask Shapes with fractional bounds being shifted by integer truncation instead of matching their canvas position ([#2504](https://github.com/wkentaro/labelme/pull/2504))
- Fixed AI Assist and AI Text Prompt oriented-rectangle Shapes extending beyond the Image when out-of-bounds points are disabled. Edge-crossing fits now use an in-bounds axis-aligned rectangle, while enabling out-of-bounds points preserves the original vertices ([#2512](https://github.com/wkentaro/labelme/pull/2512)) ([#2506](https://github.com/wkentaro/labelme/pull/2506))

## 7.0.4 - 2026-07-12

### Fixed

- Fixed AI Assist / AI Box crashing with `ValueError: incorrect coordinate type` when suppressing detections that overlap an existing polygon or oriented-rectangle shape on Pillow older than 11.2.1; the overlap check rasterized the existing shape by passing a list-of-lists (`ndarray.tolist()`) to `PIL.ImageDraw.polygon`, which older Pillow rejects, so it now passes the documented list-of-tuples form as elsewhere in the codebase ([#2331](https://github.com/wkentaro/labelme/pull/2331))

## 7.0.3 - 2026-07-11

### Fixed

- Fixed a crash when registering a shape after deleting one via the annotation-list context menu (`RuntimeError: Internal C++ object (LabelListWidgetItem) already deleted`); the list snapshots the selection on mouse press to support multi-selection checkbox toggles, and a context menu or drag can consume the matching release, so the snapshot outlived deleted items and is now tracked with persistent model indexes that drop removed rows ([#2318](https://github.com/wkentaro/labelme/pull/2318))
- Fixed `read_label_file` silently accepting a non-dict image-level `flags` value in an annotation file; the top-level flags are now validated as a `dict[str, bool]` on load, exactly as per-shape flags already were, so a malformed file surfaces a clear read error instead of loading a bad value that crashes later ([#2305](https://github.com/wkentaro/labelme/pull/2305))
- Fixed AI Assist / AI Text Prompt in polygon output mode emitting a degenerate 2-point "polygon" for thin, near-collinear detections; such a shape is not a valid polygon and later crashed mask conversion (`shape_to_mask` asserts more than 2 points), so it is now dropped like other empty detections ([#2298](https://github.com/wkentaro/labelme/pull/2298))
- Fixed two warning log messages rendering literal `%r`/`%d` placeholders instead of their values (the no-op point-removal warning and the empty save-path warning); loguru formats with brace-style placeholders, so the diagnostic values were silently dropped ([#2293](https://github.com/wkentaro/labelme/pull/2293))
- Fixed a startup crash when the config file contains an empty section such as a bare `shortcuts:` or `ai:`; empty sections now keep their defaults instead of raising an uncaught `AttributeError` ([#2295](https://github.com/wkentaro/labelme/pull/2295))
- Fixed a startup crash when a config section is set to a non-mapping value such as `shortcuts: oops`; the malformed section now surfaces in the configuration-error dialog (with an Ignore-and-use-defaults option) instead of crashing ([#2300](https://github.com/wkentaro/labelme/pull/2300))
- Fixed noisy Qt log lines flooding the terminal (notably the macOS per-keypress `qt.qpa.keymapper: Mismatch between Cocoa and Carbon` warning); Qt logging is now routed through the app logger with these harmless lines filtered out while genuine Qt warnings still surface ([#2292](https://github.com/wkentaro/labelme/pull/2292))

## 7.0.2 - 2026-07-03

### Fixed

- Fixed Undo (Ctrl+Z) not triggering auto-save; undoing a shape edit now marks the file dirty, so with auto-save on the restored state is written to disk instead of leaving the previous edit saved ([#2288](https://github.com/wkentaro/labelme/pull/2288))

## 7.0.1 - 2026-07-03

### Changed

- Changed the label dialog popup to anchor its content corner at the cursor; previously the window frame was anchored there, leaving the content a title-bar height below the pointer ([#2286](https://github.com/wkentaro/labelme/pull/2286))

### Fixed

- Fixed the label dialog visibly jumping right after opening; the post-show screen-edge correction now only nudges the dialog when it actually overflows the screen ([#2286](https://github.com/wkentaro/labelme/pull/2286))

## 7.0.0 - 2026-07-03

### Added

- Added a user-selectable color theme (System / Light / Dark) in the Settings dialog; System follows the OS appearance, and Dark mode is now supported where the app previously forced light mode ([#2260](https://github.com/wkentaro/labelme/pull/2260))
- Added support for placing annotation points outside the image boundary ([#2223](https://github.com/wkentaro/labelme/pull/2223))
- Added a schema-driven Settings dialog (replaces the "open YAML in editor" preference), with immediate live-apply and comment-preserving writes to ~/.labelmerc ([#2120](https://github.com/wkentaro/labelme/pull/2120))
- Added a Language picker to the Settings dialog so the UI language can be changed without editing the config file ([#2140](https://github.com/wkentaro/labelme/pull/2140))
- Added a `show_labels` toggle in Settings to draw each shape's label text on the canvas at its top-left anchor, live-applied without restart ([#2182](https://github.com/wkentaro/labelme/pull/2182))
- Added a BETA badge in the Settings dialog beside preview features (Show shape labels on canvas, Allow points outside the image boundary) to signal they are shipped for early use and to invite issue reports ([#2275](https://github.com/wkentaro/labelme/pull/2275))
- Added image flags to the Settings dialog with live dock refresh — newly added flags appear without reloading the image ([#2169](https://github.com/wkentaro/labelme/pull/2169))
- Added inline display of enabled shape flags in the annotation list (e.g. `car [occluded, truncated]`) so the full annotation state is visible at a glance ([#2134](https://github.com/wkentaro/labelme/pull/2134))
- Added Indonesian (id_ID) localization ([#2143](https://github.com/wkentaro/labelme/pull/2143))
- Added 0.1% precision to the zoom widget (e.g. `150.5 %`) for smoother stepping on large images ([#2165](https://github.com/wkentaro/labelme/pull/2165))

### Changed

- **Breaking:** Migrated the GUI from PyQt5 (Qt5) to PySide6 (Qt6) ([#2158](https://github.com/wkentaro/labelme/pull/2158))
- **Breaking:** Dropped Python 3.10 and 3.11 support; the minimum is now Python 3.12, following SPEC 0 now that numpy and scipy require 3.12. Users on 3.10 or 3.11 should stay on the v6.3.x maintenance line ([#2218](https://github.com/wkentaro/labelme/pull/2218), [#2280](https://github.com/wkentaro/labelme/pull/2280))
- **Breaking:** Privatized the Python import surface — `labelme.app`, `labelme.utils`, and `labelme.widgets` moved to `labelme._app`, `labelme._utils`, and `labelme._widgets`; labelme no longer exposes a supported Python API (use the CLI and the JSON label format) ([#2253](https://github.com/wkentaro/labelme/pull/2253))
- Fixed `UnicodeEncodeError` on non-UTF-8 locales (e.g. Windows cp1252) when labels contain non-ASCII characters by always reading and writing the config file in UTF-8 encoding ([#2136](https://github.com/wkentaro/labelme/pull/2136))
- **Breaking:** Switched config file parsing from PyYAML to ruamel.yaml; comments and formatting in `~/.labelmerc` are now preserved across Settings edits. Note: YAML 1.2 is now used, so boolean spellings `yes`/`no`/`on`/`off` are read as strings rather than booleans ([#2114](https://github.com/wkentaro/labelme/pull/2114))
- Changed the delete confirmation dialog to default to Cancel (not Delete) and use verb labels (Delete / Cancel) to reduce accidental data loss ([#2197](https://github.com/wkentaro/labelme/pull/2197))
- Updated predefined labels in the label dialog in place when changed via Settings, preserving labels typed during the current session ([#2164](https://github.com/wkentaro/labelme/pull/2164))
- Changed point shapes to be selected by clicking the marker as a whole rather than grabbing its single vertex ([#2158](https://github.com/wkentaro/labelme/pull/2158))

### Removed

- **Breaking:** Removed the public `LabelFile` class (`labelme.LabelFile`); use the `read_label_file` / `write_label_file` functions and the `LabelFileError` hierarchy in `labelme._label_file` instead ([#2246](https://github.com/wkentaro/labelme/pull/2246))
- **Breaking:** Removed the deprecated `labelme.utils` compatibility shims: `labelme.utils.lblsave` (use `imgviz.io.lblsave`) and the camelCase aliases `addActions`, `distancetoline`, `fmtShortcut`, `labelValidator`, `newAction`, `newButton`, `newIcon` (use their snake_case names). The `from labelme import utils` top-level re-export is also dropped ([#2249](https://github.com/wkentaro/labelme/pull/2249))
- **Breaking:** Removed the deprecated `--autosave` and `--nodata` CLI flags; use `--no-auto-save` and `--with-image-data` instead. The remaining legacy aliases `--nosortlabels`, `--labelflags`, and `--validatelabel` now emit a `FutureWarning` ([#2245](https://github.com/wkentaro/labelme/pull/2245))

### Fixed

- Fixed a hidden shape staying hover-interactive (highlight, cursor, click-to-select) when it was the hovered shape at the moment it was hidden ([#2276](https://github.com/wkentaro/labelme/pull/2276))
- Fixed the standalone-executable build instructions forcing `numpy<2.0` (a stale PyQt5-era PyInstaller workaround), which broke builds on Python 3.12+ where numpy 2.x is the default ([#2279](https://github.com/wkentaro/labelme/pull/2279))
- Fixed annotation label text being clipped or invisible in the label list on some desktop styles (e.g. GNOME/Adwaita) by widening the delegate's text clip rect to the rendered width ([#2273](https://github.com/wkentaro/labelme/pull/2273))
- Fixed `line` and two-point `linestrip` shapes being unselectable by click ([#2107](https://github.com/wkentaro/labelme/pull/2107))
- Fixed the canvas going blank after "Delete File" (Delete File now removes only the label JSON and keeps the image on screen) ([#2138](https://github.com/wkentaro/labelme/pull/2138))
- Fixed notch artifacts at interior vertices of linestrip masks by using PIL's `joint="curve"` rasterization ([#2163](https://github.com/wkentaro/labelme/pull/2163))
- Fixed deleting a polygon vertex dragging the adjacent vertex on the next mouse move ([#2194](https://github.com/wkentaro/labelme/pull/2194))
- Fixed canvas not repainting immediately after adding or removing a polygon point via keyboard shortcut ([#2174](https://github.com/wkentaro/labelme/pull/2174))
- Fixed grab-pan overscroll causing an image snap/jump at the zoom threshold by ramping the scroll slack continuously ([#2101](https://github.com/wkentaro/labelme/pull/2101))
- Fixed a confusing bare `KeyError` when a shape label is absent from the provided labels mapping; now raises a descriptive `ValueError` naming all missing labels at once ([#2173](https://github.com/wkentaro/labelme/pull/2173))
- Fixed AI Text-to-Annotation silently producing nothing when a detection-only model (e.g. YOLO-World) is paired with a mask output format; a warning now directs users to SAM or Rectangle output ([#2196](https://github.com/wkentaro/labelme/pull/2196))
- Fixed AI Text-to-Annotation aborting with an assertion when a detection model returned no mask; it now raises a descriptive error ([#2256](https://github.com/wkentaro/labelme/pull/2256))
- Fixed AI-assisted polygons being offset from their mask by aligning `compute_polygon_from_mask` with image coordinates ([#2239](https://github.com/wkentaro/labelme/pull/2239))
- Fixed the app crashing when an AI model errored during inference; the error is now surfaced instead of aborting ([#2247](https://github.com/wkentaro/labelme/pull/2247))
- Fixed TIFF images with non-finite (NaN/Inf) pixels rendering incorrectly by normalizing the display over finite pixels only ([#2255](https://github.com/wkentaro/labelme/pull/2255))
- Fixed shape flag checkboxes re-enabling on label text change when they should stay disabled ([#2243](https://github.com/wkentaro/labelme/pull/2243))
- Fixed the vertex remaining selected after removing a polygon point ([#2175](https://github.com/wkentaro/labelme/pull/2175))
- Fixed the label dialog overflowing the screen when a label has many flags by making the flag list scrollable and keeping the popup on screen ([#2263](https://github.com/wkentaro/labelme/pull/2263))
- Fixed the Edit Label dialog opening away from the cursor instead of at the context-menu origin ([#2264](https://github.com/wkentaro/labelme/pull/2264))

## 6.3.1 - 2026-05-27

### Fixed

- Fixed a crash when switching drawing modes while a shape was partially drawn; the in-progress shape is now retyped when both modes accept a single click as a starting point, and cancelled otherwise. Degenerate shapes (zero-area rectangle, zero-length line, polygon with fewer than 3 distinct vertices) are now rejected at the point of completion ([#2103](https://github.com/wkentaro/labelme/pull/2103))

## 6.3.0 - 2026-05-19

### Added

- Added mask-aware suppression that collapses redundant SAM detections at multiple granularities into a single shape per region ([#2088](https://github.com/wkentaro/labelme/pull/2088))
- Added suppression of AI detections whose mask overlaps an already-annotated shape (mask overlap >= 0.5), preventing duplicate annotations when prompting over existing labels ([#2087](https://github.com/wkentaro/labelme/pull/2087))

### Fixed

- Fixed missing status bar feedback and disabled edit-mode button when AI inference produces no new shapes ([#2083](https://github.com/wkentaro/labelme/pull/2083))
- Fixed AI detections with empty segmentation masks being emitted as transparent shapes; they are now dropped ([#2094](https://github.com/wkentaro/labelme/pull/2094))
- Fixed vertex-drag handles appearing on mask shapes, which previously shifted the bounding box without moving the underlying bitmap ([#2095](https://github.com/wkentaro/labelme/pull/2095))

## 6.2.0 - 2026-05-10

### Added

- Added oriented rectangle shape type for rotated bounding box annotation, available in the toolbar and via keyboard shortcut ([#1980](https://github.com/wkentaro/labelme/pull/1980))
- Added AI-assisted oriented rectangle: SAM masks can now be emitted as an oriented rectangle, fitting the minimum-area rotated bounding box to the predicted mask ([#2078](https://github.com/wkentaro/labelme/pull/2078))
- Added rectangle and circle as AI-assisted output formats: AI-Points and AI-Box can now output `rectangle` or `circle` derived from the predicted mask, in addition to `polygon` and `mask` ([#2064](https://github.com/wkentaro/labelme/pull/2064))
- Added right-click "Add Point to Edge" context menu action to insert a vertex at the cursor position on the nearest edge of the selected shape ([#2029](https://github.com/wkentaro/labelme/pull/2029))
- Made hide/show shape undoable via the undo stack ([#2034](https://github.com/wkentaro/labelme/pull/2034))
- Propagated hide/show toggle across all shapes in a multi-selection ([#2035](https://github.com/wkentaro/labelme/pull/2035))

### Changed

- Redesigned AI-Points and AI-Box toolbar icons to represent the input action (click vs. drag-box) with a sparkle accent, replacing the previous output-named polygon/mask icons ([#1985](https://github.com/wkentaro/labelme/pull/1985))
- Improved Turkish (tr_TR) translations for correctness, natural phrasing, and consistency with Apple/Microsoft Turkish UI conventions ([#1967](https://github.com/wkentaro/labelme/pull/1967))
- Retranslated Turkish (tr_TR) with corrected domain terminology and grammar ([#1963](https://github.com/wkentaro/labelme/pull/1963))
- Retranslated Simplified Chinese (zh_CN) to use standard CV/ML domain terms and idiomatic phrasing, including unifying "annotation" as `标注` ([#1965](https://github.com/wkentaro/labelme/pull/1965))

### Fixed

- Fixed incorrect AI-Box predictions when the bounding box was drawn right-to-left or bottom-to-top by normalizing the corner points before sending to the model ([#2032](https://github.com/wkentaro/labelme/pull/2032))
- Fixed color indicator on annotation list rows disappearing after editing a shape's group ID ([#2015](https://github.com/wkentaro/labelme/pull/2015))
- Fixed Shift+wheel to scroll horizontally on Linux and Windows, matching macOS behavior ([#2014](https://github.com/wkentaro/labelme/pull/2014))
- Fixed oriented rectangle being lost when cancelling the label dialog after drawing ([#2079](https://github.com/wkentaro/labelme/pull/2079))
- Fixed `validate_label: null` not skipping validation as documented

## 6.1.3 - 2026-04-24

### Fixed

- Stale snap highlight no longer stays on canvas after scroll, zoom, or resize ([#1975](https://github.com/wkentaro/labelme/pull/1975))

## 6.1.2 - 2026-04-21

### Fixed

- Restored first-vertex snap highlight when closing a polygon ([#1974](https://github.com/wkentaro/labelme/pull/1974))

## 6.1.1 - 2026-04-19

### Fixed

- Fixed Ctrl/Cmd+A (Edit > Select All) not working when the canvas has focus ([#1964](https://github.com/wkentaro/labelme/pull/1964))

## 6.1.0 - 2026-04-16

### Added

- Added SAM3 to the AI model list with AI-Box support, producing multiple shapes from a single bounding box annotation ([#1917](https://github.com/wkentaro/labelme/pull/1917))
- Unified AI annotation tools into two modes: AI Points -> Shape and AI Box -> Shape, each with a polygon/mask output toggle; added a visual separator between manual and AI tools in the toolbar ([#1914](https://github.com/wkentaro/labelme/pull/1914), [#1915](https://github.com/wkentaro/labelme/pull/1915), [#1916](https://github.com/wkentaro/labelme/pull/1916))
- Added a progress bar with cancellation support during AI model downloads ([#1948](https://github.com/wkentaro/labelme/pull/1948))
- Added auto-import of sibling images from the same directory when opening a single image file ([#1924](https://github.com/wkentaro/labelme/pull/1924))
- Added highlighting of AI toolbar buttons when hovering the disabled AI-Assisted Annotation widget to help new users find them ([#1961](https://github.com/wkentaro/labelme/pull/1961))
- Switched canvas repainting from synchronous to asynchronous rendering, avoiding blocking redraws ([#1869](https://github.com/wkentaro/labelme/pull/1869))
- Added Greek (el_GR) translation ([#1893](https://github.com/wkentaro/labelme/pull/1893))
- Added Ukrainian (uk_UA) translation ([#1892](https://github.com/wkentaro/labelme/pull/1892))
- Added Russian (ru_RU) translation ([#1891](https://github.com/wkentaro/labelme/pull/1891))

### Changed

- Shortened toolbar button labels by removing the redundant "Create" prefix (e.g., "Create Polygon" becomes "Polygon") ([#1914](https://github.com/wkentaro/labelme/pull/1914))
- Disabled the file list dock with an explanatory tooltip when a label `.json` file is opened directly; re-enabled it when a directory or image is opened ([#1924](https://github.com/wkentaro/labelme/pull/1924))
- Added support for cropped masks returned by osam 0.4.0 (SAM3) for accurate annotation on large images ([#1919](https://github.com/wkentaro/labelme/pull/1919))

### Deprecated

- Deprecated `labelme.utils.lblsave`; use `imgviz.io.lblsave` instead. The old import will be removed in a future release ([#1911](https://github.com/wkentaro/labelme/pull/1911), [#1959](https://github.com/wkentaro/labelme/pull/1959))

### Removed

- Removed the "Open Recent" submenu from the File menu; use the file list dock (which now auto-populates with sibling images) or the OS file dialog instead ([#1921](https://github.com/wkentaro/labelme/pull/1921))

### Fixed

- Fixed single undo to fully restore a deleted shape; previously two undos were required ([#1932](https://github.com/wkentaro/labelme/pull/1932))
- Disabled SAM3 in the model selector during AI-Points mode and showed a warning, as SAM3 does not support point prompts ([#1918](https://github.com/wkentaro/labelme/pull/1918))
- Fixed AI mode tooltip names to match the renamed menu labels ([#1928](https://github.com/wkentaro/labelme/pull/1928))
- Equalized button widths in the vertical toolbar ([#1961](https://github.com/wkentaro/labelme/pull/1961))

## 6.0.2 - 2026-04-16

### Fixed

- Fixed broken images on the PyPI project page by rewriting relative image paths to absolute GitHub raw URLs at build time ([#1954](https://github.com/wkentaro/labelme/pull/1954))

## 6.0.1 - 2026-04-16

### Fixed

- Fixed the "Save Automatically" checkbox having no effect after v6.0.0 changed its default to enabled ([#1953](https://github.com/wkentaro/labelme/pull/1953))

## 6.0.0 - 2026-03-28

### Added

- Added support for multispectral and float32 TIFF images via tifffile (e.g., satellite imagery) ([#1812](https://github.com/wkentaro/labelme/pull/1812))
- Added Polish (pl_PL) translation ([#1809](https://github.com/wkentaro/labelme/pull/1809))
- Added Thai (th_TH) translation ([#1886](https://github.com/wkentaro/labelme/pull/1886))
- Added Turkish language support for AI-assisted annotation features ([#1805](https://github.com/wkentaro/labelme/pull/1805))
- Created sparse ~/.labelmerc containing only user-changed settings instead of copying the full default config ([#1796](https://github.com/wkentaro/labelme/pull/1796))

### Changed

- **Breaking:** Changed auto-save default to on; use `--no-auto-save` or `auto_save: false` in config to disable ([#1815](https://github.com/wkentaro/labelme/pull/1815))
- **Breaking:** Changed the default so image data is no longer embedded in JSON files; JSON now references image paths instead of base64. Use `--with-image-data` or `with_image_data: true` in config to embed ([#1814](https://github.com/wkentaro/labelme/pull/1814))
- **Breaking:** Renamed the CLI positional argument from `filename` to `path`; it now accepts image files, label files, or directories ([#1825](https://github.com/wkentaro/labelme/pull/1825))
- **Breaking:** Changed `--output` to always expect a directory path (no longer accepts `.json` file paths) ([#1813](https://github.com/wkentaro/labelme/pull/1813))
- **Breaking:** Standardized CLI flags to hyphenated style: `--autosave` -> `--no-auto-save`, `--nosortlabels` -> `--no-sort-labels`, `--labelflags` -> `--label-flags`, `--validatelabel` -> `--validate-label`; old forms kept as hidden aliases until v7 ([#1823](https://github.com/wkentaro/labelme/pull/1823))
- Renamed the "Shape Labels" dock widget to "Annotation List" ([#1828](https://github.com/wkentaro/labelme/pull/1828))
- Renamed "polygon" to "shape" in shortcuts and UI labels ([#1822](https://github.com/wkentaro/labelme/pull/1822))
- Prioritized vertices over shape bodies in hover detection, making vertex editing easier ([#1867](https://github.com/wkentaro/labelme/pull/1867))
- Improved large image loading performance by skipping re-encoding for JPEG/PNG without EXIF rotation ([#1811](https://github.com/wkentaro/labelme/pull/1811))

### Deprecated

- Deprecated `--autosave` flag; use `--no-auto-save` instead (will be removed in v7)
- Deprecated `--nodata` flag; use `--with-image-data` instead (will be removed in v7)
- Deprecated config key `store_data`; automatically migrated to `with_image_data`

### Removed

- **Breaking:** Removed `labelme_draw_json`, `labelme_draw_label_png`, and `labelme_export_json` CLI entry points; moved to `examples/tutorial/` as standalone scripts ([#1846](https://github.com/wkentaro/labelme/pull/1846))
- **Breaking:** Removed `labelme_on_docker` CLI entry point ([#1821](https://github.com/wkentaro/labelme/pull/1821))
- **Breaking:** Removed deprecated `labelme.utils.polygons_to_mask()` and `labelme.utils.labelme_shapes_to_label()` (deprecated since v4) ([#1821](https://github.com/wkentaro/labelme/pull/1821))

### Fixed

- Fixed point shapes not being clickable ([#1860](https://github.com/wkentaro/labelme/pull/1860))
- Fixed window position not recovering when the saved screen is no longer available ([#1859](https://github.com/wkentaro/labelme/pull/1859))
- Fixed out-of-bounds crash when highlighting AI-generated masks ([#1858](https://github.com/wkentaro/labelme/pull/1858))
- Fixed pasted shapes not being selected after cross-file paste ([#1876](https://github.com/wkentaro/labelme/pull/1876))
- Fixed RGBA/transparent images not rendering correctly in the brightness/contrast dialog ([#1872](https://github.com/wkentaro/labelme/pull/1872))
- Fixed crosshair guide lines extending beyond image bounds ([#1870](https://github.com/wkentaro/labelme/pull/1870))
- Fixed a crash when the previously selected shape was removed from the annotation list ([#1871](https://github.com/wkentaro/labelme/pull/1871))
- Fixed a crash on malformed JSON in the file dialog preview ([#1900](https://github.com/wkentaro/labelme/pull/1900))
- Fixed a hang with `@` symbols in file paths on macOS with Unicode paths ([#1904](https://github.com/wkentaro/labelme/pull/1904))
- Fixed rectangle drawn right-to-left producing incorrect masks ([#1817](https://github.com/wkentaro/labelme/pull/1817))
- Fixed a crash when moving a vertex beyond valid range on the canvas ([#1818](https://github.com/wkentaro/labelme/pull/1818))
- Fixed RGBA PNG conversion in `labelme2coco` ([#1830](https://github.com/wkentaro/labelme/pull/1830))
- Fixed deprecated NumPy boolean type usage ([#1831](https://github.com/wkentaro/labelme/pull/1831))
- Fixed silent failure when an image file fails to open; an error dialog is now shown ([#1810](https://github.com/wkentaro/labelme/pull/1810))
- Fixed display issues by forcing light mode (dark mode not yet supported) ([#1808](https://github.com/wkentaro/labelme/pull/1808))
- Fixed points on the edge of the image being rejected; edge placement is now allowed ([#1801](https://github.com/wkentaro/labelme/pull/1801))

## 5.11.4 - 2026-03-10

### Added

- Added a "Reset Layout" action to reset the window layout to default ([#1864](https://github.com/wkentaro/labelme/pull/1864))

### Fixed

- Fixed window state reset for users upgrading from older versions ([#1863](https://github.com/wkentaro/labelme/pull/1863))

## 5.11.3 - 2026-02-20

### Fixed

- Forced light mode since dark mode is not yet supported

## 5.11.2 - 2026-01-31

### Fixed

- Fixed mask being set and drawn for non-mask shapes (e.g. polygon) ([#1797](https://github.com/wkentaro/labelme/pull/1797))

## 5.11.1 - 2026-01-28

_No user-facing changes._

## 5.11.0 - 2026-01-28

### Added

- Added support for square drawing in Create Rectangle mode ([#1748](https://github.com/wkentaro/labelme/pull/1748))
- Applied the "Fusion" style for consistent appearance across platforms ([#1751](https://github.com/wkentaro/labelme/pull/1751))
- Added model selection display to the AI Prompt widget ([#1752](https://github.com/wkentaro/labelme/pull/1752))
- Added an info button to the AI-Assisted Annotation widget ([#1764](https://github.com/wkentaro/labelme/pull/1764))
- Added a tooltip for the AI Text-to-Annotation info button ([#1766](https://github.com/wkentaro/labelme/pull/1766))
- Introduced SAM3 (smart) model for text-to-rectangle annotation ([#1762](https://github.com/wkentaro/labelme/pull/1762))
- Added support for "polygon" and "mask" output types in AI text-to-annotation ([#1774](https://github.com/wkentaro/labelme/pull/1774))
- Added a "Preferences..." menu item for editing the config file (macOS: Cmd+,; Win/Linux: Ctrl+Shift+,) ([#1781](https://github.com/wkentaro/labelme/pull/1781))
- Added Traditional Chinese (zh_TW) translation ([#1727](https://github.com/wkentaro/labelme/pull/1727))
- Added French (fr_FR) translation ([#1730](https://github.com/wkentaro/labelme/pull/1730))
- Added Japanese (ja_JP) translation ([#1732](https://github.com/wkentaro/labelme/pull/1732))
- Added Hungarian (hu_HU) translation ([#1734](https://github.com/wkentaro/labelme/pull/1734))
- Added German (de_DE) translation ([#1735](https://github.com/wkentaro/labelme/pull/1735))
- Added Persian (fa_IR) translation ([#1737](https://github.com/wkentaro/labelme/pull/1737))
- Added Korean (ko_KR) translation ([#1738](https://github.com/wkentaro/labelme/pull/1738))
- Added Spanish (es_ES) translation ([#1739](https://github.com/wkentaro/labelme/pull/1739))
- Added Portuguese (pt_BR) translation ([#1749](https://github.com/wkentaro/labelme/pull/1749))
- Added Dutch (nl_NL) translation ([#1750](https://github.com/wkentaro/labelme/pull/1750))
- Added Italian (it_IT) translation ([#1776](https://github.com/wkentaro/labelme/pull/1776))
- Added Vietnamese (vi_VN) translation ([#1779](https://github.com/wkentaro/labelme/pull/1779))

### Changed

- Disabled the AI-Assisted Annotation widget when not in an AI mode ([#1767](https://github.com/wkentaro/labelme/pull/1767))
- Disabled the AI Prompt widget when not in rectangle-create mode ([#1753](https://github.com/wkentaro/labelme/pull/1753))
- Restricted label editing from the label list to edit mode only ([#1769](https://github.com/wkentaro/labelme/pull/1769))

### Removed

- **Breaking:** Dropped Python 3.9 support ([#1746](https://github.com/wkentaro/labelme/pull/1746))

### Fixed

- Fixed a crash when loading a new image by clearing the shape selection state ([#1717](https://github.com/wkentaro/labelme/pull/1717))
- Fixed import conflicts by loading onnxruntime before PyQt5 ([#1723](https://github.com/wkentaro/labelme/pull/1723))
- Fixed double-click shape finalization not respecting the close-shape check ([#1724](https://github.com/wkentaro/labelme/pull/1724))
- Fixed a typo in a variable name in the shape module ([#1733](https://github.com/wkentaro/labelme/pull/1733))
- Fixed a crash when bounding-box non-maximum suppression receives empty input ([#1761](https://github.com/wkentaro/labelme/pull/1761))
- Fixed unnecessary AI model initialization by loading the AI session lazily ([#1775](https://github.com/wkentaro/labelme/pull/1775))
- Fixed Windows-style paths not being handled correctly in label files ([#1784](https://github.com/wkentaro/labelme/pull/1784))
- Fixed a NumPy compatibility issue by replacing the cross-product helper with a manual 2D implementation ([#1785](https://github.com/wkentaro/labelme/pull/1785))
- Fixed the file list not being filtered immediately when opening a directory with a file_search config filter ([#1788](https://github.com/wkentaro/labelme/pull/1788))
- Fixed Japanese (ja_JP) menu and toolbar labels wrapping incorrectly by adding explicit newlines ([#1768](https://github.com/wkentaro/labelme/pull/1768))

## 5.10.1 - 2025-11-29

### Fixed

- Fixed a crash when loading a new image while shapes were selected on the canvas
- Fixed a crash on double-click shape finalization by correctly checking whether the shape was closeable
- Fixed a startup crash on some systems by importing onnxruntime before PyQt5

## 5.10.0 - 2025-11-25

### Added

- Added canvas mode display to the status bar ([#1682](https://github.com/wkentaro/labelme/pull/1682))
- Added a sidebar toolbar for shape creation tools ([#1685](https://github.com/wkentaro/labelme/pull/1685))
- Added image index display to the window title ([#1692](https://github.com/wkentaro/labelme/pull/1692))
- Added middle-mouse-button drag to pan the canvas ([#1622](https://github.com/wkentaro/labelme/pull/1622))
- Improved vertex selection to prioritize the highlighted shape's vertex ([#1691](https://github.com/wkentaro/labelme/pull/1691))
- Refreshed the application icons ([#1701](https://github.com/wkentaro/labelme/pull/1701))
- Added mouse-wheel zoom toward canvas center ([#1704](https://github.com/wkentaro/labelme/pull/1704))

### Changed

- Compacted the toolbar layout ([#1684](https://github.com/wkentaro/labelme/pull/1684))
- Changed zoom centering to use the visible region center instead of the canvas origin ([#1705](https://github.com/wkentaro/labelme/pull/1705))

### Fixed

- Fixed the Edit Mode button being incorrectly enabled on startup (it is already in Edit mode by default) ([#1683](https://github.com/wkentaro/labelme/pull/1683))
- Fixed font size inconsistency in the toolbar on macOS ([#1713](https://github.com/wkentaro/labelme/pull/1713))
- Fixed high-DPI display scaling on HiDPI screens ([#1687](https://github.com/wkentaro/labelme/pull/1687))
- Fixed a crash when no image is loaded during canvas repaint ([#1695](https://github.com/wkentaro/labelme/pull/1695))
- Fixed an error when a file is closed while the image list is not empty ([#1700](https://github.com/wkentaro/labelme/pull/1700))
- Fixed current image index display to reflect the file list position ([#1708](https://github.com/wkentaro/labelme/pull/1708))
- Fixed the AI prompt receiving focus after a file is closed ([#1699](https://github.com/wkentaro/labelme/pull/1699))
- Fixed a spurious scrollbar appearing when fitting the image to width ([#1702](https://github.com/wkentaro/labelme/pull/1702))
- Fixed canvas layout shifting caused by non-ASCII bullet characters in status messages ([#1712](https://github.com/wkentaro/labelme/pull/1712))
- Fixed shapes remaining visible on the canvas after a reset ([#1690](https://github.com/wkentaro/labelme/pull/1690))
- Fixed excessive VRAM usage by removing the cache on the SAM model ([#1715](https://github.com/wkentaro/labelme/pull/1715))
- Fixed a duplicate unsaved-changes confirmation dialog when navigating between images ([#1693](https://github.com/wkentaro/labelme/pull/1693))

## 5.9.1 - 2025-10-17

### Fixed

- Fixed canvas cursor so changes take effect immediately without flickering ([#1681](https://github.com/wkentaro/labelme/pull/1681))

## 5.9.0 - 2025-10-16

### Added

- Validated shape JSON objects in annotation files, catching malformed annotations earlier ([#1624](https://github.com/wkentaro/labelme/pull/1624))
- Added spacebar shortcut to finalize a shape while drawing ([#1474](https://github.com/wkentaro/labelme/pull/1474))
- Added drawing and editing status messages to the status bar ([#1673](https://github.com/wkentaro/labelme/pull/1673))
- Added a progress dialog when downloading an AI model ([#1677](https://github.com/wkentaro/labelme/pull/1677))
- Added an option to keep previous brightness/contrast settings across images ([#1678](https://github.com/wkentaro/labelme/pull/1678))
- Added a download dialog for the text-to-bbox AI model ([#1679](https://github.com/wkentaro/labelme/pull/1679))
- Added an About Labelme menu item and dialog showing the version and links ([#1680](https://github.com/wkentaro/labelme/pull/1680))

### Fixed

- Fixed the brightness/contrast slider label not updating correctly ([#1613](https://github.com/wkentaro/labelme/pull/1613))
- Fixed linestrip shapes incorrectly filling their internal area ([#1628](https://github.com/wkentaro/labelme/pull/1628))
- Fixed missing fill drawing in polygon mode ([#1627](https://github.com/wkentaro/labelme/pull/1627))
- Fixed label list rendering inconsistency on Windows ([#1646](https://github.com/wkentaro/labelme/pull/1646))
- Fixed cursor flickering on Windows ([#1647](https://github.com/wkentaro/labelme/pull/1647))
- Fixed label list items being overwritten when dragging and dropping ([#1651](https://github.com/wkentaro/labelme/pull/1651))
- Fixed the brightness/contrast dialog failing on non-RGB images (e.g. PNG with alpha channel) ([#1655](https://github.com/wkentaro/labelme/pull/1655))
- Fixed the Save Automatically checkmark not appearing on Windows ([#1657](https://github.com/wkentaro/labelme/pull/1657))

## 5.8.3 - 2025-07-13

### Fixed

- Fixed a crash when clicking on a polygon (float coordinates caused a type error in the Qt point constructor on Python 3.12) ([#1606](https://github.com/wkentaro/labelme/pull/1606))
- Fixed the AI mask feature crashing due to a missing file-handle attribute on the logger's output stream ([#1603](https://github.com/wkentaro/labelme/pull/1603))
- Fixed Python 3.12 compatibility when loading Docker by replacing the deprecated executable-search function with the standard `shutil.which` ([#1589](https://github.com/wkentaro/labelme/pull/1589))

## 5.8.2 - 2025-06-21

### Changed

- Deferred SAM image-embedding computation to the first click on an image instead of on image load, making image navigation faster when AI annotation is active ([#1593](https://github.com/wkentaro/labelme/pull/1593))
- Initialized the AI (SAM) model lazily only when first needed, removing unnecessary initialization on mode switches ([#1596](https://github.com/wkentaro/labelme/pull/1596))

### Fixed

- Captured unhandled exceptions globally so crashes are recorded in the log file when running the packaged app ([#1601](https://github.com/wkentaro/labelme/pull/1601))
- Fixed a crash when switching from AI polygon mode to polygon mode after the AI model was initialized ([#1588](https://github.com/wkentaro/labelme/pull/1588))
- Fixed shape flags staying disabled in the label dialog after group-editing flags on multiple shapes

## 5.8.1 - 2025-03-24

### Fixed

- Fixed missing check for AI segmentation model in canvas finalization ([#1566](https://github.com/wkentaro/labelme/pull/1566))

## 5.8.0 - 2025-03-16

### Added

- Added SAM2 as the default AI model for faster and more accurate AI-polygon and AI-mask annotations ([#1557](https://github.com/wkentaro/labelme/pull/1557))
- Added support for `shape_type="mask"` in conversion tools (`labelme_draw_json`, `labelme2voc.py`, `labelme_export_json`) ([#1560](https://github.com/wkentaro/labelme/pull/1560))

### Removed

- **Breaking:** Removed `labelme_json_to_dataset` command (deprecated in favor of `labelme_export_json`) ([#1561](https://github.com/wkentaro/labelme/pull/1561))

### Fixed

- Fixed a crash when finishing a shape in AI-mask or AI-polygon mode ([#1558](https://github.com/wkentaro/labelme/pull/1558))
- Fixed a crash caused by a null bounding box in AI-mask mode response ([#1556](https://github.com/wkentaro/labelme/pull/1556))

## 5.7.0 - 2025-03-04

### Changed

- **Breaking:** Dropped qtpy and PySide2 support; PyQt5 is now the primary supported Qt binding ([#1540](https://github.com/wkentaro/labelme/pull/1540))

### Fixed

- Fixed a crash when a shape's flags field is None, which occurred when using AI text-to-rectangle ([#1536](https://github.com/wkentaro/labelme/pull/1536))
- Fixed a crash in the packaged app caused by missing stderr when downloading AI models via gdown ([#1549](https://github.com/wkentaro/labelme/pull/1549))

## 5.6.1 - 2025-01-23

### Fixed

- Fixed an encoding error on Windows when reading annotation files ([#1525](https://github.com/wkentaro/labelme/pull/1525))
- Fixed a crash on startup caused by an undefined logging method when using loguru ([#1530](https://github.com/wkentaro/labelme/pull/1530))

## 5.6.0 - 2024-12-30

### Added

- Added "AI Text to Rectangles" AI feature ([#1469](https://github.com/wkentaro/labelme/pull/1469))

### Changed

- Changed point manipulation shortcuts: ALT+Click adds a point, ALT+SHIFT+Click deletes a point ([#1496](https://github.com/wkentaro/labelme/pull/1496))

### Fixed

- Fixed slight position shift when duplicating a shape ([#1499](https://github.com/wkentaro/labelme/pull/1499))
- Fixed the group ID field not being clearable by re-selecting the already-set value ([#1498](https://github.com/wkentaro/labelme/pull/1498))
- Fixed group ID editing when the text field is disabled ([#1497](https://github.com/wkentaro/labelme/pull/1497))
- Fixed crosshair and point size rendering to stay consistent regardless of zoom level ([#1471](https://github.com/wkentaro/labelme/pull/1471))

## 5.5.0 - 2024-06-13

### Added

- Added support for editing multiple annotations simultaneously ([#1455](https://github.com/wkentaro/labelme/pull/1455))
- Added XY coordinate display in the status bar ([#1456](https://github.com/wkentaro/labelme/pull/1456))
- Added support for closing an AI polygon by pressing Enter ([#1429](https://github.com/wkentaro/labelme/pull/1429))

### Changed

- Saved masks as 8-bit unsigned integers for better compatibility with other tools ([#1452](https://github.com/wkentaro/labelme/pull/1452))
- Kept shapes selected after duplicating ([#1401](https://github.com/wkentaro/labelme/pull/1401))
- Improved brightness/contrast adjustment speed and usability, adding numeric labels to the sliders ([#1443](https://github.com/wkentaro/labelme/pull/1443))
- Updated the internationalization template and improved the Simplified Chinese translation ([#1411](https://github.com/wkentaro/labelme/pull/1411))

### Fixed

- Fixed slider alignment in the brightness/contrast dialog
- Fixed stride value in the brightness/contrast dialog

## 5.4.1 - 2024-01-06

### Added

- Added copy and paste actions to the Edit menu ([#1392](https://github.com/wkentaro/labelme/pull/1392))

### Fixed

- Fixed an encoding error on Windows caused by emoji characters in output ([#1390](https://github.com/wkentaro/labelme/pull/1390))
- Fixed crashes during annotation caused by empty contours ([#1391](https://github.com/wkentaro/labelme/pull/1391))

## 5.4.0 - 2023-12-31

### Added

- Added an AI mask annotation mode that generates shapes as masks using AI ([#1358](https://github.com/wkentaro/labelme/pull/1358))
- Integrated EfficientSAM as a faster AI model option (claimed ~20x faster than original SAM) ([#1375](https://github.com/wkentaro/labelme/pull/1375))
- Added a menu to toggle visibility of all shapes with keyboard shortcuts ([#1381](https://github.com/wkentaro/labelme/pull/1381))
- Added regex filename search in the file browser ([#1384](https://github.com/wkentaro/labelme/pull/1384))
- Included translation files in the package to enable localization everywhere ([#1383](https://github.com/wkentaro/labelme/pull/1383))
- Added an `ai.default` config key to set the default AI model in `~/.labelmerc`

### Changed

- Increased resolution of polygon approximation for more accurate AI-generated polygons ([#1363](https://github.com/wkentaro/labelme/pull/1363))
- Cleaned up the toolbar: removed less common items and clarified distinction between actions and other controls ([#1356](https://github.com/wkentaro/labelme/pull/1356))
- Resized toolbar icons to 32x32 for consistent alignment ([#1357](https://github.com/wkentaro/labelme/pull/1357))
- Used a tight bounding box to represent the bounding box for mask shapes ([#1379](https://github.com/wkentaro/labelme/pull/1379))
- Exported original VOC format in `labelme2voc.py` ([#1323](https://github.com/wkentaro/labelme/pull/1323))
- Added support for comma-separated text for the `--labels` argument in `labelme2voc.py` ([#1326](https://github.com/wkentaro/labelme/pull/1326))
- Sorted JSON file processing order in `labelme2voc.py` for deterministic output ([#1327](https://github.com/wkentaro/labelme/pull/1327))
- Showed label names and image preview in `draw_label_png.py` ([#1318](https://github.com/wkentaro/labelme/pull/1318))
- Removed custom font override to stop interfering with system font rendering ([#1355](https://github.com/wkentaro/labelme/pull/1355))
- Cleaned up AI-generated masks by removing small noisy objects (smaller than 5% of the mask area) after SAM prediction

### Fixed

- Fixed file paths displaying incorrectly on Windows by normalizing path separators ([#1362](https://github.com/wkentaro/labelme/pull/1362))
- Fixed a crash caused by an incompatible `onnxruntime` version by pinning away from 1.16.0 ([#1364](https://github.com/wkentaro/labelme/pull/1364))
- Fixed a crash when an AI mode was activated before an image was loaded

## 5.3.1 - 2023-08-22

### Fixed

- Fixed `labelme_export_json` CLI to strip only the file extension from the output directory name, so files with multiple dots (e.g. `image.v2.json`) no longer produce a mangled directory name

## 5.3.0 - 2023-08-06

### Added

- Integrated Segment Anything Model (SAM) for AI-assisted polygon annotation (`Create AI-Polygon` mode) ([#1262](https://github.com/wkentaro/labelme/pull/1262))
- Added support for positive and negative point clicks (Shift+click to exclude regions) for SAM annotation ([#1262](https://github.com/wkentaro/labelme/pull/1262))
- Added support for 1-click annotation in `ai_polygon` mode ([#1262](https://github.com/wkentaro/labelme/pull/1262))
- Added real-time polygon preview while placing SAM points ([#1262](https://github.com/wkentaro/labelme/pull/1262))
- Added a dropdown to select AI models ([#1262](https://github.com/wkentaro/labelme/pull/1262))
- Added an image embedding cache to speed up repeated SAM annotations on the same image ([#1262](https://github.com/wkentaro/labelme/pull/1262))
- Added a zoom level label to the UI ([#1262](https://github.com/wkentaro/labelme/pull/1262))

### Changed

- **Breaking:** Renamed command-line tool `labelme_json_to_dataset` to `labelme_export_json` ([#1308](https://github.com/wkentaro/labelme/pull/1308))
- Moved the toolbar to the top by default ([#1262](https://github.com/wkentaro/labelme/pull/1262))
- Enabled Ctrl+Shift key combination for annotation interactions ([#1262](https://github.com/wkentaro/labelme/pull/1262))
- Set shape fill color to black and enabled fill by default ([#1262](https://github.com/wkentaro/labelme/pull/1262))

### Fixed

- Fixed polygon contour detection at image borders ([#1262](https://github.com/wkentaro/labelme/pull/1262))
- Fixed uninitialized AI model image when annotating consecutive images ([#1262](https://github.com/wkentaro/labelme/pull/1262))
- Fixed `double_click="close"` behavior requiring fewer than 4 points to close a polygon ([#1262](https://github.com/wkentaro/labelme/pull/1262))
- Fixed duplicate last point in polygon computed from AI points ([#1262](https://github.com/wkentaro/labelme/pull/1262))
- Treated zero-length lines as lines to avoid unintuitive behavior ([#1262](https://github.com/wkentaro/labelme/pull/1262))
- Fixed portrait-orientation image handling in Segment Anything Model ([#1262](https://github.com/wkentaro/labelme/pull/1262))

## 5.2.1 - 2023-05-16

### Fixed

- Fixed an undefined label description when the label popup is disabled ([#1270](https://github.com/wkentaro/labelme/pull/1270))

## 5.2.0 - 2023-04-06

### Added

- Added a description field to labels ([#1255](https://github.com/wkentaro/labelme/pull/1255))

### Fixed

- Fixed floating-point coordinate handling when moving multiple shapes on the canvas ([#1253](https://github.com/wkentaro/labelme/pull/1253))
- Fixed removing a vertex from a polygon or linestrip that was already at its minimum point count, which would produce a malformed shape ([#1254](https://github.com/wkentaro/labelme/pull/1254))

## 5.1.1 - 2022-11-20

### Fixed

- Removed the overly broad matplotlib version restriction from install requirements; the constraint is only needed when building the standalone executable, so regular installs can now use any matplotlib version

## 5.1.0 - 2022-11-15

### Added

- Added crosshair display alongside cursor on the canvas

### Removed

- **Breaking:** Removed Docker support as it was unstable and Docker Hub policy changed

## 5.0.5 - 2022-10-30

### Fixed

- Fixed a TypeError when using the polygon annotation tool on Python 3.10 caused by an internal point type mismatch

## 5.0.4 - 2022-10-24

### Fixed

- Fixed a crash when opening a directory caused by the label list widget returning a fractional size instead of an integer size
- Fixed a crash when scrolling annotations loaded from older JSON files due to a float value passed to the scroll bar
- Fixed removing the last point of a shape not always marking the annotation as modified

## 5.0.3 - 2022-10-23

### Fixed

- Fixed type errors when annotating on Python 3.10

## 5.0.2 - 2022-09-26

### Fixed

- Fixed a crash when editing a label whose name does not exist in the label list
- Escaped label names so that labels containing angle brackets (e.g. `<cat>`, `<background>`) are displayed and handled correctly

## 5.0.1 - 2022-03-03

_No user-facing changes._

## 5.0.0 - 2022-02-26

### Changed

- Sorted files in the file browser using OS-native natural order ([#990](https://github.com/wkentaro/labelme/pull/990))

### Removed

- **Breaking:** Dropped Python 2 support ([#993](https://github.com/wkentaro/labelme/pull/993))
- **Breaking:** Dropped PyQt4 support ([#994](https://github.com/wkentaro/labelme/pull/994))
- Removed the man page; use `--help` instead ([#996](https://github.com/wkentaro/labelme/pull/996))

## v4.6.0 and earlier

See the [GitHub Releases](https://github.com/wkentaro/labelme/releases) page for changelogs of v4.6.0 and earlier.
