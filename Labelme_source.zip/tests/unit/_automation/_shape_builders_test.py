from __future__ import annotations

import math
import typing

import numpy as np
import pytest
from numpy.typing import NDArray

from labelme._automation import MASK_REQUIRED_SHAPE_TYPES
from labelme._automation import AiOutputFormat
from labelme._automation import Detection
from labelme._automation import assign_available_group_ids
from labelme._automation import shapes_from_detections
from labelme._shape import Shape
from labelme._utils.shape import shape_to_mask


def test_shapes_from_detections_rectangle_uses_bbox() -> None:
    [shape] = shapes_from_detections(
        detections=[Detection(bbox=(10, 20, 30, 50))],
        shape_type="rectangle",
    )

    assert shape.shape_type == "rectangle"
    assert (shape.points[0][0], shape.points[0][1]) == pytest.approx((10, 20))
    assert (shape.points[1][0], shape.points[1][1]) == pytest.approx((30, 50))


def test_shapes_from_detections_rectangle_without_bbox_is_dropped() -> None:
    shapes = shapes_from_detections(
        detections=[Detection(mask=np.ones((5, 5), dtype=bool))],
        shape_type="rectangle",
    )

    assert shapes == []


def test_shapes_from_detections_circle_with_mask_uses_centroid_and_area() -> None:
    [shape] = shapes_from_detections(
        detections=[
            Detection(
                bbox=(10, 20, 30, 50),
                mask=np.ones((31, 21), dtype=bool),
            )
        ],
        shape_type="circle",
    )

    assert shape.shape_type == "circle"
    expected_cx = 10 + 10
    expected_cy = 20 + 15
    expected_radius = math.sqrt(21 * 31 / math.pi)
    assert shape.points[0][0] == pytest.approx(expected_cx)
    assert shape.points[0][1] == pytest.approx(expected_cy)
    assert shape.points[1][0] == pytest.approx(expected_cx + expected_radius)
    assert shape.points[1][1] == pytest.approx(expected_cy)


def test_shapes_from_detections_circle_without_mask_falls_back_to_inscribed() -> None:
    [shape] = shapes_from_detections(
        detections=[Detection(bbox=(0, 0, 10, 20))],
        shape_type="circle",
    )

    assert shape.shape_type == "circle"
    assert shape.points[0][0] == pytest.approx(5)
    assert shape.points[0][1] == pytest.approx(10)
    assert shape.points[1][0] == pytest.approx(10)
    assert shape.points[1][1] == pytest.approx(10)


def test_shapes_from_detections_oriented_rectangle_with_mask_uses_min_area_rect() -> (
    None
):
    # Wider-than-tall rectangular mask: long axis is +x in mask-local coords,
    # so corners trace (xmin, ymin) → (xmax, ymin) → (xmax, ymax) → (xmin, ymax).
    # World corners are mask-local corners offset by the bbox origin.
    [shape] = shapes_from_detections(
        detections=[
            Detection(
                bbox=(10, 20, 30, 30),
                mask=np.ones((11, 21), dtype=bool),
            )
        ],
        shape_type="oriented_rectangle",
    )

    assert shape.shape_type == "oriented_rectangle"
    expected = [(10, 20), (30, 20), (30, 30), (10, 30)]
    for i, (x, y) in enumerate(expected):
        assert (shape.points[i][0], shape.points[i][1]) == pytest.approx((x, y))


def test_shapes_from_detections_oriented_rectangle_without_mask_falls_back() -> None:
    [shape] = shapes_from_detections(
        detections=[Detection(bbox=(0, 0, 10, 20))],
        shape_type="oriented_rectangle",
    )

    assert shape.shape_type == "oriented_rectangle"
    expected = [(0, 0), (10, 0), (10, 20), (0, 20)]
    for i, (x, y) in enumerate(expected):
        assert (shape.points[i][0], shape.points[i][1]) == pytest.approx((x, y))


def test_shapes_from_detections_oriented_rectangle_with_rotated_mask(
    *,
    rotated_rectangle_mask: NDArray[np.bool_],
    rotated_rectangle_angle: float,
) -> None:
    # The mask is centered at (20, 20); placing it at bbox origin (50, 100)
    # offsets the world center to (70, 120).
    [shape] = shapes_from_detections(
        detections=[Detection(bbox=(50, 100, 90, 140), mask=rotated_rectangle_mask)],
        shape_type="oriented_rectangle",
    )

    assert shape.shape_type == "oriented_rectangle"
    edge_dx = shape.points[1][0] - shape.points[0][0]
    edge_dy = shape.points[1][1] - shape.points[0][1]
    recovered_angle = math.atan2(edge_dy, edge_dx)
    assert recovered_angle == pytest.approx(
        rotated_rectangle_angle, abs=math.radians(3)
    )
    center_x = sum(shape.points[i][0] for i in range(4)) / 4
    center_y = sum(shape.points[i][1] for i in range(4)) / 4
    assert center_x == pytest.approx(70.0, abs=0.5)
    assert center_y == pytest.approx(120.0, abs=0.5)


def test_shapes_from_detections_oriented_rectangle_with_square_mask() -> None:
    # The minimum-area rectangle of a square mask is the axis-aligned bbox,
    # so the offset corners trace the bbox itself.
    [shape] = shapes_from_detections(
        detections=[Detection(bbox=(0, 0, 10, 10), mask=np.ones((11, 11), dtype=bool))],
        shape_type="oriented_rectangle",
    )

    assert shape.shape_type == "oriented_rectangle"
    expected = [(0, 0), (10, 0), (10, 10), (0, 10)]
    for i, (x, y) in enumerate(expected):
        assert (shape.points[i][0], shape.points[i][1]) == pytest.approx((x, y))


def test_shapes_from_detections_oriented_rectangle_square_mask_no_bbox() -> None:
    # Without a bbox the mask coordinates are emitted as-is; the square mask
    # still produces a valid axis-aligned rectangle rather than being dropped.
    [shape] = shapes_from_detections(
        detections=[Detection(mask=np.ones((11, 11), dtype=bool))],
        shape_type="oriented_rectangle",
    )

    assert shape.shape_type == "oriented_rectangle"
    expected = [(0, 0), (10, 0), (10, 10), (0, 10)]
    for i, (x, y) in enumerate(expected):
        assert (shape.points[i][0], shape.points[i][1]) == pytest.approx((x, y))


def test_shapes_from_detections_bounds_edge_crossing_oriented_rectangle() -> None:
    mask = np.array(
        [
            [0, 0, 0, 0, 0, 0, 0],
            [0, 0, 1, 1, 1, 0, 0],
            [0, 0, 1, 1, 1, 1, 1],
            [0, 1, 1, 1, 1, 1, 1],
            [0, 0, 1, 1, 1, 1, 1],
            [0, 0, 0, 0, 1, 1, 1],
        ],
        dtype=bool,
    )
    [raw_shape] = shapes_from_detections(
        detections=[Detection(mask=mask)],
        shape_type="oriented_rectangle",
    )

    [shape] = shapes_from_detections(
        detections=[Detection(mask=mask)],
        shape_type="oriented_rectangle",
        image_size=(7, 6),
    )

    assert (raw_shape.points[:, 0] > 7).any()
    lower = np.clip(raw_shape.points.min(axis=0), 0, [7, 6])
    upper = np.clip(raw_shape.points.max(axis=0), 0, [7, 6])
    np.testing.assert_allclose(
        shape.points,
        [lower, [upper[0], lower[1]], upper, [lower[0], upper[1]]],
    )


def test_shapes_from_detections_drops_oriented_rectangle_outside_image() -> None:
    shapes = shapes_from_detections(
        detections=[Detection(bbox=(-10, 10, -1, 20))],
        shape_type="oriented_rectangle",
        image_size=(100, 100),
    )

    assert shapes == []


def test_shapes_from_detections_polygon_with_mask_traces_contour() -> None:
    [shape] = shapes_from_detections(
        detections=[Detection(mask=np.ones((20, 20), dtype=bool))],
        shape_type="polygon",
    )

    assert shape.shape_type == "polygon"
    assert len(shape.points) >= 3


def test_shapes_from_detections_polygon_simplifies_pixel_stair_steps() -> None:
    mask = np.zeros((100, 100), dtype=bool)
    mask[20:80, 30:70] = True

    [shape] = shapes_from_detections(
        detections=[Detection(mask=mask)],
        shape_type="polygon",
    )

    assert len(shape.points) == 4


def test_shapes_from_detections_polygon_keeps_disconnected_regions() -> None:
    mask = np.zeros((100, 100), dtype=bool)
    mask[10:40, 10:40] = True
    mask[60:90, 60:90] = True

    shapes = shapes_from_detections(
        detections=[Detection(mask=mask)],
        shape_type="polygon",
    )

    assert len(shapes) == 2
    assert shapes[0].group_id == shapes[1].group_id
    assert shapes[0].group_id is not None


def test_shapes_from_detections_polygon_drops_hole() -> None:
    mask = np.zeros((100, 100), dtype=bool)
    mask[10:90, 10:90] = True
    mask[30:70, 30:70] = False

    [shape] = shapes_from_detections(
        detections=[Detection(mask=mask)],
        shape_type="polygon",
    )

    polygon_mask = shape_to_mask(
        mask.shape,
        shape.points.tolist(),
        shape_type="polygon",
    )
    assert polygon_mask[20, 20]
    assert polygon_mask[50, 50]


def test_shapes_from_detections_polygon_drops_lands_within_deviation() -> None:
    mask = np.zeros((5, 5), dtype=bool)
    mask[1, 1] = True
    mask[2, 2] = True

    shapes = shapes_from_detections(
        detections=[Detection(mask=mask)],
        shape_type="polygon",
    )

    assert shapes == []

    detailed_shapes = shapes_from_detections(
        detections=[Detection(mask=mask)],
        shape_type="polygon",
        polygon_detail=100,
    )

    assert len(detailed_shapes) == 2
    assert detailed_shapes[0].group_id == detailed_shapes[1].group_id


def test_shapes_from_detections_polygon_maximum_detail_keeps_thin_mask() -> None:
    mask = np.zeros((3, 400), dtype=bool)
    mask[1, :] = True

    [shape] = shapes_from_detections(
        detections=[Detection(mask=mask)],
        shape_type="polygon",
        polygon_detail=100,
    )

    assert len(shape.points) >= 3


def test_shapes_from_detections_polygon_with_bbox_offsets_contour() -> None:
    # The mask traces a contour in mask-local coordinates; a bbox origin shifts
    # every contour point by (bbox[0], bbox[1]) into image coordinates.
    mask = np.ones((20, 20), dtype=bool)
    [local, offset] = shapes_from_detections(
        detections=[
            Detection(mask=mask),
            Detection(bbox=(10, 20, 30, 40), mask=mask),
        ],
        shape_type="polygon",
    )

    assert offset.shape_type == "polygon"
    np.testing.assert_allclose(offset.points, local.points + [10, 20])


def test_shapes_from_detections_mask_uses_rounded_bbox_corners() -> None:
    mask = np.ones((30, 22), dtype=bool)
    [shape] = shapes_from_detections(
        detections=[Detection(bbox=(10.4, 20.6, 30.9, 50.1), mask=mask)],
        shape_type="mask",
    )

    assert shape.shape_type == "mask"
    assert (shape.points[0][0], shape.points[0][1]) == pytest.approx((10, 21))
    assert (shape.points[1][0], shape.points[1][1]) == pytest.approx((31, 50))
    assert shape.mask is not None
    assert np.array_equal(shape.mask, mask)


def test_shapes_from_detections_mask_drops_empty_mask() -> None:
    # OSAM occasionally returns a bbox whose segmentation mask is all-False;
    # without this guard the shape would render as bbox-only (no visible mask).
    shapes = shapes_from_detections(
        detections=[
            Detection(bbox=(10, 20, 30, 50), mask=np.zeros((31, 21), dtype=bool))
        ],
        shape_type="mask",
    )
    assert shapes == []


@pytest.mark.parametrize("shape_type", typing.get_args(AiOutputFormat))
def test_shapes_from_detections_without_bbox_or_mask_is_dropped(
    *,
    shape_type: AiOutputFormat,
) -> None:
    # Every shape type needs a bbox, a mask, or both; with neither there is
    # nothing to derive geometry from, so the detection is dropped.
    shapes = shapes_from_detections(
        detections=[Detection()],
        shape_type=shape_type,
    )

    assert shapes == []


def test_mask_required_shape_types_is_polygon_and_mask() -> None:
    assert MASK_REQUIRED_SHAPE_TYPES == {"polygon", "mask"}


def test_assign_available_group_ids_avoids_existing_ids() -> None:
    existing = [Shape(group_id=5)]
    new_shapes = [
        Shape(group_id=1),
        Shape(group_id=1),
        Shape(group_id=2),
        Shape(group_id=None),
    ]

    assign_available_group_ids(shapes=new_shapes, existing_shapes=existing)

    assert [shape.group_id for shape in new_shapes] == [6, 6, 7, None]
